/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/06/18 16:51:58
*Description:  组件备注框
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
public class TJRemarks : MonoBehaviour
{

    [Header("备注工具：（回车换行）")]
    [Tooltip("备注工具")]
    [Multiline(15)]
    public string m_text;
//  public GridSelection asd;
//  private void Start() {
//    print (GridSelection.position);
//  }
}
