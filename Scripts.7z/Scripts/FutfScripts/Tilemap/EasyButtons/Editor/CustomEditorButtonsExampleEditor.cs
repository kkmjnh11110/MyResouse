/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/07/04 16:48:21
*Description:   
*/
using UnityEditor;

namespace EasyButtons
{
    [CustomEditor(typeof(CustomEditorButtonsExample))]
    public class CustomEditorButtonsExampleEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            this.DrawEasyButtons();
            base.OnInspectorGUI();
        }
    }
}
