/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/07/04 16:48:23
*Description:   
*/
using UnityEngine;

namespace EasyButtons
{
    [CreateAssetMenu(fileName = "ScriptableObjectExample.asset", menuName = "EasyButtons/ScriptableObjectExample")]
    public class ScriptableObjectExample : ScriptableObject
    {
        [Button]
        public void SayHello()
        {
            Debug.Log("Hello");
        }

        [Button(ButtonMode.DisabledInPlayMode)]
        public void SayHelloEditor()
        {
            Debug.Log("Hello from edit mode");
        }

        [Button(ButtonMode.EnabledInPlayMode)]
        public void SayHelloPlayMode()
        {
            Debug.Log("Hello from play mode");
        }
    }
}
