/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/10/23 16:31:54
*Description:   
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransitionData : MonoBehaviour
{
    public int m_Id = 0;
    // public int m_Radius = 0;
    // Start is called before the first frame update
    // void Start()
    // {

    // }

    // // Update is called once per frame
    // void Update()
    // {

    // }
}
