/** *****************************Description:  动态阻挡对象上面添加这个脚本*****************************
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/07/23 10:17:13
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.Networking;
using UnityEditor;

//Unity中默认情况下，脚本只有在运行的时候才被执行，加上此属性[ExecuteInEditMode]后，不运行程序，也能执行脚本。
[ExecuteInEditMode]
public class DynamicBlocks : MonoBehaviour
{
    #region 变量
    public List<Vector2Int> area = new List<Vector2Int> { new Vector2Int(0, 0), new Vector2Int(1, 1) };
    [System.NonSerialized]
    public Vector2Int pos;
    private string gameObjectName;
    //绘制tilebase
    private Tilemap TM;
    private TileBase tb;
    [System.NonSerialized]
    public Grid grid = null;
    Transform but;
    Vector3Int v3I;
    TilemapRenderer renderer;
    int blockX;
    int blockY;

    int areaX;
    int areaY;
    // [System.NonSerialized]
    public List<Vector2Int> m_parentVector2 = new List<Vector2Int> { };

    WaitForSeconds waitForSeconds = new WaitForSeconds(1.0f);

    public bool m_snap = true;//开关网格捕捉
    #endregion

    #region 无用代码
    // [EasyButtons.Button]
    // public void Awake()
    // {
    //   gameObjectName = gameObject.name;
    //   Debug.Log(gameObjectName);
    //   Debug.Log("area：" + area.Count);
    //   // jisuan();
    //   DrawTile();
    //   Debug.Log("pos:" + pos.x + "," + pos.y);
    // }
    #endregion

    private void Awake()
    {
        // System.GC.Collect();//GC

        GameObject[] obj = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[]; //关键代码，获取所有gameobject元素给数组obj
        foreach (GameObject child in obj)    //遍历所有gameobject
        {
            //=======类型判空undefined=======
            if (child.GetComponent<Grid>())
            {
                grid = child.GetComponent<Grid>();
            }
        }

        v3I = new Vector3Int(0, 0, 0);

        tb = Resources.Load("hong") as TileBase;
        TM = GameObject.Find("Tilemap_Event").GetComponent<Tilemap>();
        renderer = GameObject.Find("Tilemap_Event").GetComponent<TilemapRenderer>();
        renderer.sortingLayerName = "策划备注";
        renderer.sortingOrder = 9999;
    }

    public void jisuan()
    {
        #region /*------------------------------------------最外围坐标判断*/
        List<Vector2Int> posRandArea1 = new List<Vector2Int>() { };//1最左
        List<Vector2Int> posRandArea2 = new List<Vector2Int>() { };//2最右
        List<Vector2Int> posRandArea3 = new List<Vector2Int>() { };//3最下
        List<Vector2Int> posRandArea4 = new List<Vector2Int>() { };//4最上
        Vector2Int RandArea1 = new Vector2Int(area[0].x, area[0].y);//1小小
        Vector2Int RandArea2 = new Vector2Int(area[0].x, area[0].y);//2大小
        Vector2Int RandArea3 = new Vector2Int(area[0].x, area[0].y);//3小大
        Vector2Int RandArea4 = new Vector2Int(area[0].x, area[0].y);//4大大
        int posXmax = area[0].x;//找到x最大值
        int posXmin = area[0].x;//找到x小大值
        int posYmax = area[1].y;//找到y最大值
        int posYmin = area[1].y;//找到y小大值
                                //获取最外面的x和y值
        for (int Q = 0; Q < area.Count; Q++)
        {
            if (area[Q].x >= posXmax)
            {
                posXmax = area[Q].x;
            }
            if (posXmin >= area[Q].x)
            {
                posXmin = area[Q].x;
            }
            if (area[Q].y >= posYmax)
            {
                posYmax = area[Q].y;
            }
            if (posYmin >= area[Q].y)
            {
                posYmin = area[Q].y;
            }
        }
        // Debug.Log("posXmax:" + posXmax + "posXmin:" + posXmin + "posYmax:" + posYmax + "posYmin:" + posYmin);
        //获取最外面x和y值总共那些点
        foreach (var item in area)
        {
            if (item.x == posXmax)
            {
                // Debug.Log("最右边点是：" + item);
                posRandArea2.Add(item);
            }
            if (item.x == posXmin)
            {
                // Debug.Log("最左边点是：" + item);
                posRandArea1.Add(item);
            }
            if (item.y == posYmax)
            {
                // Debug.Log("最上边点是：" + item);
                posRandArea4.Add(item);
            }
            if (item.y == posYmin)
            {
                // Debug.Log("最下边点是：" + item);
                posRandArea3.Add(item);
            }
        }
        //比较这些点确定四个点的值
        foreach (var item1 in posRandArea1)
        {
            if (item1.y < RandArea1.y)
            {
                RandArea1 = item1;
            }
            else if (item1.y > RandArea3.y)
            {
                RandArea3 = item1;
            }
        }
        foreach (var item2 in posRandArea2)
        {
            if (item2.y < RandArea2.y)
            {
                RandArea2 = item2;
            }
            else if (item2.y > RandArea2.y)
            {
                RandArea4 = item2;
            }
        }
        foreach (var item3 in posRandArea3)
        {
            if (item3.x < RandArea1.x)
            {
                RandArea1 = item3;
            }
            else if (item3.x > RandArea2.x)
            {
                RandArea2 = item3;
            }
        }
        foreach (var item4 in posRandArea4)
        {
            if (item4.x < RandArea3.x)
            {
                RandArea3 = item4;
            }
            else if (item4.x > RandArea4.x)
            {
                RandArea4 = item4;
            }
        }
        // Debug.Log("RandArea1:" + RandArea1 + "RandArea2:" + RandArea2 + "RandArea3:" + RandArea3 + "RandArea4:" + RandArea4);
        /*------------------------------------------最外围坐标判断END*/
        #endregion
    }

    #region StartCoroutine顺序协程
    // void Start()
    // {
    //   StartCoroutine(Init());
    // }
    IEnumerator Init()
    {
        yield return StartCoroutine(init1());
    }
    IEnumerator init1()
    {
        DrawTile();
        StopCoroutine(Init());//GC
        yield return waitForSeconds;//
    }
    #endregion

    Vector3Int v3i1 = new Vector3Int();
    Vector3Int v3i2 = new Vector3Int();

    /// <summary>
    /// 绘制tilemap的tilebase
    /// </summary>
    public void DrawTile()
    {
        // if (!gameObject.GetComponent<SpriteRenderer>())
        {
            GameObject[] obj = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[]; //关键代码，获取所有gameobject元素给数组obj
            foreach (GameObject child in obj)    //遍历所有gameobject
            {
                //=======类型判空undefined=======
                if (child.GetComponent<Grid>())
                {
                    grid = child.GetComponent<Grid>();
                }
            }

            blockX = grid.LocalToCell((Vector3)transform.position).x;
            blockY = grid.LocalToCell((Vector3)transform.position).y;
            // Debug.Log("blockX:----------" + blockX);
            // Debug.Log("blockY:----------" + blockY);

            // Debug.Log("---------***********area[1].x:"+area[1].x);
            // Debug.Log("---------***********area[0].x:"+area[0].x);

            areaX = area[1].x - area[0].x + 1;
            areaY = area[1].y - area[0].y + 1;
            for (int i = 0; i < areaX; i++)
            {
                for (int j = 0; j < areaY; j++)
                {
                    if (area[0].x == 0 && area[0].y == 0 && area[1].x == 0 & area[1].y == 0)
                    {

                    }
                    else
                    {
                        v3i1.x = area[0].x + i + blockX;
                        v3i1.y = area[0].y + j + blockY;
                        v3i1.z = 0;
                        TM.SetTile(v3i1, tb);
                    }
                }
            }

            if ((area[1].x == area[0].x && area[1].y == area[0].y && area[0].x == 0 && (!transform.GetComponent<SpriteRenderer>()) && (!transform.GetComponent<UnityEngine.UI.Button>())))
            {
                v3i2.x = area[0].x + blockX;
                v3i2.y = area[0].y + blockY;
                v3i2.z = 0;
                TM.SetTile(v3i2, tb);
            }
        }
    }
    /// <summary>
    /// 清除tilemap所有元素
    /// </summary>
    public void ClearTile()
    {
        TM = GameObject.Find("Tilemap_Event").GetComponent<Tilemap>();
        //清除tilebase
        TM.ClearAllTiles();
    }
    float nowX = 0;
    float nowY = 0;
    int updateCount = 0;

    private void LateUpdate()
    {
        //坐标吸附
        {
            // if (m_snap)
            // {
            //     if (nowX != transform.position.x || nowY != transform.position.y)
            //     {
            //         grid = GameObject.Find("MapData").GetComponent<Grid>();
            //         Vector3Int gridpos = grid.LocalToCell((Vector3)transform.position);
            //         pos.x = gridpos.x;
            //         pos.y = gridpos.y;
            //         v3I.x = gridpos.x;
            //         v3I.y = gridpos.y;
            //         v3I.z = 0;
            //         transform.position = grid.CellToLocal(v3I);
            //     }
            // }
            // //上一帧的坐标和这帧的坐标不同的话
            // nowX = transform.position.x;
            // nowY = transform.position.y;
        }

        // if (Input.GetMouseButtonUp(1))
        // if (nowX != transform.position.x || nowY != transform.position.y)
        // if (false)
        // {
        //     if (grid == null)
        //     {
        //         grid = GameObject.Find("MapData").GetComponent<Grid>();
        //     }

        //     //   Debug.Log("aaaaaa");
        //     //获取对象名称存到json中
        //     gameObjectName = gameObject.name;
        //     m_parentVector2.Clear();
        //     but = GameObject.Find("Objects").transform;
        //     ClearTile();//清除tilemap所有元素
        //                 /**=======foreach遍历所有的子物体以及孙物体，并且遍历包含本身=======
        //                 /**=======foreach遍历所有的子物体以及孙物体，并且遍历包含本身=======
        //                 * @param m_list:列表数组
        //                 *
        //                 */
        //     foreach (Transform child in but.GetComponentsInChildren<Transform>(true))
        //     {
        //         if (child.GetComponent<DynamicBlocks>() && child.gameObject.active == true)
        //         {
        //             StartCoroutine(child.GetComponent<DynamicBlocks>().Init());//绘制tilemap的tilebase
        //                                                                        // child.GetComponent<DynamicBlocks>().DrawTile();//绘制tilemap的tilebase
        //         }
        //     }
        //     GetChildPos();//采集对象格子
        //                   // }

        // }

        // nowX = transform.position.x;
        // nowY = transform.position.y;
    }

    /// <summary>
    /// 编辑器窗口调用绘制事件设置范围
    /// </summary>
    public void CallDraw()
    {
        if (grid == null)
        {
            grid = GameObject.Find("MapData").GetComponent<Grid>();
        }
        //获取对象名称存到json中
        gameObjectName = gameObject.name;
        m_parentVector2.Clear();
        but = GameObject.Find("Objects").transform;

        ClearTile();//清除tilemap所有元素

        /**=======foreach遍历所有的子物体以及孙物体，并且遍历包含本身=======
        /**=======foreach遍历所有的子物体以及孙物体，并且遍历包含本身=======
        * @param m_list:列表数组
        *
        */
        foreach (Transform child in but.GetComponentsInChildren<Transform>(true))
        {
            if (child.GetComponent<DynamicBlocks>() && child.gameObject.active == true)
            {
                StartCoroutine(child.GetComponent<DynamicBlocks>().Init());//绘制tilemap的tilebase
                                                                           // child.GetComponent<DynamicBlocks>().DrawTile();//绘制tilemap的tilebase
                child.GetComponent<DynamicBlocks>().GetChildPos();//采集对象格子
            }
        }

    }

    Vector2Int v2i = new Vector2Int();
    /// <summary>
    /// 采集对象格子
    /// </summary>
    private void GetChildPos()
    {

        Vector3Int gridpos = grid.LocalToCell((Vector3)transform.position);
        pos.x = gridpos.x;
        pos.y = gridpos.y;

        //如果是父对象就有精灵组件
        if (gameObject.GetComponent<SpriteRenderer>())
        {
            for (int isChildNum = 0; isChildNum < transform.childCount; isChildNum++)
            {
                Transform ischild = transform.GetChild(isChildNum);
                if (ischild.GetComponent<DynamicBlocks>())
                {

                    int blockXParent = grid.LocalToCell((Vector3)ischild.parent.position).x;//父亲的坐标点
                    int blockYParent = grid.LocalToCell((Vector3)ischild.parent.position).y;//父亲的坐标点
                    int blockXChild = grid.LocalToCell((Vector3)ischild.position).x;//孩子的坐标点
                    int blockYChild = grid.LocalToCell((Vector3)ischild.position).y;//孩子的坐标点

                    List<Vector2Int> areaChild = ischild.GetComponent<DynamicBlocks>().area;//孩子身上的两个区域点
                    DynamicBlocks parentDynamicBlocks = ischild.parent.GetComponent<DynamicBlocks>();//写到父亲节点里
                    int areaXChild = areaChild[1].x - areaChild[0].x + 1;//孩子身上点组成的边长
                    int areaYChild = areaChild[1].y - areaChild[0].y + 1;//孩子身上点组成的边长
                    for (int i = 0; i < areaXChild; i++)
                    {
                        for (int j = 0; j < areaYChild; j++)
                        {
                            int nowX = areaChild[0].x + i + blockXChild - blockXParent;
                            int nowY = areaChild[0].y + j + blockYChild - blockYParent;
                            for (int parentNum = 0; parentNum < parentDynamicBlocks.m_parentVector2.Count; parentNum++)
                            {
                                if ((parentDynamicBlocks.m_parentVector2[parentNum].x == nowX) && (parentDynamicBlocks.m_parentVector2[parentNum].y == nowY))
                                {
                                    parentDynamicBlocks.m_parentVector2.RemoveAt(parentNum);//移除重复坐标
                                }
                            }
                            v2i.x = nowX;
                            v2i.y = nowY;
                            parentDynamicBlocks.m_parentVector2.Add(v2i);
                        }
                    }
                }
            }


        }
    }


}