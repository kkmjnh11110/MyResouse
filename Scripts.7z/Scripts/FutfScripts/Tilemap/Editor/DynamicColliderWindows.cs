/** *****************************Description:动态阻挡制作窗口*****************************
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/10/28 18:00:03
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.IO;//引用这个命名空间是用于接下来用可变的字符串的
using System.Text;//引用这个命名空间是用于接下来用可变的字符串的
using UnityEngine.UI;
using System;
using System.Threading.Tasks;
using UnityEngine.Tilemaps;

public class DynamicColliderWindows : EditorWindow
{
    #region ===================================变量==================================
    static MapEditorWindows m_mapWindow;//地图编辑器窗口
    static DynamicColliderWindows m_dynamicColliderWindows;//地图编辑器窗口

    private bool groupEnabled = false;

    bool showPosition = true;//折叠
    string status = "动态阻挡列表";//折叠

    GameObject gamelist = null;
    private GameObject m_currentObj;
    private Vector2 V2 = Vector2.zero;
    int leftSize = 10;

    #endregion ================================变量==================================

    #region ===================================生命周期==================================
    void OnGUI()
    {
        //标题
        {
            GUILayout.Space(10);
            GUI.skin.label.fontSize = 24;
            GUI.skin.label.alignment = TextAnchor.MiddleCenter;
            GUILayout.Label("动态阻挡模块制作工具");
        }

        //返回主界面
        GUILayout.Space(5);
        GUILayout.BeginArea(new Rect(Screen.width - Screen.width / 14, 5, Screen.width / 15, Screen.width / 15));
        if (GUILayout.Button("<--", GUILayout.Width(Screen.width / 15), GUILayout.Height(Screen.width / 15)))
        {
            //打开新窗口
            m_mapWindow = (MapEditorWindows)EditorWindow.GetWindow(typeof(MapEditorWindows), false, "地图编辑器", true);//创建窗口
            m_mapWindow.Show();//展示
        }
        GUILayout.EndArea();

        GUILayout.Space(10);
        GUILayout.BeginHorizontal(GUI.skin.textField);
        GUI.skin.textField.alignment = TextAnchor.MiddleCenter;
        if (GUILayout.Button("管理动态阻挡", GUILayout.Width(Screen.width / 2), GUILayout.Height(Screen.width / 15)))
        {
            Debug.Log("创建阻挡");
            OnTip("正在研发中");
        }

        if (GUILayout.Button("绘制动态阻挡", GUILayout.Width(Screen.width / 2), GUILayout.Height(Screen.width / 15)))
        {
            Debug.Log("绘制阻挡");
            OnTip("正在研发中");
        }
        GUILayout.EndHorizontal();

        GUILayout.Space(10);
        GUILayout.BeginVertical(GUI.skin.textField);
        //折叠列表，里面放动态阻挡物体
        {
            showPosition = EditorGUILayout.Foldout(showPosition, status);
            if (showPosition)
            {
                GUILayout.Space(5);
                if (GUILayout.Button("刷新列表", GUILayout.Width(Screen.width), GUILayout.Height(Screen.width / 18)))
                {
                    Debug.Log("刷新列表");
                    gamelist = GameObject.Find("MapData/Objects");
                }
                GUILayout.Space(5);
                if (gamelist != null)
                {
                    V2 = EditorGUILayout.BeginScrollView(V2, false, true);
                    //动态阻挡对象列表
                    for (int i = 0; i < gamelist.transform.childCount; i++)
                    {
                        GUILayout.BeginHorizontal(GUI.skin.textField);
                        if (GUILayout.Button(gamelist.transform.GetChild(i).name, GUILayout.Width(Screen.width / 5 * 4), GUILayout.Height(Screen.width / 30)))
                        {
                            m_currentObj = gamelist.transform.GetChild(i).gameObject;
                            Selection.activeGameObject = m_currentObj;
                            EditorApplication.ExecuteMenuItem("Window/General/Scene");
                            EditorApplication.ExecuteMenuItem("Edit/Frame Selected");
                        }
                        if (GUILayout.Button("-", GUILayout.Width(Screen.width / 5), GUILayout.Height(Screen.width / 30)))
                        {

                            if (gamelist.transform.GetChild(i).gameObject)
                            {
                                DisplayDialogUilt(delegate () { DestroyImmediate(gamelist.transform.GetChild(i).gameObject); }, "是否删除当前动态阻挡？");
                            }
                        }
                        GUILayout.EndHorizontal();
                    }
                    //添加动态阻挡功能
                    if (GUILayout.Button("+", GUILayout.Width(Screen.width), GUILayout.Height(Screen.width / 30)))
                    {
                        Debug.Log("+");
                    }
                    EditorGUILayout.EndScrollView();
                }
            }

        }
        //绘制
        GUILayout.Space(5);
        if (GUILayout.Button("绘制", GUILayout.Width(Screen.width), GUILayout.Height(Screen.width / 18)))
        {
            //=======类型判空undefined=======
            // Debug.Log(Selection.activeGameObject);

            if (m_currentObj)
            {
                if (!m_currentObj.transform.Find("TileChild"))
                {
                    Transform TileChild = new GameObject("TileChild").transform;
                    TileChild.parent = m_currentObj.transform;
                    TileChild.localPosition = Vector3.zero;
                    Tilemap TM = TileChild.gameObject.AddComponent<Tilemap>();
                    TM.tileAnchor = Vector3.one;
                    TilemapRenderer TR = TileChild.gameObject.AddComponent<TilemapRenderer>();
                    TR.sortingOrder = 999;
                    Selection.activeGameObject = TileChild.gameObject;
                    EditorApplication.ExecuteMenuItem("Window/General/Scene");
                    EditorApplication.ExecuteMenuItem("Edit/Frame Selected");
                }
            }

            EditorApplication.ExecuteMenuItem("Window/2D/Tile Palette");
            EditorApplication.ExecuteMenuItem("Window/General/Scene");
        }
        //保存
        GUILayout.Space(5);
        if (GUILayout.Button("保存", GUILayout.Width(Screen.width), GUILayout.Height(Screen.width / 18)))
        {
            Debug.Log("保存");
            //=======类型判空undefined=======
            if (m_currentObj)
            {
                if (m_currentObj.GetComponent<Tilemap>())
                {
                    Tilemap tm = m_currentObj.GetComponent<Tilemap>();//tilemap中的Tile
                    Vector2Int m_width_Height = new Vector2Int(123, 123);//地图宽高;
                    TileBase tileBase = Resources.Load("hong") as TileBase;

                    for (int k = 0; k <= (m_width_Height.x - 1); k++)//遍历网格x，m_width_Height0.2大小的网格
                    {
                        for (int j = 0; j <= (m_width_Height.y - 1); j++)//遍历网格y
                        {
                            // if (tm.)//如果tile被填充过huang
                            {
                                // TilemapCollider2D tc=Selection.activeGameObject.GetComponent<TilemapCollider2D>();
                                // tc.
                            }
                            if (tm.GetTile(new Vector3Int(k, j, 0)) == tileBase)//如果tile被填充过huang
                            {
                                //Debug.Log("m_huang[h]:" + m_huang[h]);
                                // m_RandAreaArray.Add(new Vector2Int(k, j));//存到数组中
                                Debug.Log("k:" + k + "j:" + j);
                            }
                        }
                    }
                    DestroyImmediate(m_currentObj.GetComponent<TilemapCollider2D>());
                    DestroyImmediate(m_currentObj.GetComponent<Tilemap>());
                }
            }
        }


        GUILayout.EndVertical();

        #region 未使用
        // EditorGUILayout.HelpBox("帮助信息", MessageType.Info);//打开后可操作镶嵌其中的GUI

        // //打开后可操作镶嵌其中的GUI
        // groupEnabled = EditorGUILayout.BeginToggleGroup("可选设置", groupEnabled);
        // EditorGUILayout.HelpBox("帮助信息", MessageType.Info);
        // EditorGUILayout.EndToggleGroup();
        #endregion 未使用

    }

    private void OnHierarchyChange()
    {
        Debug.Log("对象面板事件");
    }

    private void OnProjectChange()
    {
        Debug.Log("文件事件");
    }

    private void OnSelectionChange()
    {
        Debug.Log("选择事件");
    }


    //通用函数，弹窗（委托）;调用方法DisplayDialogUilt(delegate(){});
    /// <summary>
    /// 通用函数，弹窗（委托）;调用方法DisplayDialogUilt(delegate(){});
    /// </summary>
    /// <param name="action">要传递的函数</param>
    /// <param name="Qustion">要显示的提问</param>
    private void DisplayDialogUilt(System.Action action, string Qustion)
    {
        bool ok = EditorUtility.DisplayDialog("确认框", Qustion, "ok", "cancel");

        switch (ok)
        {
            case true: action.Invoke(); break;
            case false: break;
        }
    }

    #endregion ================================生命周期==================================

    #region ===================================引用方法==================================
    /// <summary>
    /// 弹出吐司提示框
    /// </summary>
    /// <param name="text">要显示的文本</param>
    // 弹出吐司提示框
    private void OnTip(string text)
    {
        m_dynamicColliderWindows = (DynamicColliderWindows)EditorWindow.GetWindow(typeof(DynamicColliderWindows), false, "开", true);//创建窗口
        m_dynamicColliderWindows.ShowNotification(new GUIContent(text));
    }

    #endregion ================================引用方法==================================

    #region ===================================未引用方法==================================
    // // Start is called before the first frame update
    // void Start()
    // {

    // }

    // // Update is called once per frame
    // void Update()
    // {

    // }
    #endregion ================================未引用方法==================================

}
