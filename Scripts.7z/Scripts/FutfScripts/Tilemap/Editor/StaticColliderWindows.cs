/** *****************************Description:静态阻挡制作窗口*****************************
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/10/28 18:23:07
*Description:   
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.IO;//引用这个命名空间是用于接下来用可变的字符串的
using System.Text;//引用这个命名空间是用于接下来用可变的字符串的
using UnityEngine.UI;
using System;
using System.Threading.Tasks;

public class StaticColliderWindows : EditorWindow
{
    static MapEditorWindows m_mapWindow;//地图编辑器窗口

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnGUI()
    {
        //标题
        {
            GUILayout.Space(10);
            GUI.skin.label.fontSize = 24;
            GUI.skin.label.alignment = TextAnchor.MiddleCenter;
            GUILayout.Label("静态阻挡模块制作工具");
        }

        //返回主界面
        GUILayout.Space(5);
        GUILayout.BeginArea(new Rect(Screen.width - Screen.width / 14, 5, Screen.width / 15, Screen.width / 15));
        if (GUILayout.Button("<--", GUILayout.Width(Screen.width / 15), GUILayout.Height(Screen.width / 15)))
        {
            //打开新窗口
            m_mapWindow = (MapEditorWindows)EditorWindow.GetWindow(typeof(MapEditorWindows), false, "地图编辑器", true);//创建窗口
            m_mapWindow.Show();//展示
        }
        GUILayout.EndArea();
    }
}
