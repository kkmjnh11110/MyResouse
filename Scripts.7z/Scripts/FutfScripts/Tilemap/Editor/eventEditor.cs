/** *Description:   editor模板
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/07/18 13:31:08
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


public class eventEditor : MonoBehaviour
{
  public static TextAsset m_textAsset;//读取本地文件

//   [MenuItem("⚙事件编辑器/⚙怪物/🔍添加", false, 2)]


  static void Test()
  {
    /*------------------------------------------读取本地文件*/
    Debug.Log("事件编辑器/怪物/添加");
    m_textAsset = ((TextAsset)Resources.Load("test"));
    Debug.Log(m_textAsset.text);
    /*------------------------------------------找得到预制对象*/
    Debug.Log(GameObject.Find("Event").name);
    Transform but = GameObject.Find("Event").transform;
    /**=======foreach遍历所有的子物体以及孙物体，并且遍历包含本身=======
    * @param m_list:列表数组
    *
    */
    for (int i = 0; i < but.GetComponentsInChildren<Transform>(true).Length; i++)
    {
      string name = but.GetComponentsInChildren<Transform>(true)[i].name;
      Debug.Log(name);

      //Split分割字符串
      string level = (name).Split('V')[1];
      /**Split分割字符串
      * @param :字符串
      * @param :分割符号
      * @param :返回第个数组
      */
      if (level == "10")
      {
        Debug.Log("10");
      }
    }
  }

//   [MenuItem("⚙事件编辑器/⚙物品/🔍添加", false, 3)]
  static void Test2()
  {
    Debug.Log("事件编辑器/物品/添加");
  }

}
