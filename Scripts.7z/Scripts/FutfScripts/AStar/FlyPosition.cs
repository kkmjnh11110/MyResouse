/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/07/29 11:38:13
*Description:   
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class FlyPosition : MonoBehaviour
{
  Grid grid;
  GameObject character;
  public InputField m_x;
  public InputField m_y;
  // Start is called before the first frame update
  void Start()
  {
    grid = GameObject.Find("AStar (1)").GetComponent<Grid>();
    character = GameObject.Find("Character");
  }


  public void FlyPos()
  {
    int resultX = int.Parse(m_x.text);
    int resultY = int.Parse(m_y.text);//字符串转整形
    Vector3 posLocal = grid.CellToLocalInterpolated(new Vector3(resultX, resultY, 0));
    character.transform.position = posLocal;
  }


}
