/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  2D_IsoTilemaps_Project
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/17 15:15:46
*Description:   
*/
/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  2D_IsoTilemaps_Project
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/13 14:47:28
*Description:  寻路位移和动画控制
*/

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IsometricPlayerAnimationCtl : MonoBehaviour
{

  #region =======插件说明=======



  #endregion

  [Tooltip("一、角色位移速度。")]
  [Header("一、角色位移速度。")]
  [Header("地堡3寻路角色控制插件")]
  public float movementSpeed = 1f;

  IsometricCharacterRenderer isoRenderer;

  Rigidbody2D rbody;
  [Tooltip("二、寻路指针对象。")]
  [Header("二、寻路指针对象。")]
  public GameObject m_Target;
  [Tooltip("三、主角对象。")]
  [Header("三、主角对象。")]
  public GameObject m_Role;

  private Text text;
  private void Awake()
  {
    rbody = GetComponent<Rigidbody2D>();
    isoRenderer = GetComponentInChildren<IsometricCharacterRenderer>();
    text = GameObject.Find("posText").GetComponent<Text>();
  }


  // Update is called once per frame
  void FixedUpdate()
  {
    //Vector2 currentPos = rbody.position;
    //float horizontalInput = Input.GetAxis("Horizontal");
    //float verticalInput = Input.GetAxis("Vertical");
    //Vector2 inputVector = new Vector2(horizontalInput, verticalInput);

    ////Vector2 inputVector = new Vector2(Target.transform.position.x, Target.transform.position.y);
    //inputVector = Vector2.ClampMagnitude(inputVector, 1);
    //Vector2 movement = inputVector * movementSpeed;
    //Vector2 newPos = currentPos + movement * Time.fixedDeltaTime;

    Vector3 v3 = new Vector3(0, 0, 0);
    v3 = (m_Target.transform.position) - (m_Role.transform.position);
    ;
    Vector2 v2 = new Vector2(v3.x, v3.y);
    isoRenderer.SetDirection(v2);//角色朝向
                                 //isoRenderer.SetDirection(movement);
                                 //rbody.MovePosition(newPos);
    /*------------------------------------------打印角色当前格子位置*/
    Grid grid = GameObject.Find("AStar (1)").GetComponent<Grid>();
    Vector3 pos = grid.LocalToCellInterpolated(new Vector3(transform.localPosition.x, transform.localPosition.y, 0));

    text.text = "主角坐标：(" + (int)pos.x + "，" + (int)pos.y + ")";
    /*------------------------------------------打印角色当前格子位置 End*/
  }
  /// <summary>
  /// =======触发器碰撞检测函数=======
  /// </summary>
  /// <param name="other">碰撞到主角的物体</param>
  private void OnTriggerEnter2D(Collider2D other)
  {
    if (other.name == "Target")
    {
      other.transform.GetChild(0).GetComponent<SpriteRenderer>().enabled = false;
    }
  }
  /// <summary>
  /// =======触发器碰撞退出检测函数=======
  /// </summary>
  /// <param name="other">碰撞到主角的物体</param>
  private void OnTriggerExit2D(Collider2D other)
  {
    if (other.name == "Target")
    {
      other.transform.GetChild(0).GetComponent<SpriteRenderer>().enabled = true;
    }
  }
}
