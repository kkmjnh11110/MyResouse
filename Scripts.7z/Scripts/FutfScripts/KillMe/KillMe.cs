/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.4.0f1
*CreateTime:   2019/06/14 10:56:37
*Description:  给策划小哥用的游戏开始隐藏掉备注的物体
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillMe : MonoBehaviour
{
    void Awake()
    {
        gameObject.SetActive(false);
    }
}
