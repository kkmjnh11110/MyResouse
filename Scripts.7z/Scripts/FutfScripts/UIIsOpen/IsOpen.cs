/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/06/05 15:39:05
*Description:   
*/
/**
*Copyright(C) 2019 by water
*All rights reserved.
*ProductName:  water
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/22 16:58:13
*Description:  是否开启组件功能
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsOpen : MonoBehaviour
{
    /// <summary> m_list功能:显示透支绘制组件 </summary>
    public List<DebugOverdrawMode> m_list;
    /// <summary> m_list2功能:光阴组件 </summary>
    public List<SFRenderer> m_list2;

    /// <summary> m_Panel功能:测试UI面板 </summary>
    public GameObject m_Panel;

    private bool m_isOpen = false;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    /// <summary>
    /// 是否开启组件功能
    /// </summary>
    public void IsOpenoverdraw()
    {
        for (int i = 0; i < m_list.Count; i++)
        {
            m_list[i].enabled = m_isOpen;
        }

        m_isOpen = !m_isOpen;
    }
    /// <summary>
    /// 是否开启组件功能
    /// </summary>
    public void IsOpenlight()
    {
        for (int i = 0; i < m_list.Count; i++)
        {
            m_list2[i].enabled = m_isOpen;
        }

        m_isOpen = !m_isOpen;
    }

    /// <summary>
    ///=======IsOpenDebug方法功能：是否开启测试UI=======
    /// </summary>
    public void IsOpenDebug()
    {
        m_Panel.active=m_isOpen;
        m_isOpen = !m_isOpen;
    }
}
