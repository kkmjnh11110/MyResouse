/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/21 13:29:27
*Description:  是否开启Debug界面
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// using UnityEngine.Rendering.PostProcessing;

public class DebugUI : MonoBehaviour
{

    /// <summary> m_isBloom功能:是否开启bloom </summary>
    private bool m_isBloom = false;

    /// <summary> m_gameobjBloom功能:bloom对象 </summary>
    public GameObject m_gameobjBloom;

    public List<GameObject> list;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    /// <summary>
    ///=======IsBloom方法功能：隐藏显示布鲁姆效果=======
    /// </summary>

    public void IsBloom()
    {
        if (m_isBloom)
        {
            // m_gameobjBloom.GetComponent<UnityStandardAssets.CinematicEffects.Bloom>().enabled = true;

            for (int i = 0; i < list.Count; i++)
            {
                list[i].SetActive(true);
            }
        }
        else
        {
            // m_gameobjBloom.GetComponent<UnityStandardAssets.CinematicEffects.Bloom>().enabled = false;
            for (int i = 0; i < list.Count; i++)
            {
                list[i].SetActive(false);
            }
        }
        m_isBloom = !m_isBloom;
    }
}
