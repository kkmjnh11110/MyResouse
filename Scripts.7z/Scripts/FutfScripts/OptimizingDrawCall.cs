/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  2D_IsoTilemaps_Project
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/13 16:06:38
*Description:  场景优化
*/

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;

public class OptimizingDrawCall : MonoBehaviour
{
    #region 变量
    /// <summary>
    /// 需要遍历这个对象的所有子物体(作用:遍历子物体后设置render的enable值来减少drawcall)
    /// </summary>
    public GameObject m_AllMap;

    /// <summary>
    /// 遍历的结果数组
    /// </summary>
    //public List<Transform> ChileArray;

    public GameObject m_AllCollider;

    /// <summary>
    /// 相机坐标
    /// </summary>
    private Vector2 m_tp;
    #endregion

    /// <summary>
    /// Fixeds the update.
    /// </summary>
    void FixedUpdate()
    {
        //遍历所有的子物体以及孙物体，并且遍历包含本身（地形）
        for (int i = 0; i < m_AllMap.GetComponentsInChildren<Transform>(true).Length; i++)
        {

            Transform children = m_AllMap.GetComponentsInChildren<Transform>()[i];//遍历到所有子对象

            //动态添加脚本（遮挡剔除）
            if (!children.gameObject.GetComponent<OptimizTileMap>())
            {
                children.gameObject.AddComponent<OptimizTileMap>();
            }

            if (children.GetComponent<TilemapRenderer>())
            {
                children.GetComponent<TilemapRenderer>().allowOcclusionWhenDynamic = true;
                children.GetComponent<TilemapRenderer>().enabled = false;
            }

        }
        //遍历所有的子物体以及孙物体，并且遍历包含本身(物件)
        for (int i = 0; i < m_AllCollider.GetComponentsInChildren<Transform>(true).Length; i++)
        {

            Transform colliderChildren = m_AllCollider.GetComponentsInChildren<Transform>()[i];//遍历到所有子对象
            SpriteRenderer tr = m_AllCollider.GetComponentsInChildren<Transform>()[i].GetComponent<SpriteRenderer>();//遍历到所有子对象上的render组件
            Vector2 cp = colliderChildren.transform.position;//子对象坐标
            if (tr)
            {

                if (((m_tp.x - 333.5) < cp.x) && (cp.x < (m_tp.x + 333.5)) && ((m_tp.y - 667) < cp.x) && (cp.x < (m_tp.y + 667)))
                {
                    tr.enabled = false;
                    //print("删除");
                }
                else
                {
                    tr.enabled = true;
                }

            }
        }

    }


    // Start is called before the first frame update
    void Start()
    {
        m_tp = transform.position;//相机坐标
        //children.transform.parent = root.transform;
        //StaticBatchingUtility.Combine(m_AllCollider);
    }

    #region 无用代码


    //// Update is called once per frame
    //void Update()
    //{

    //}

    #endregion
}
