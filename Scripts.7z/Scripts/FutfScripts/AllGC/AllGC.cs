/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  Dxcb3
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/06/03 11:15:57
*Description:   
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllGC : MonoBehaviour
{
    public List<Component> m_component;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Init());
    }

    IEnumerator Init()
    {
        yield return StartCoroutine(init1());
        Debug.Log("init1 finish");
        yield return StartCoroutine(init2());
        Debug.Log("init2 finish");
        yield return StartCoroutine(init3());
        Debug.Log("init3 finish");
    }
    IEnumerator init1()
    {
        yield return new WaitForSeconds(0.001f);//
    }
    IEnumerator init2()
    {
        yield return new WaitForSeconds(0.001f);//
    }
    IEnumerator init3()
    {
        yield return new WaitForSeconds(0.001f);//
    }
    // Update is called once per frame
    void Update()
    {
        
    }

    public void AllGCFun()
    {
        for (int i = 0; i < m_component.Count; i++)
        {
            if (m_component[i].name=="")
            {
                
            }
            print("m_component[i].name:"+m_component[i].ToString());
        }
    }

}
