/**
*Copyright(C) 2019 by DefaultCompany
*All rights reserved.
*ProductName:  2D_IsoTilemaps_Project
*Author:       futf-Tony
*Version:      1.0
*UnityVersion: 2018.3.13f1
*CreateTime:   2019/05/14 10:47:31
*Description:   
*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class OptimizTileMap : MonoBehaviour
{
    // Start is called before the first frame update
    //void Start()
    //{

    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}


    /// <summary>
    /// =======���ɼ�ʱ��������Ϊ=======
    /// </summary>
    void OnBecameVisible()
    {
        print(gameObject.name + ":����");
        if (transform.GetComponent<TilemapRenderer>())
        {
            transform.GetComponent<TilemapRenderer>().enabled = true;
        }

    }



    /// <summary>
    /// =======�����ɼ�ʱ��������Ϊ=======
    /// </summary>
    private void OnBecameInvisible()
    {
        print(gameObject.name + ":����");
        if (transform.GetComponent<TilemapRenderer>())
        {
            transform.GetComponent<TilemapRenderer>().enabled = false;

        }
    }

}
