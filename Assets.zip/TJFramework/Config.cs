﻿

namespace TJ
{
    public class Config
    {
        //打包规则描述文件路径
        public const string AssetBundleBuildRulePath = "Assets/TJFramework/AssetBundleBuilder/BuildRuleTemplate.json";
        //Xlua生成路径
        // public const string XluaGeneratePath = "Assets/XLua/Gen";
        //打包AB包路径(当前不考虑热更新的情况)
        public const string AB_Build_Path = "Assets/StreamingAssets/assetbundles";
        //打包AB包路径(PC热更)
        // public const string PC_StreamingAssets_Path = "Build/Windows/dungeon3_Data/StreamingAssets/assetbundles";
        //打包AB包路径(PC外部)
        public const string AB_Build_External_Path_PC = "StreamingAssetsData/Windows/assetbundles";
        //打包AB包路径(Android外部)
        public const string AB_Build_External_Path_Android = "StreamingAssetsData/Android/assetbundles";
        //打包AB包路径(IOS外部)
        public const string AB_Build_External_Path_IOS = "StreamingAssetsData/IOS/assetbundles";

    };
}
