using System;
using UnityEngine;
using XLua;

namespace TJ {
    public class Collider2DLBehaviour : LBehaviour {
        Action<LuaTable, Collision2D> cbEnter;
        Action<LuaTable, Collision2D> cbExit;
        Action<LuaTable, Collision2D> cbStay;

        Action<LuaTable, Collider2D> cbEnter2;
        Action<LuaTable, Collider2D> cbExit2;
        Action<LuaTable, Collider2D> cbStay2;

        protected override void BindAction() {
            Collider2D collider = this.gameObject.GetComponent<Collider2D>();
            if (collider == null || luaInst == null) {
                Debug.LogError("Collider2DLBehaviour can't find collider2d comp.");
                return;
            }
            if (!collider.isTrigger) {
                luaInst.Get("OnCollisionEnter2D", out cbEnter);
                luaInst.Get("OnCollisionExit2D", out cbExit);
                luaInst.Get("OnCollisionStay2D", out cbStay);
            } else {
                luaInst.Get("OnTriggerEnter2D", out cbEnter2);
                luaInst.Get("OnTriggerExit2D", out cbExit2);
                luaInst.Get("OnTriggerStay2D", out cbStay2);

            }

        }

        protected override void UnbindAction() {
            cbEnter = null;
            cbExit = null;
            cbStay = null;
            cbEnter2 = null;
            cbExit2 = null;
            cbStay2 = null;
        }

        void OnCollisionEnter2D(Collision2D c) {
            if (cbEnter != null)
                cbEnter(luaInst, c);
        }

        void OnCollisionExit2D(Collision2D c) {
            if (cbExit != null)
                cbExit(luaInst, c);
        }
        void OnCollisionStay2D(Collision2D c) {
            if (cbStay != null)
                cbStay(luaInst, c);
        }
        void OnTriggerEnter2D(Collider2D c) {
            if (cbEnter2 != null)
                cbEnter2(luaInst, c);
        }

        void OnTriggerExit2D(Collider2D c) {
            if (cbExit2 != null)
                cbExit2(luaInst, c);
        }
        void OnTriggerStay2D(Collider2D c) {
            if (cbStay2 != null)
                cbStay2(luaInst, c);
        }

    }
}