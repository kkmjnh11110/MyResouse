using System;
using UnityEngine;
using XLua;

namespace TJ {
    public class AnimationEventLBehaviour : LBehaviour {
        Action<LuaTable> cbOnDisable;
        Action<LuaTable> cbOnEnable;
        Action<LuaTable, AnimationEvent> cbOnAniEvent;
        Animator ani;
        protected override void BindAction() {
            luaInst.Get("OnDisable", out cbOnDisable);
            luaInst.Get("OnEnable", out cbOnEnable);
            luaInst.Get("OnAniEvent", out cbOnAniEvent);
            ani = this.gameObject.GetComponent<Animator>();
        }

        protected override void UnbindAction() {
            cbOnDisable = null;
            cbOnEnable = null;
            cbOnAniEvent = null;
        }

        public void AddAniEvent(string clip_name) {
            if (ani == null)
                return;
            AnimationClip[] clips = ani.runtimeAnimatorController.animationClips;
            for (int i = 0; i < clips.Length; i++) {
                if (clips[i].name == clip_name) {
                    if (clips[i].events.Length == 0) {
                        AnimationEvent evt = new AnimationEvent();
                        evt.time = clips[i].length;
                        evt.stringParameter = clip_name;
                        evt.functionName = "OnAniEvent";
                        clips[i].AddEvent(evt);
                    }
                    break;
                }
            }
        }

        public void ClearAniEvent(string clip_name) {
            if (ani == null)
                return;
            AnimationClip[] clips = ani.runtimeAnimatorController.animationClips;
            for (int i = 0; i < clips.Length; i++) {
                if (clips[i].name == clip_name) {
                    if( clips[i].events.Length > 0 ){
                        clips[i].events = new AnimationEvent[0];
                    }
                    break;
                }
            }
        }

        void OnDisable() {
            CallLua(cbOnDisable);
        }

        void OnEnable() {
            CallLua(cbOnEnable);
        }

        void OnAniEvent(AnimationEvent evt) {

            cbOnAniEvent(luaInst, evt);
        }
    }
}