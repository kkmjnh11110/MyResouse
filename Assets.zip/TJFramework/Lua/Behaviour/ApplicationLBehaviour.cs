﻿using System;
using UnityEngine;
using XLua;

namespace TJ
{
    public class ApplicationLBehaviour : LBehaviour
    {
        Action<bool> cbFocus;
        Action<bool> cbPause;

        protected override void BindAction()
        {
            luaInst.Get("OnApplicationFocus", out cbFocus);
            luaInst.Get("OnApplicationPause", out cbPause);
        }

        protected override void UnbindAction()
        {
            cbFocus = null;
            cbPause = null;
        }

        void OnApplicationFocus(bool hasFocus)
        {
            if (luaInst == null || cbFocus == null)
                return;

            cbFocus(hasFocus);
        }

        void OnApplicationPause(bool pauseStatus)
        {
            if (luaInst == null || cbPause == null)
                return;

            cbPause(pauseStatus);
        }
    }
}
