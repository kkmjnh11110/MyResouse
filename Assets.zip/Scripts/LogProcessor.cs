using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using TJ;
using UnityEngine;
using UnityEngine.Networking;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class LogData {
    public string log { get; set; }
    public string track { get; set; }
    public LogType type { get; set; }
}

public class AsyncRequestState{
    public HttpWebRequest request;
    public LogData log;
}

public class BugReportConfig {
    public string url { get; set; }
    public string buildv { get; set; }
    public string updatev { get; set; }
    public int aid { get; set; }
    public int uid { get; set; }
    public string client_b { get; set; }
    public string sign { get; set; }
    public int level { get; set; }
    public int cmd { get; set; }
}

public class LogProcessor {
    ConsoleUtils.ConsoleWindow console = null;

    private Queue<LogData> waitQueue = null;
    private Queue<LogData> procQueue = null;
    private Thread workThread = null;
    private BugReportConfig config = null;

    readonly object syncLock = new object();

    public LogProcessor(string conf) {
        Setup(conf);
        Application.logMessageReceivedThreaded += handleLogCallbackThreaded;
#if UNITY_EDITOR
        EditorApplication.playModeStateChanged += HandleOnPlayModeChanged;
#endif
        waitQueue = new Queue<LogData>();
        procQueue = new Queue<LogData>();
        workThread = new Thread(Processor);
        workThread.Start();
        if (Application.platform == RuntimePlatform.WindowsPlayer) {
            console = new ConsoleUtils.ConsoleWindow();
            console.Initialize();
            // Console.OutputEncoding = System.Text.Encoding.Default;
            Console.WriteLine(Console.OutputEncoding.ToString());
            // Console.WriteLine(Console.OutputEncoding.CodePage);
            Debug.Log("debug console start.");
        }
    }
    public void Clear() {
        if (console != null) {
            console.Shutdown();
            console = null;
        }
        Application.logMessageReceivedThreaded -= handleLogCallbackThreaded;
#if UNITY_EDITOR
        EditorApplication.playModeStateChanged -= HandleOnPlayModeChanged;
#endif
        workThread.Abort();
    }

    public void Setup(string conf) {
        config = null;
        try {
            config = JsonConvert.DeserializeObject<BugReportConfig>(conf);
        } catch (JsonException e) {
            Debug.LogError(e.ToString());
            return;
        }

    }

    void OutputConsole(string log, string stackTrace, LogType type) {

        if (console != null) {
            int thread_id = Thread.CurrentThread.ManagedThreadId;
            ConsoleColor color = ConsoleColor.Gray;
            if (type == LogType.Warning)
                color = ConsoleColor.Yellow;
            else if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
                color = ConsoleColor.Red;
            Console.ForegroundColor = color;
            string time = "[Thread" + thread_id + "][" + DateTime.Now.ToLongTimeString().ToString() + "]";
            Console.WriteLine(time + " " + log);
            if (type == LogType.Error || type == LogType.Exception)
                Console.WriteLine(stackTrace);
            Console.ResetColor();
        }

    }

    public void Processor() {
        while (true) {
            if (procQueue.Count == 0) {
                lock(syncLock) {
                    while (waitQueue.Count == 0)
                        Monitor.Wait(syncLock);
                    Queue<LogData> tmp = procQueue;
                    procQueue = waitQueue;
                    waitQueue = tmp;
                }
            } else {
                while (procQueue.Count > 0) {
                    LogData log = procQueue.Dequeue();
                    // do somthing.
                    // string one = log.log + "\n" + log.track;
                    if (config.aid > 0) {
                        var p = new { buildv = config.buildv, updatev = config.updatev, content = log.log + "\n" + log.track, err_t = (log.type == LogType.Exception ? 1 : 0) };
                        // var one = new { config.cmd, p };
                        string msg = "[" + Convert.ToString(config.cmd) + "," + JsonConvert.SerializeObject(p) + "]";
                        if (SocketManager.Instance.BugReport(msg) && log.type != LogType.Exception)
                            continue;
                    }
                    PostBugAsync(log);
                }
            }
        }
    }

    private string BuildPostData(LogData one) {
        string ts = Convert.ToString(DateTimeOffset.UtcNow.ToUnixTimeSeconds());
        string sign = ts + config.sign;
        var md5 = System.Security.Cryptography.MD5.Create();
        var md5bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(sign));
        sign = System.BitConverter.ToString(md5bytes).Replace("-", "").ToUpper();
        int type = 0;
        if (one.type == LogType.Warning)
            type = 1;
        else if (one.type == LogType.Error)
            type = 2;
        else
            type = 3;
        var postData = new {
            version = config.updatev,
            aid = config.aid,
            uid = config.uid,
            err_type = type,
            content = one.log + "\n" + one.track,
            client_b = config.client_b,
            ts = ts,
            sign = sign
        };
        return JsonConvert.SerializeObject(postData);
    }

    void PostBug(LogData one) {
        string postData = BuildPostData(one);
        try {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(config.url);
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Proxy = null;
            // request.ServicePoint.ConnectionLimit = 10;
            request.Timeout = 10 * 1000;
            var stream = new StreamWriter(request.GetRequestStream());
            stream.Write(postData);
            stream.Close();
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream streamResponse = response.GetResponseStream();
            StreamReader streamRead = new StreamReader(streamResponse);
            string responseString = streamRead.ReadToEnd();
            OutputConsole("logProcessor post ok response:" + responseString, "", LogType.Warning);
        } catch (WebException e) {
            OutputConsole("logProcessor post err:" + e.Message, "", LogType.Exception);
        } catch (Exception e) {
            OutputConsole("logProcessor post err:" + e.Message, "", LogType.Exception);
        }
    }

    void PostBugAsync(LogData one) {
        try {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(config.url);
            AsyncRequestState postState = new AsyncRequestState();
            postState.log = one;
            postState.request = request;
            request.Method = "POST";
            request.ContentType = "application/json";
            request.Proxy = null;
            // request.ServicePoint.ConnectionLimit = 10;
            request.Timeout = 10 * 1000;
            request.BeginGetRequestStream(new AsyncCallback(GetRequestStreamCallback), postState);
        } catch (WebException e) {
            OutputConsole("logProcessor postAsync err:" + e.Message, "", LogType.Exception);
        } catch (Exception e) {
            OutputConsole("logProcessor postAsync err:" + e.Message, "", LogType.Exception);
        }
    }

    private void GetRequestStreamCallback(IAsyncResult asynchronousResult) {
        try {
            AsyncRequestState state = (AsyncRequestState)asynchronousResult.AsyncState;
            HttpWebRequest request = state.request;
            var stream = new StreamWriter(request.EndGetRequestStream(asynchronousResult));
            string postData = BuildPostData(state.log);
            stream.Write(postData);
            stream.Close();
            request.BeginGetResponse(new AsyncCallback(GetResponseCallback), request);
        } catch (WebException e) {
            OutputConsole("logProcessor postAsync GetRequestStreamCallback err:" + e.Message, "", LogType.Exception);
        }
    }
    private void GetResponseCallback(IAsyncResult asynchronousResult) {
        try {
            HttpWebRequest request = (HttpWebRequest)asynchronousResult.AsyncState;
            // End the operation
            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(asynchronousResult);
            Stream streamResponse = response.GetResponseStream();
            StreamReader streamRead = new StreamReader(streamResponse);
            string responseString = streamRead.ReadToEnd();
            OutputConsole("logProcessor postAsync ok response:" + responseString, "", LogType.Warning);
            // Close the stream object
            streamResponse.Close();
            streamRead.Close();
            // Release the HttpWebResponse
            response.Close();
        } catch (WebException e) {
            OutputConsole("logProcessor postAsync GetResponseCallback err:" + e.Message, "", LogType.Exception);
        }

    }

    void RecordOneLog(LogData log) {
        lock(syncLock) {
            waitQueue.Enqueue(log);
            Monitor.Pulse(syncLock);
        }
    }

    void handleLogCallbackThreaded(string log, string stackTrace, LogType type) {
        OutputConsole(log, stackTrace, type);
        if (config == null)
            return;
        if (config.level == 0) {
            if (type != LogType.Exception && type != LogType.Assert)
                return;
        } else if (config.level == 1) {
            if (type != LogType.Error && type != LogType.Exception && type != LogType.Assert)
                return;
        } else {
            if (type == LogType.Log)
                return;
        }
        LogData one = new LogData();
        one.log = log;
        one.track = stackTrace;
        one.type = type;
        RecordOneLog(one);

    }
#if UNITY_EDITOR
    private void HandleOnPlayModeChanged(PlayModeStateChange state) {
        if (state == PlayModeStateChange.ExitingPlayMode) {
            Clear();
        }
    }
#endif
}