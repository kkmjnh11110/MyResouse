﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using TJ;
using UnityEngine;
using WebSocketSharp;

// 对websocket-sharp类的封装，方便使用。

public class WebSocketWrapper {
    public struct CALLBACK {
        public Action<string> onOpen;
        public Action<int, string> onClose;
        public Action<string> onMsg;
        public Action<string> onErr;
    }
    public struct STATECMD {
        public enum CMD { OPEN, CLOSED, ERR, DATA }
        public int cmd;
        public int code;
        public string info;
        public byte[] data;
    }
    WebSocketSharp.WebSocket _webSocket;
    readonly Queue<STATECMD> _cmds = new Queue<STATECMD>();
    readonly object _recvLock = new object();
    public WebSocketWrapper(string uri, CALLBACK cb) {
        Uri = new Uri(uri);
        callback = cb;
        if (!Uri.Scheme.Equals("ws") && !Uri.Scheme.Equals("wss")) {
            Debug.Log("websocket invalid uri scheme! uri:" + Uri.ToString() + " scheme:" + Uri.Scheme);
        }
    }
    public Uri Uri { set; get; }

    CALLBACK callback;

    public void Connect(bool async = true) {
        if (isConnected())
            return;
        if (_webSocket == null) {
            _webSocket = new WebSocketSharp.WebSocket(Uri.ToString());
            _webSocket.Log.Level = LogLevel.Debug;
            _webSocket.Compression = CompressionMethod.Deflate;
            //_webSocket.IgnoreExtensions = true;
            string origin = Uri.ToString();
            origin = origin.Substring(0, origin.LastIndexOf('/'));
            // Debug.Log("origin:"+origin);
            _webSocket.Origin = origin;

            _webSocket.EmitOnPing = true;
            _webSocket.OnOpen += (sender, e) => {
                string t = "websocket connected! uri:" + Uri.ToString();
                // Debug.Log(t);
                lock(_recvLock) {
                    STATECMD one = new STATECMD { cmd = (int)STATECMD.CMD.OPEN, code = 0, info = t };
                    _cmds.Enqueue(one);
                }
            };
            _webSocket.OnError += (sender, e) => {
                lock(_recvLock) {
                    STATECMD one = new STATECMD { cmd = (int)STATECMD.CMD.ERR, code = 0, info = e.Message };
                    _cmds.Enqueue(one);
                }
            };
            _webSocket.OnMessage += (sender, e) => {
                if (e.IsPing)
                    return;
                lock(_recvLock) {
                    STATECMD one = new STATECMD { cmd = (int)STATECMD.CMD.DATA, code = 0, info = "", data = e.RawData };
                    _cmds.Enqueue(one);
                }
            };
            _webSocket.OnClose += (sender, e) => {
                lock(_recvLock) {
                    STATECMD one = new STATECMD { cmd = (int)STATECMD.CMD.CLOSED, code = e.Code, info = e.Reason };
                    _cmds.Enqueue(one);
                }
            };
        }
        if (async)
            _webSocket.ConnectAsync();
        else
            _webSocket.Connect();
    }

    public bool isConnected() {
        return (_webSocket != null && (_webSocket.ReadyState == WebSocketState.Open || _webSocket.ReadyState == WebSocketState.Closing));
    }

    public void Send(string data) {
        if (isConnected())
            _webSocket.Send(data);
    }

    public void SendAsync(string data, Action<bool> completed) {
        _webSocket.SendAsync(data, completed);

    }

    public void Close(ushort code = 1000, string reason = "user close") {
        if (isConnected()) {
            _webSocket.Close(code, reason);
        }
    }

    void ProcCmdQuery() {
        while (true) {
            if (_cmds.Count == 0)
                return;
            lock(_recvLock) {
                STATECMD one = _cmds.Dequeue();
                // Debug.Log("cmd:" + one.cmd + " info:" + one.info);
                if (one.cmd == (int)STATECMD.CMD.OPEN) {
                    // string t = "websocket connected! info:"+one.info;
                    if (callback.onOpen != null) {
                        callback.onOpen(one.info);
                    }
                } else if (one.cmd == (int)STATECMD.CMD.CLOSED) {
                    Debug.Log("websocket closed code:" + one.code + " reason:" + one.info);
                    if (callback.onClose != null) {
                        callback.onClose(one.code, one.info);
                    }
                } else if (one.cmd == (int)STATECMD.CMD.ERR) {
                    Debug.Log("websocket error:" + one.info);
                    if (callback.onErr != null)
                        callback.onErr(one.info);
                } else if (one.cmd == (int)STATECMD.CMD.DATA) {
                    //Debug.Log("onMsg:"+e.Data);
                    if (callback.onMsg != null)
                        callback.onMsg(Encoding.UTF8.GetString(one.data));
                }
            }
        }
    }

    public void Update() {
        ProcCmdQuery();
    }

    public void Clear() {
        Close();
        // remove all callback
        callback = new CALLBACK();
        _webSocket = null;
    }

}