using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using TJ;
using UnityEngine;
using UnityEngine.Networking;

// socket类，封装了一个websocket对象，方便收发消息。
public class Socket {
    WebSocketWrapper _socket;
    public Socket(WebSocketWrapper ws) {
        _socket = ws;
    }

    // 发送消息
    public void Send(string data) {
        _socket.Send(data);
    }

    // 是否连接成功
    public bool isConnected() {
        return _socket.isConnected();
    }

    // 建立连接
    public void Connect() {
        _socket.Connect();
    }

    // 关闭连接
    public void Close() {
        _socket.Close();
    }

    public void Clear() {

        _socket.Clear();
        _socket = null;
    }

    // 当前连接uri
    public string Uri() {
        return _socket.Uri.ToString();
    }

    // 更新（每帧调用)
    public void Update() {
        _socket.Update();
    }

    // 发送http请求
    public void SendHttpRequest(string uri, string data, Action<long, string> cb) {
        SocketManager.Instance.SendHttpRequest(uri, data, cb);
    }

}

// 网络连接管理类。（创建和管理所有连接）
public class SocketManager : Singleton<SocketManager>, IDisposable {

    protected SocketManager() { }
    List<Socket> sockets = new List<Socket>();

    readonly object reporterLock = new object();
    private Queue<string> bugQueue = new Queue<string>();

    // 创建socket对象，需要提供ws/wss uri地址，以及消息回调函数。
    public Socket Create(string uri, Action<string> _onOpen, Action<int, string> _onClose, Action<string> _onMsg, Action<string> _onErr) {
        Socket socket = Get(uri);
        if (socket != null)
            return socket;
        WebSocketWrapper.CALLBACK cb = new WebSocketWrapper.CALLBACK();
        cb.onClose = _onClose;
        cb.onOpen = _onOpen;
        cb.onMsg = _onMsg;
        cb.onErr = _onErr;
        socket = new Socket(new WebSocketWrapper(uri, cb));
        sockets.Add(socket);
        return socket;
    }

    // 返回给定uri对应的socket对象
    public Socket Get(string uri) {
        for (int i = 0; i < sockets.Count; i++) {
            if (sockets[i].Uri() == uri) {
                return sockets[i];
            }
        }
        return null;
    }

    // 移除一个socket对象
    public void Remove(Socket socket) {
        socket.Clear();
        sockets.Remove(socket);
    }

    // 遍历每个连接调用更新(需要每帧调用)
    public void Update() {
        for (int i = sockets.Count - 1; i >= 0; i--) {
            int count = sockets.Count;
            if (count == 0)
                break;
            if (i >= count)
                i = count - 1;
            sockets[i].Update();
        }
        ProcBugQueue();
    }

    void ProcBugQueue() {
        lock(reporterLock) {
            while (bugQueue.Count > 0) {
                string one = bugQueue.Dequeue();
                if (sockets.Count > 0) {
                    Debug.Log("bug report:" + one);
                    sockets[0].Send(one);
                }
            }
        }
    }

    // 清理所有已经注册的连接
    public void Clear() {
        for (int i = 0; i < sockets.Count; i++) {
            sockets[i].Clear();
        }
        sockets.Clear();
    }

    public void Dispose() {
        Clear();
    }

    // http 请求
    public void SendHttpRequest(string uri, string data, Action<long, string> cb) {
        StartCoroutine(PostHttpQuery(uri, data, cb));
    }

    private IEnumerator PostHttpQuery(string uri, string data, Action<long, string> cb) {
        UnityWebRequest www = null;
        www = new UnityWebRequest(uri, "POST");
        byte[] postBytes = System.Text.Encoding.UTF8.GetBytes(data);
        www.uploadHandler = (UploadHandler)new UploadHandlerRaw(postBytes);
        www.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        www.SetRequestHeader("Content-Type", "application/json");
        yield return www.SendWebRequest();
        if (www.error != null) {
            cb(www.responseCode != 0 ? www.responseCode : -1, www.error);
        } else {
            cb(0, www.downloadHandler.text);
        }
    }

    public bool BugReport(string one) {
        if (sockets.Count == 0)
            return false;
        lock(reporterLock) {
            bugQueue.Enqueue(one);
            return true;
        }
    }

}