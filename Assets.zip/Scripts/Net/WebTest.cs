﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TJ;

public class WebTest : MonoBehaviour
{
     List<Socket> sockets = new List<Socket>();

    float timer { get;set; }
    // Start is called before the first frame update
    void Start()
    {
        sockets.Add(SocketManager.Instance.Create("ws://localhost:8000/",onOpen,onClose,onMessage,onErr ));
        //sockets.Add(TJ.SocketManager.Instance.Create("ws://localhost:8001/",onOpen,onClose,onMessage,onErr ));
        
    }

    // Update is called once per frame
    void Update()
    {
        SocketManager.Instance.Update();

        if( Time.fixedTime - timer > 5 ){
            timer = Time.fixedTime;
            sockets.ForEach( (one) => {
                if( one.isConnected() ){
                    string info = "send one test string. uri:"+one.Uri();
                    one.Send(info);
                    Debug.Log(info);
                    one.Close();
                }
                else{
                    one.Connect();
                }
            });
        }

    }

    void onOpen(string info){
        Debug.Log("onOpen:"+info);
    }

    void onClose(int errno,string reason){
        Debug.Log("onClose code:"+errno+" reason:"+reason);
    }

    void onMessage(string msg){
        Debug.Log("onMsg:"+msg);
    }

    void onErr( string info){
        Debug.Log("onErr:"+info);
    }
}
