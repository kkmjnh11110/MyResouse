using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;
using TJ;
using UnityEngine;

namespace MyAstar {
    public class Node {
        //Node's position in the grid
        public int x;
        public int y;
        public int z;

        //Node's costs for pathfinding purposes
        public float hCost;
        public float gCost;

        public float fCost {
            get //the fCost is the gCost+hCost so we can get it directly this way
            {
                return gCost + hCost;
            }
        }

        public Node parentNode;
        public bool Walkable = true;
        public UInt32 userParam = 0;

        //Types of nodes we can have, we will use this later on a case by case examples
        public NodeType nodeType;
        public enum NodeType {
            ground,
            air
        }

        public Vector3 position {
            get {
                return PathFindManager.Instance.GridToLocal(new Vector3(x, y, z));
            }
        }
    }

    public class GridBase {
        public int maxX = 0;
        public int maxY = 0;
        public int maxZ = 0;

        //Offset relates to the world positions only
        public float offsetX = 1;
        public float offsetY = 1;
        public float offsetZ = 1;

        public float node_size = 0;

        public Node[, , ] grid;

        private byte[] external_blocks = null;
        bool is_APFP_block = false;

        public void Init(int grid_x_size, int grid_y_size, float node_s, bool random_block = false) {
            maxX = grid_x_size;
            maxY = grid_y_size;
            maxZ = 1;
            offsetX = offsetY = offsetZ = node_size = node_s;
            grid = new Node[maxX, maxY, maxZ];
            for (int x = 0; x < maxX; x++) {
                for (int y = 0; y < maxY; y++) {
                    for (int z = 0; z < maxZ; z++) {
                        //Apply the offsets and create the world object for each node
                        float posX = x * offsetX;
                        float posY = y * offsetY;
                        float posZ = z * offsetZ;
                        //Create a new node and update it's values
                        Node node = new Node();
                        node.x = x;
                        node.y = y;
                        node.z = z;

                        if (random_block) {
                            // random add some blocks
                            if (UnityEngine.Random.Range(0, 100) < 40) {
                                node.Walkable = false;
                                // SetNodeColor(node,Color.red);
                            }
                        }

                        //then place it to the grid
                        grid[x, y, z] = node;
                    }
                }
            }
        }
        public Node GetNode(int x, int y, int z) {

            if (x < maxX && x >= 0 &&
                y >= 0 && y < maxY &&
                z >= 0 && z < maxZ) {
                return grid[x, y, z];
            }

            return null;
        }

        public bool NodeWalkable(Node n) {
            return n != null && checkExternalBlock(n.x, n.y) && n.Walkable;
        }

        public UInt32 getNodeUserParam(bool walkable, int x, int y) {
            Node node = GetNode(x, y, 0);
            if (node != null) {
                if (node.Walkable == walkable)
                    return node.userParam;
            }
            return 0;
        }

        public void SetExternalBlockData(byte[] b, bool APFP) {
            external_blocks = b;
            is_APFP_block = APFP;
        }
        public bool checkExternalBlock(int x, int y) {
            if (external_blocks == null)
                return true;
            int idx = y * maxX + x;
            Int32 total = BitConverter.ToInt32(external_blocks, 0);
            if (idx < 0 || idx >= total)
                return false;
            int offset = 0;
            if (is_APFP_block) {
                // astar path project 使用的地图格式偏移
                offset = sizeof(Int32) + (sizeof(Int32) + sizeof(UInt32) + sizeof(Int32) * 3 + sizeof(UInt16)) * idx;
                UInt32 flags = BitConverter.ToUInt32(external_blocks, offset + sizeof(Int32));
                return (flags & 1) != 0;
            } else {
                // 自定义格式
                offset = sizeof(Int32) + (sizeof(byte)) * idx;
                byte flags = external_blocks[offset];
                return flags != 0;
            }
        }

        public Node GetNodeFromVector3(Vector3 pos) {
            int x = Mathf.RoundToInt(pos.x);
            int y = Mathf.RoundToInt(pos.y);
            int z = Mathf.RoundToInt(pos.z);

            Node retVal = GetNode(x, y, z);
            return retVal;
        }

        public Node FindNearestWalkableNode(Vector2 pos, Vector2 orig, float maxNearestNodeDistance = 10, int getNearestForceOverlap = 2) {
            int z = 0;
            int x = (int)Mathf.Clamp(pos.x, 0, maxX - 1);
            int y = (int)Mathf.Clamp(pos.y, 0, maxY - 1);
            Node n = GetNode(x, y, z);
            if (NodeWalkable(n))
                return n;
            Node minNode = null;
            float minDist = float.PositiveInfinity;
            int overlap = getNearestForceOverlap;
            // find nearest node in given distance
            for (int w = 1;; w++) {
                if (w > maxNearestNodeDistance)
                    break;
                bool anyInside = false;
                int nx;
                int ny = y + w;
                // Side 1 on the square
                for (nx = x - w; nx <= x + w; nx++) {
                    if (nx < 0 || ny < 0 || nx >= maxX || ny >= maxY)
                        continue;
                    anyInside = true;
                    Node t = GetNode(nx, ny, z);
                    if (NodeWalkable(t)) {
                        float dist = (orig.x - nx) * (orig.x - nx) + (orig.y - ny) * (orig.y - ny);
                        if (dist < minDist) {
                            minDist = dist;
                            minNode = t;
                        }
                    }
                }
                ny = y - w;
                // Side 2 on the square
                for (nx = x - w; nx <= x + w; nx++) {
                    if (nx < 0 || ny < 0 || nx >= maxX || ny >= maxY)
                        continue;
                    anyInside = true;
                    Node t = GetNode(nx, ny, z);
                    if (NodeWalkable(t)) {
                        float dist = (orig.x - nx) * (orig.x - nx) + (orig.y - ny) * (orig.y - ny);
                        if (dist < minDist) {
                            minDist = dist;
                            minNode = t;
                        }
                    }
                }
                nx = x - w;
                // Side 3 on the square
                for (ny = y - w; ny <= y + w; ny++) {
                    if (nx < 0 || ny < 0 || nx >= maxX || ny >= maxY)
                        continue;
                    anyInside = true;
                    Node t = GetNode(nx, ny, z);
                    if (NodeWalkable(t)) {
                        float dist = (orig.x - nx) * (orig.x - nx) + (orig.y - ny) * (orig.y - ny);
                        if (dist < minDist) {
                            minDist = dist;
                            minNode = t;
                        }
                    }
                }
                nx = x + w;
                // side 4
                for (ny = y - w; ny <= y + w; ny++) {
                    if (nx < 0 || ny < 0 || nx >= maxX || ny >= maxY)
                        continue;
                    anyInside = true;
                    Node t = GetNode(nx, ny, z);
                    if (NodeWalkable(t)) {
                        float dist = (orig.x - nx) * (orig.x - nx) + (orig.y - ny) * (orig.y - ny);
                        if (dist < minDist) {
                            minDist = dist;
                            minNode = t;
                        }
                    }

                }
                // We found a suitable node
                if (minNode != null) {
                    // If we don't need to search more, just return
                    // Otherwise search for 'overlap' iterations more
                    overlap--;
                    if (overlap == 0) {
                        break;
                    }
                }
            }
            return minNode;
        }

        public void ForeachNode(Action<Node> cb) {
            for (int x = 0; x < maxX; x++) {
                for (int y = 0; y < maxY; y++) {
                    for (int z = 0; z < maxZ; z++) {
                        cb(grid[x, y, z]);
                    }
                }
            }
        }

        public void Clear() {
            external_blocks = null;
            grid = null;
            node_size = 0;
            maxX = maxY = maxZ = 0;
            offsetX = offsetY = offsetZ = 0;
        }
    }

    public class Pathfinder {
        GridBase gridBase;
        PathFindManager manager;
        public Node startPosition;
        public Node endPosition;

        public volatile bool jobDone = false;
        PathFindManager.PathfindingJobComplete completeCallback;
        int user_param = 0;
        public List<Vector3> foundPath = new List<Vector3>();
        bool path_in_local_coordinate = false;
        bool active_path_modifier = true;

        public bool is_trace_finder = false;
        int trace_check_range = 2;

        System.Threading.Timer threadTimer;
        Thread workThread;

        public void Start(bool use_thread, int timeout = 10) {
            if (use_thread) {
                if (is_trace_finder) {
                    workThread = new Thread(FindTrace);
                } else {
                    workThread = new Thread(FindPath);
                }
                threadTimer = new System.Threading.Timer(threadTimeout, null, timeout * 1000, 0);
                workThread.Start();
            } else {
                if (is_trace_finder)
                    FindTrace();
                else
                    FindPath();
            }
        }

        //Constructor
        public Pathfinder(Node start, Node target, PathFindManager.PathfindingJobComplete callback, bool local_coordinate, bool use_path_modifier) {
            startPosition = start;
            endPosition = target;
            completeCallback = callback;
            manager = PathFindManager.Instance;
            gridBase = manager.getGrid();
            path_in_local_coordinate = local_coordinate;
            active_path_modifier = use_path_modifier;
        }

        public void SetTraceParamCheck(int _user_param, int check_range) {
            is_trace_finder = true;
            trace_check_range = check_range;
            user_param = _user_param;
        }

        private void FindPath() {
            List<Node> path = FindPathActual(startPosition, endPosition);
            foundPath = BuildFindedPath(path);
            jobDone = true;
        }

        private void threadTimeout(object state) {
            Clear();
        }

        private List<Vector3> BuildFindedPath(List<Node> path) {
            List<Vector3> p = new List<Vector3>();

            if (path.Count == 0)
                return p;
            // List<Vector2> grid_p = new List<Vector2>();
            foreach (Node n in path) {
                p.Add(new Vector3((n.x + 0.5f) * gridBase.node_size, (n.y + 0.5f) * gridBase.node_size, n.z));
                // grid_p.Add(new Vector2(n.x, n.y));
            }

            Path tp = new Path();
            tp.vectorPath = p;
            tp.path = path;
            // foundPath.grid_path = grid_p;
            if (active_path_modifier)
                manager.RunModifiers(ModifierPass.PostProcess, tp);
            if (!path_in_local_coordinate) {
                for (int i = 0; i < tp.vectorPath.Count; i++) {
                    tp.vectorPath[i] = manager.LocalToGrid(tp.vectorPath[i]);
                }
            }
            return tp.vectorPath;
        }

        private void FindTrace() {
            List<Node> path = FindPathActual(startPosition, endPosition);
            List<Vector2> trace = new List<Vector2>();
            Dictionary<int, bool> added = new Dictionary<int, bool>();
            for (int i = 0; i < path.Count; i++) {
                Node n = path[i];
                int sx = n.x - trace_check_range;
                int dx = n.x + trace_check_range;
                int sy = n.y - trace_check_range;
                int dy = n.y + trace_check_range;
                bool find = false;
                for (int x = sx; x <= dx; x++) {
                    for (int y = sy; y <= dy; y++) {
                        UInt32 p = gridBase.getNodeUserParam(false, x, y);
                        if (p != 0) {
                            find = true;
                            int high = (int)p >> 16;
                            int low = (int)p & 0xffff;
                            if (low == user_param && !added.ContainsKey(high)) {
                                // Debug.LogWarning("h:" + high + " l:" + low + " pos.x:" + x + " pos.y:" + y);
                                added.Add(high, true);
                                trace.Add(new Vector2(n.x, n.y));
                            }
                            break;
                        }
                    }
                    if (find) {
                        break;
                    }
                }
            }
            if (trace.Count > 0) {
                // add end pos 
                trace.Add(new Vector2(endPosition.x, endPosition.y));
                // use trace to refind path
                foundPath.Clear();
                for (int i = 0; i < trace.Count; i++) {
                    Node start = startPosition;
                    if (i > 0)
                        start = gridBase.GetNode((int)trace[i - 1].x, (int)trace[i - 1].y, 0);
                    Node end = gridBase.GetNode((int)trace[i].x, (int)trace[i].y, 0);
                    List<Vector3> t = BuildFindedPath(FindPathActual(start, end));
                    if (t.Count > 0)
                        foundPath.AddRange(t);
                }
            } else {
                foundPath = BuildFindedPath(path);
            }
            jobDone = true;
        }

        public void NotifyComplete() {
            if (completeCallback != null) {
                completeCallback(foundPath);
            }
        }

        public void Clear() {
            if (workThread != null && !jobDone){
                workThread.Abort();
                workThread = null;
            }
            if (threadTimer != null) {
                threadTimer.Dispose();
                threadTimer = null;
            }
            completeCallback = null;
            jobDone = true;
        }

        private List<Node> FindPathActual(Node start, Node target) {
            //Typical A* algorythm from here and on

            List<Node> foundPath = new List<Node>();

            //We need two lists, one for the nodes we need to check and one for the nodes we've already checked
            List<Node> openSet = new List<Node>();
            HashSet<Node> closedSet = new HashSet<Node>();

            //We start adding to the open set
            openSet.Add(start);

            while (openSet.Count > 0) {
                Node currentNode = openSet[0];

                for (int i = 0; i < openSet.Count; i++) {
                    //We check the costs for the current node
                    //You can have more opt. here but that's not important now
                    if (openSet[i].fCost < currentNode.fCost ||
                        (openSet[i].fCost == currentNode.fCost &&
                            openSet[i].hCost < currentNode.hCost)) {
                        //and then we assign a new current node
                        if (!currentNode.Equals(openSet[i])) {
                            currentNode = openSet[i];
                        }
                    }
                }

                //we remove the current node from the open set and add to the closed set
                openSet.Remove(currentNode);
                closedSet.Add(currentNode);

                //if the current node is the target node
                if (currentNode.Equals(target)) {
                    //that means we reached our destination, so we are ready to retrace our path
                    foundPath = RetracePath(start, currentNode);
                    break;
                }

                //if we haven't reached our target, then we need to start looking the neighbours
                foreach (Node neighbour in GetNeighbours(currentNode, true)) {
                    if (!closedSet.Contains(neighbour)) {
                        //we create a new movement cost for our neighbours
                        float newMovementCostToNeighbour = currentNode.gCost + GetDistance(currentNode, neighbour);

                        //and if it's lower than the neighbour's cost
                        if (newMovementCostToNeighbour < neighbour.gCost || !openSet.Contains(neighbour)) {
                            //we calculate the new costs
                            neighbour.gCost = newMovementCostToNeighbour;
                            neighbour.hCost = GetDistance(neighbour, target);
                            //Assign the parent node
                            neighbour.parentNode = currentNode;
                            //And add the neighbour node to the open set
                            if (!openSet.Contains(neighbour)) {
                                openSet.Add(neighbour);
                            }
                        }
                    }
                }
            }

            //we return the path at the end
            return foundPath;
        }

        private List<Node> RetracePath(Node startNode, Node endNode) {
            //Retrace the path, is basically going from the endNode to the startNode
            List<Node> path = new List<Node>();
            Node currentNode = endNode;

            while (currentNode != startNode) {
                path.Add(currentNode);
                //by taking the parentNodes we assigned
                currentNode = currentNode.parentNode;
            }

            //then we simply reverse the list
            path.Reverse();

            return path;
        }

        private List<Node> GetNeighbours(Node node, bool getVerticalneighbours = false) {
            //This is were we start taking our neighbours
            List<Node> retList = new List<Node>();

            for (int x = -1; x <= 1; x++) {
                for (int yIndex = -1; yIndex <= 1; yIndex++) {
                    for (int z = -1; z <= 1; z++) {
                        int y = yIndex;

                        //If we don't want a 3d A*, then we don't search the y
                        if (!getVerticalneighbours) {
                            y = 0;
                        }

                        if (x == 0 && y == 0 && z == 0) {
                            //000 is the current node
                        } else {
                            Node searchPos = new Node();

                            //the nodes we want are what's forward/backwars,left/righ,up/down from us
                            searchPos.x = node.x + x;
                            searchPos.y = node.y + y;
                            searchPos.z = node.z + z;

                            Node newNode = GetNeighbourNode(searchPos, false, node);

                            if (newNode != null) {
                                retList.Add(newNode);
                            }
                        }
                    }
                }
            }

            return retList;

        }

        private Node GetNeighbourNode(Node adjPos, bool searchTopDown, Node currentNodePos) {
            //this is where the meat of it is
            //We can add all the checks we need here to tweak the algorythm to our heart's content
            //but first let's start from the the usual stuff you'll see in A*

            Node retVal = null;

            //let's take the node from the adjacent positions we passed
            Node node = GetNode(adjPos.x, adjPos.y, adjPos.z);

            //if it's not null and we can walk on it
            if (gridBase.NodeWalkable(node)) {
                //we can use that node
                retVal = node;
            } //if not
            else if (searchTopDown) //and we want to have 3d A* 
            {
                //then look what the adjacent node have under him
                adjPos.y -= 1;
                Node bottomBlock = GetNode(adjPos.x, adjPos.y, adjPos.z);

                //if there is a bottom block and we can walk on it
                if (gridBase.NodeWalkable(bottomBlock)) {
                    retVal = bottomBlock; // we can return that
                } else {
                    //otherwise, we look what it has on top of it
                    adjPos.y += 2;
                    Node topBlock = GetNode(adjPos.x, adjPos.y, adjPos.z);
                    if (gridBase.NodeWalkable(topBlock)) {
                        retVal = topBlock;
                    }
                }
            }

            //if the node is diagonal to the current node then check the neighbouring nodes
            //so to move diagonally, we need to have 4 nodes walkable
            int originalX = adjPos.x - currentNodePos.x;
            int originalZ = adjPos.z - currentNodePos.z;

            if (Mathf.Abs(originalX) == 1 && Mathf.Abs(originalZ) == 1) {
                // the first block is originalX, 0 and the second to check is 0, originalZ
                //They need to be pathfinding walkable
                Node neighbour1 = GetNode(currentNodePos.x + originalX, currentNodePos.y, currentNodePos.z);
                if (!gridBase.NodeWalkable(neighbour1)) {
                    retVal = null;
                }

                Node neighbour2 = GetNode(currentNodePos.x, currentNodePos.y, currentNodePos.z + originalZ);
                if (!gridBase.NodeWalkable(neighbour2)) {
                    retVal = null;
                }
            }

            //and here's where we can add even more additional checks
            if (retVal != null) {
                //Example, do not approach a node from the left
                /*if(node.x > currentNodePos.x) {
                    node = null;
                }*/
            }

            return retVal;
        }

        private Node GetNode(int x, int y, int z) {
            Node n = null;

            lock(gridBase) {
                n = gridBase.GetNode(x, y, z);
            }
            return n;
        }

        private int GetDistance(Node posA, Node posB) {
            //We find the distance between each node
            //not much to explain here

            int distX = Mathf.Abs(posA.x - posB.x);
            int distZ = Mathf.Abs(posA.z - posB.z);
            int distY = Mathf.Abs(posA.y - posB.y);

            if (distX > distZ) {
                return 14 * distZ + 10 * (distX - distZ) + 10 * distY;
            }

            return 14 * distX + 10 * (distZ - distX) + 10 * distY;
        }

    }

    public class Path {
        public List<Vector3> vectorPath = null;
        public List<Node> path = null;

        public Node start = null;
        public Node target = null;
        public void Clear() {
            vectorPath = new List<Vector3>();
            path = new List<Node>();
        }
    }

    public enum ModifierPass {
        PreProcess,

        PostProcess = 2,
    }

    public class PathFindManager : Singleton<PathFindManager>, IDisposable {

        //The maximum simultaneous threads we allow to open
        int MaxJobs = 3;

        //Delegates are a variable that points to a function
        public delegate void PathfindingJobComplete(List<Vector3> path);

        private List<Pathfinder> currentJobs = new List<Pathfinder>();
        private List<Pathfinder> todoJobs = new List<Pathfinder>();

        private GridBase gridBase = new GridBase();

        public Vector2 startNodePosition = new Vector3(5, 30, 0);
        public Vector2 endNodePosition = new Vector3(82, 72, 0);

        public bool Find;
        public bool use_modifier = true;

        List<Vector3> findPath = new List<Vector3>();

        readonly List<IPathModifier> modifiers = new List<IPathModifier>();

        /*         Y
         *         |
         *         |
         *
         *      6  2  5
         *       \ | /
         * --  3 - X - 1  ----- X
         *       / | \
         *      7  0  4
         *
         *         |
         *         |
         */
        public readonly int[] neighbourXOffsets = new int[8] { 0, 1, 0, -1, 1, 1, -1, -1 };
        public readonly int[] neighbourYOffsets = new int[8] {-1, 0, 1, 0, -1, 1, 1, -1 };

        string map_config_data = "";

        void Start() {

        }

        void Update() {

            if (Find) {
                Find = false;
                FindOnePath(startNodePosition, endNodePosition, onFindedPath, false, use_modifier);
            }

            int i = 0;
            while (i < currentJobs.Count) {
                if (currentJobs[i].jobDone) {
                    currentJobs[i].NotifyComplete();
                    currentJobs[i].Clear();
                    currentJobs.RemoveAt(i);
                } else {
                    i++;
                }
            }

            if (todoJobs.Count > 0 && currentJobs.Count < MaxJobs) {
                Pathfinder job = todoJobs[0];
                todoJobs.RemoveAt(0);
                currentJobs.Add(job);
                job.Start(true);
            }
        }

        // 搜索一条路径（立即返回方式） start target : 路径起止点    
        // local_coordinate : true/false :输入起止点是本地/格子坐标（返回的路径也对应本地/格子坐标）
        // use_path_modifier : 路径平滑组件是否有效
        public List<Vector3> FindOnePathNow(Vector3 start, Vector3 target, bool local_coordinate = false, bool use_path_modifier = false) {
            if (local_coordinate) {
                start = LocalToGrid(start);
                target = LocalToGrid(target);
            }
            Node s = gridBase.FindNearestWalkableNode(start, target, 10, 1);
            Node t = gridBase.FindNearestWalkableNode(target, start);
            if (s == null || t == null) {
                // Debug.Log(s == null? "start pos invalid!": "target pos invalid!");
                return new List<Vector3>();
            }
            Pathfinder job = new Pathfinder(s, t, null, local_coordinate, use_path_modifier);
            job.Start(false);
            return job.foundPath;
        }

        // 搜索一条路径（异步多线程方式，回调通知搜索到的路径） start target : 路径起止点  completecallback:路径回调  
        // local_coordinate : true/false :输入起止点是本地/格子坐标（返回的路径也对应本地/格子坐标）
        // use_path_modifier : 路径平滑组件是否有效
        public void FindOnePath(Vector3 start, Vector3 target, PathfindingJobComplete completeCallback, bool local_coordinate = true, bool use_path_modifier = true) {
            if (local_coordinate) {
                // Debug.Log("begin search path local coop s:(" + start.x + "," + start.y + ") t:(" + target.x + "," + target.y + ")");
                start = LocalToGrid(start);
                target = LocalToGrid(target);
            }
            Node s = gridBase.FindNearestWalkableNode(start, target, 10, 1);
            Node t = gridBase.FindNearestWalkableNode(target, start);
            if (s == null || t == null) {
                // Debug.Log(s == null? "start pos invalid!": "target pos invalid!");
                completeCallback(new List<Vector3>());
                return;
            }
            if (use_path_modifier) {
                Path path = new Path();
                path.start = s;
                path.target = t;
                RunModifiers(ModifierPass.PreProcess, path);
            }
            // Debug.Log("grid coop s:(" + s.x + "," + s.y + ") t:(" + t.x + "," + t.y + ")");
            Pathfinder newJob = new Pathfinder(s, t, completeCallback, local_coordinate, use_path_modifier);
            todoJobs.Add(newJob);
        }

        // 支持客户端自定义范围内阻挡类型检查来设置路径必经点的寻路（用于防止路径优化造成的触发失败。）
        public void FindPathTrace(Vector3 start, Vector3 target, PathfindingJobComplete completeCallback, int user_param, int check_range,
            bool local_coordinate = true, bool use_path_modifier = true) {
            if (local_coordinate) {
                start = LocalToGrid(start);
                target = LocalToGrid(target);
            }
            Node s = gridBase.FindNearestWalkableNode(start, target, 10, 1);
            Node t = gridBase.FindNearestWalkableNode(target, start);
            if (s == null || t == null) {
                // Debug.Log(s == null? "start pos invalid!": "target pos invalid!");
                completeCallback(new List<Vector3>());
                return;
            }
            if (use_path_modifier) {
                Path path = new Path();
                path.start = s;
                path.target = t;
                RunModifiers(ModifierPass.PreProcess, path);
            }
            Pathfinder newJob = new Pathfinder(s, t, completeCallback, local_coordinate, use_path_modifier);
            newJob.SetTraceParamCheck(user_param, check_range);
            todoJobs.Add(newJob);
        }
        public void Dispose() {
            todoJobs.Clear();
            foreach (Pathfinder job in currentJobs) {
                job.Clear();
            }
            currentJobs.Clear();
            gridBase.Clear();
            modifiers.Clear();
        }

        public void onFindedPath(List<Vector3> path) {
            if (path.Count == 0) {
                // Debug.Log("find path is empty!");
            }
            findPath = path;
        }

        public GridBase getGrid() {
            return gridBase;
        }

        private void OnDrawGizmos() {
            if (gridBase == null)
                return;
            Vector3 pos = transform.position;
            Vector3 a1, a2, a3, a4;
            gridBase.ForeachNode((Node n) => {

                if (!gridBase.NodeWalkable(n)) {
                    Gizmos.color = new Color(1, 0, 0, 0.5f);
                    if (n != null && !n.Walkable) {
                        Gizmos.color = new Color(0, 0, 1, 0.5f);
                    }
                    a1 = new Vector3(pos.x + (n.x + 0.5f) * gridBase.offsetX, pos.y + (n.y + 0.5f) * gridBase.offsetY, pos.z);
                    Gizmos.DrawCube(a1, new Vector3(1, 1, 0.01f) * gridBase.node_size);
                }
            });

            // draw finded path
            if (findPath.Count > 0) {
                Gizmos.color = Color.green;
                Vector3 b = findPath[0];
                // draw finded path
                // in grid coop
                a1 = new Vector3(pos.x + (b.x + 0.5f) * gridBase.offsetX, pos.y + (b.y + 0.5f) * gridBase.offsetY, pos.z);
                foreach (Vector3 n2 in findPath) {
                    a2 = new Vector3(pos.x + (n2.x + 0.5f) * gridBase.offsetX, pos.y + (n2.y + 0.5f) * gridBase.offsetY, pos.z);
                    Gizmos.DrawLine(a1, a2);
                    a1 = a2;
                }
                // draw finded grid path    
                // Gizmos.color = Color.yellow;
                // b = findGridPath[0];
                // a1 = new Vector3(pos.x + (b.x + 0.5f) * gridBase.offsetX, pos.y + (b.y + 0.5f) * gridBase.offsetY, pos.z);
                // foreach (Vector2 n2 in findGridPath) {
                //     a2 = new Vector3(pos.x + (n2.x + 0.5f) * gridBase.offsetX, pos.y + (n2.y + 0.5f) * gridBase.offsetY, pos.z);
                //     Gizmos.DrawLine(a1, a2);
                //     a1 = a2;
                // }

            }

            // draw range rect
            // a2---a3
            // |    |
            // a1---a4
            Gizmos.color = Color.yellow;
            a1 = pos;
            a2 = new Vector3(a1.x, a1.y + gridBase.maxY * gridBase.offsetY, pos.z);
            a3 = new Vector3(a1.x + gridBase.maxX * gridBase.offsetX, a1.y + gridBase.maxY * gridBase.offsetY, pos.z);
            a4 = new Vector3(a1.x + gridBase.maxX * gridBase.offsetX, a1.y, pos.z);
            Gizmos.DrawLine(a1, a2);
            Gizmos.DrawLine(a2, a3);
            Gizmos.DrawLine(a3, a4);
            Gizmos.DrawLine(a4, a1);

            // draw start and end pos
            Gizmos.color = Color.green;
            a1 = new Vector3(pos.x + (startNodePosition.x + 0.5f) * gridBase.offsetX, pos.y + (startNodePosition.y + 0.5f) * gridBase.offsetY, pos.z);
            a2 = new Vector3(pos.x + (endNodePosition.x + 0.5f) * gridBase.offsetX, pos.y + (endNodePosition.y + 0.5f) * gridBase.offsetY, pos.z);
            Gizmos.DrawCube(a1, new Vector3(1, 1, 0.01f) * gridBase.node_size);
            Gizmos.DrawCube(a2, new Vector3(1, 1, 0.01f) * gridBase.node_size);
        }

        byte[] extractZipEntry(ZipFile zipFile, ZipEntry zipEntry) {
            String entryFileName = zipEntry.Name;
            byte[] buffer = new byte[4096]; // 4K is optimum
            Stream zipStream = zipFile.GetInputStream(zipEntry);

            MemoryStream ms = new MemoryStream();
            // StreamWriter fw = new StreamWriter(ms);
            StreamUtils.Copy(zipStream, ms, buffer);
            // fw.Flush();
            ms.Flush();
            ms.Position = 0;
            byte[] bytes = new byte[ms.Length];
            ms.Read(bytes, 0, (int)ms.Length);
            return bytes;
        }

        private bool InitGridFromAPFPdump(byte[] zip_data) {
            MemoryStream ms = new MemoryStream();
            ms.Write(zip_data, 0, zip_data.Length);
            ms.Position = 0;
            ZipFile zipFile = new ZipFile(ms);
            // load meta.json
            ZipEntry entry = zipFile.GetEntry("meta.json");
            byte[] json_data = null;
            if (entry != null) {
                // 使用astar project 专用的数据
                // apfp 输出的meta.json version 字段是错的。解析会报错。。。
                // byte[] json_data = extractZipEntry(zipFile,entry);
                // JsonSerializerSettings settings  = new JsonSerializerSettings();
                // settings.Culture = System.Globalization.CultureInfo.InvariantCulture;
                // dynamic jobj = JsonConvert.DeserializeObject (System.Text.Encoding.UTF8.GetString(json_data),settings);
                // string ver = jobj["version"];

                // load graph0.json
                entry = zipFile.GetEntry("graph0.json");
                if (entry == null) {
                    Debug.Log("InitGridFromAPFPdump can't load graph0.json!");
                    return false;
                }
                json_data = extractZipEntry(zipFile, entry);
                dynamic jobj = JsonConvert.DeserializeObject(System.Text.Encoding.UTF8.GetString(json_data));
                float node_size = (float)jobj["nodeSize"];
                int w = (int)((float)jobj["unclampedSize"]["x"] / node_size);
                int h = (int)((float)jobj["unclampedSize"]["y"] / node_size);

                // load graph0_extra.binary 
                entry = zipFile.GetEntry("graph0_extra.binary");
                if (entry == null) {
                    Debug.Log("InitGridFramAPFPdump can't load graph0_extra.binary!");
                    return false;
                }
                json_data = extractZipEntry(zipFile, entry);
                gridBase.Init(w, h, node_size);
                gridBase.SetExternalBlockData(json_data, true);
                return true;
            }
            entry = zipFile.GetEntry("config");
            if (entry != null) {
                // 自定义格式的数据包
                json_data = extractZipEntry(zipFile, entry);
                map_config_data = System.Text.Encoding.UTF8.GetString(json_data);
                dynamic jobj = JsonConvert.DeserializeObject(map_config_data);
                float node_size = (float)jobj["NodeSize"];
                int w = (int)jobj["Width"];
                int h = (int)jobj["Height"];
                string name = (string)jobj["Name"];
                // load map block data
                entry = zipFile.GetEntry("data");
                if (entry == null) {
                    Debug.Log("InitGridFramAPFPdump can't load map data! name:" + name);
                    return false;
                }
                json_data = extractZipEntry(zipFile, entry);
                gridBase.Init(w, h, node_size);
                gridBase.SetExternalBlockData(json_data, false);
                return true;
            }

            Debug.Log("InitGridFromAPFPdump can't load !");
            return false;
        }

        public bool LoadFromAPFPdump(string asset_name, bool async = false) {
            // BundleManager:LoadAsset(path)
            if (!BundleManager.Instance.AssetExists(asset_name)) {
                return false;
            }
            if (async == false) {
                Asset asset = BundleManager.Instance.LoadAsset(asset_name);
                TextAsset zip = asset.RawAsset as TextAsset;
                return InitGridFromAPFPdump(zip.bytes);
            }
            StartCoroutine(delayLoad(asset_name));
            return true;
        }
        private IEnumerator delayLoad(string asset_name) {
            AssetLoadRequest req = BundleManager.Instance.LoadAssetAsync(asset_name);
            yield return req;
            if (req.Asset == null) {
                Debug.Log("failed load asset :" + asset_name);
            } else {
                TextAsset zip = req.Asset.RawAsset as TextAsset;
                InitGridFromAPFPdump(zip.bytes);
            }

        }

        public Vector3 GridToLocal(Vector3 grid_coord) {
            return new Vector3((grid_coord.x + 0.5f) * gridBase.offsetX, (grid_coord.y + 0.5f) * gridBase.offsetY, 0);
        }
        public Vector3 LocalToGrid(Vector3 local_coord) {
            return new Vector3((int)(local_coord.x / gridBase.node_size), (int)(local_coord.y / gridBase.node_size), 0);
        }

        public float GetGridNodeSize() {
            return gridBase.node_size;
        }
        public void RegisterModifier(IPathModifier modifier) {
            modifiers.Add(modifier);
            // Sort the modifiers based on their specified order
            modifiers.Sort((a, b) => a.Order.CompareTo(b.Order));
        }

        public void DeregisterModifier(IPathModifier modifier) {
            modifiers.Remove(modifier);
        }

        public void RunModifiers(ModifierPass pass, Path path) {
            if (pass == ModifierPass.PreProcess) {
                for (int i = 0; i < modifiers.Count; i++)
                    modifiers[i].PreProcess(path);
            } else if (pass == ModifierPass.PostProcess) {
                UnityEngine.Profiling.Profiler.BeginSample("Running Path Modifiers");
                // Loop through all modifiers and apply post processing
                for (int i = 0; i < modifiers.Count; i++)
                    modifiers[i].Apply(path);
                UnityEngine.Profiling.Profiler.EndSample();
            }
        }

        public bool Linecast(Node fromNode, Node toNode) {
            var dir = new Vector2(toNode.x - fromNode.x, toNode.y - fromNode.y);

            // How much further we move away from (or towards) the line when walking along the primary direction (e.g up and right or down and left).
            // This isn't an actual distance. It is a signed distance so it can be negative (other side of the line)
            // Also it includes an additional factor, but the same factor is used everywhere
            // and we only check for if the signed distance is greater or equal to zero so it is ok
            long primaryDirectionError = (long)Util.CrossMagnitude(dir, new Vector2(System.Math.Sign(dir.x), System.Math.Sign(dir.y)));

            /*            Y/Z
             *             |
             *  quadrant   |   quadrant
             *     1              0
             *             2
             *             |
             *   ----  3 - X - 1  ----- X
             *             |
             *             0
             *  quadrant       quadrant
             *     2       |      3
             *             |
             */

            // Calculate the quadrant index as shown in the diagram above (the axes are part of the quadrants after them in the counter clockwise direction)
            int quadrant = 0;

            if (dir.x <= 0 && dir.y > 0)quadrant = 1;
            else if (dir.x < 0 && dir.y <= 0)quadrant = 2;
            else if (dir.x >= 0 && dir.y < 0)quadrant = 3;

            // This will be (1,2) for quadrant 0 and (2,3) for quadrant 1 etc.
            // & 0x3 is just the same thing as % 4 but it is faster
            // This is the direction which moves further to the right of the segment (when looking from the start)
            int directionToReduceError = (quadrant + 1) & 0x3;
            // This is the direction which moves further to the left of the segment (when looking from the start)
            int directionToIncreaseError = (quadrant + 2) & 0x3;
            int directionDiagonal = (dir.x != 0 && dir.y != 0) ? 4 + ((quadrant + 1) & 0x3) : -1;
            Vector2 offset = new Vector2(0, 0);
            while (fromNode != null && (fromNode.x != toNode.x || fromNode.y != toNode.y)) {
                // This is proportional to the distance between the line and the node
                var error = Util.CrossMagnitude(dir, offset) * 2;

                // How does the error change we take one step in the primary direction
                var nerror = error + primaryDirectionError;

                // Check if we need to reduce or increase the error (we want to keep it near zero)
                // and pick the appropriate direction to move in
                int ndir = nerror < 0 ? directionToIncreaseError : directionToReduceError;
                if (nerror == 0 && directionDiagonal != -1)ndir = directionDiagonal;

                int nx = fromNode.x + neighbourXOffsets[ndir];
                int ny = fromNode.y + neighbourYOffsets[ndir];
                fromNode = gridBase.GetNode(nx, ny, 0);
                if (!gridBase.NodeWalkable(fromNode))
                    break;
                offset += new Vector2(neighbourXOffsets[ndir], neighbourYOffsets[ndir]);
            }
            return fromNode != toNode;
        }
        public bool Linecast(Vector3 from, Vector3 to) {
            // hit = new GraphHitInfo();

            // hit.origin = from;

            Vector3 fromInGraphSpace = LocalToGrid(from);
            Vector3 toInGraphSpace = LocalToGrid(to);

            // Clip the line so that the start and end points are on the graph
            if (!Util.ClipLineSegmentToBounds(fromInGraphSpace, toInGraphSpace, out fromInGraphSpace, out toInGraphSpace, gridBase.maxX, gridBase.maxY)) {
                // Line does not intersect the graph
                // So there are no obstacles we can hit
                return false;
            }

            // Find the closest nodes to the start and end on the part of the segment which is on the graph
            var startNode = gridBase.GetNodeFromVector3(fromInGraphSpace); //GetNearest(transform.Transform(fromInGraphSpace), NNConstraint.None).node as GridNodeBase;
            var endNode = gridBase.GetNodeFromVector3(toInGraphSpace); //GetNearest(transform.Transform(toInGraphSpace), NNConstraint.None).node as GridNodeBase;

            if (!gridBase.NodeWalkable(startNode)) {
                // Hit point is the point where the segment intersects with the graph boundary
                // or just #from if it starts inside the graph
                return true;
            }

            // Throw away components we don't care about (y)
            // Also subtract 0.5 because nodes have an offset of 0.5 (first node is at (0.5,0.5) not at (0,0))
            // And it's just more convenient to remove that term here.
            // The variable names #from and #to are unfortunately already taken, so let's use start and end.
            var start = new Vector2(fromInGraphSpace.x, fromInGraphSpace.y);
            var end = new Vector2(toInGraphSpace.x, toInGraphSpace.y);

            // Couldn't find a valid node
            // This shouldn't really happen unless there are NO nodes in the graph
            if (startNode == null || endNode == null) {
                return true;
            }

            var dir = end - start;

            // Primary direction that we will move in
            // (e.g up and right or down and left)
            var sign = new Vector2(Mathf.Sign(dir.x), Mathf.Sign(dir.y));

            // How much further we move away from (or towards) the line when walking along #sign
            // This isn't an actual distance. It is a signed distance so it can be negative (other side of the line)
            // Also it includes an additional factor, but the same factor is used everywhere
            // and we only check for if the signed distance is greater or equal to zero so it is ok
            var primaryDirectionError = Util.CrossMagnitude(dir, sign);

            /*            Y/Z
             *             |
             *  quadrant   |   quadrant
             *     1              0
             *             2
             *             |
             *   ----  3 - X - 1  ----- X
             *             |
             *             0
             *  quadrant       quadrant
             *     2       |      3
             *             |
             */

            // Some XORing to get the quadrant index as shown in the diagram above
            int quadrant = (dir.y >= 0 ? 0 : 3) ^ (dir.x >= 0 ? 0 : 1);
            // This will be (1,2) for quadrant 0 and (2,3) for quadrant 1 etc.
            // & 0x3 is just the same thing as % 4 but it is faster
            // This is the direction which moves further to the right of the segment (when looking from the start)
            int directionToReduceError = (quadrant + 1) & 0x3;
            // This is the direction which moves further to the left of the segment (when looking from the start)
            int directionToIncreaseError = (quadrant + 2) & 0x3;

            // Current node. Start at n1
            var current = startNode;

            while (current.x != endNode.x || current.y != endNode.y) {

                // Position of the node in 2D graph/node space
                // Here the first node in the graph is at (0,0)
                var p = new Vector2(current.x, current.y);

                // Calculate the error
                // This is proportional to the distance between the line and the node
                var error = Util.CrossMagnitude(dir, p - start);

                // How does the error change we take one step in the primary direction
                var nerror = error + primaryDirectionError;

                // Check if we need to reduce or increase the error (we want to keep it near zero)
                // and pick the appropriate direction to move in
                int ndir = nerror < 0 ? directionToIncreaseError : directionToReduceError;

                // Check we can move in that direction
                int nx = current.x + neighbourXOffsets[ndir];
                int ny = current.y + neighbourYOffsets[ndir];
                var other = gridBase.GetNode(nx, ny, 0);
                // var other = current.GetNeighbourAlongDirection(ndir);
                if (gridBase.NodeWalkable(other)) {
                    current = other;
                } else {
                    return true;
                }
            }

            // No obstacles detected
            if (current == endNode) {
                return false;
            }

            // Reached node right above or right below n2 but we cannot reach it
            return true;
        }

        public string GetMapConfigString() {
            return map_config_data;
        }

        public void SetGridWalkable(int x, int y, bool isWalkable, int user_param1, int user_param2) {
            Node node = gridBase.GetNode(x, y, 0);
            if (node != null) {
                node.Walkable = isWalkable;
                node.userParam = (UInt32)(user_param1 << 16 | user_param2);
                // Debug.Log("setGridWalkable: p1:" + user_param1 + " p2:" + user_param2 + " walk:" + isWalkable);
            }
        }

        public bool isGridWalkable(int x, int y) {
            return gridBase.NodeWalkable(gridBase.GetNode(x, y, 0));
        }

    }

}