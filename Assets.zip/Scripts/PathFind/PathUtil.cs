using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MyAstar {

    public static class Memory {
        /// <summary>
        /// Sets all values in an array to a specific value faster than a loop.
        /// Only faster for large arrays. Slower for small ones.
        /// Tests indicate it becomes faster somewhere when the length of the array grows above around 100.
        /// For large arrays this can be magnitudes faster. Up to 40 times faster has been measured.
        ///
        /// Note: Only works on primitive value types such as int, long, float, etc.
        ///
        /// <code>
        /// //Set all values to 8 in the array
        /// int[] arr = new int[20000];
        /// Pathfinding.Util.Memory.MemSet<int> (arr, 8, sizeof(int));
        /// </code>
        /// See: System.Buffer.BlockCopy
        /// </summary>
        /// <param name="array">the array to fill</param>
        /// <param name="value">the value to fill the array with</param>
        /// <param name="byteSize">size in bytes of every element in the array. e.g 4 bytes for an int, or 8 bytes for a long.
        /// It can be efficiently got using the sizeof built-in function.</param>
        public static void MemSet<T>(T[] array, T value, int byteSize)where T : struct {
            if (array == null) {
                throw new ArgumentNullException("array");
            }

            int block = 32, index = 0;
            int length = Math.Min(block, array.Length);

            //Fill the initial array
            while (index < length) {
                array[index] = value;
                index++;
            }

            length = array.Length;
            while (index < length) {
                Buffer.BlockCopy(array, 0, array, index * byteSize, Math.Min(block, length - index) * byteSize);
                index += block;
                block *= 2;
            }
        }

        /// <summary>
        /// Sets all values in an array to a specific value faster than a loop.
        /// Only faster for large arrays. Slower for small ones.
        /// Tests indicate it becomes faster somewhere when the length of the array grows above around 100.
        /// For large arrays this can be magnitudes faster. Up to 40 times faster has been measured.
        ///
        /// Note: Only works on primitive value types such as int, long, float, etc.
        ///
        /// It can be efficiently got using the sizeof built-in function.
        ///
        /// <code>
        /// //Set all values to 8 in the array
        /// int[] arr = new int[20000];
        /// Pathfinding.Util.Memory.MemSet<int> (arr, 8, sizeof(int));
        /// </code>
        /// See: System.Buffer.BlockCopy
        /// </summary>
        /// <param name="array">the array to fill</param>
        /// <param name="value">the value to fill the array with</param>
        /// <param name="byteSize">size in bytes of every element in the array. e.g 4 bytes for an int, or 8 bytes for a long.</param>
        /// <param name="totalSize">all indices in the range [0, totalSize-1] will be set</param>
        public static void MemSet<T>(T[] array, T value, int totalSize, int byteSize)where T : struct {
            if (array == null) {
                throw new ArgumentNullException("array");
            }

            int block = 32, index = 0;
            int length = Math.Min(block, totalSize);

            //Fill the initial array
            while (index < length) {
                array[index] = value;
                index++;
            }

            length = totalSize;
            while (index < length) {
                Buffer.BlockCopy(array, 0, array, index * byteSize, Math.Min(block, totalSize - index) * byteSize);
                index += block;
                block *= 2;
            }
        }

        /// <summary>
        /// Returns a new array with at most length newLength.
        /// The array will contain a copy of all elements of arr up to but excluding the index newLength.
        /// </summary>
        public static T[] ShrinkArray<T>(T[] arr, int newLength) {
            newLength = Math.Min(newLength, arr.Length);
            var shrunkArr = new T[newLength];
            Array.Copy(arr, shrunkArr, newLength);
            return shrunkArr;
        }

        /// <summary>Swaps the variables a and b</summary>
        public static void Swap<T>(ref T a, ref T b) {
            T tmp = a;

            a = b;
            b = tmp;
        }
    }

    /// <summary>Magnitude of the cross product a x b</summary>
    public static class Util {
        static public float CrossMagnitude(Vector2 a, Vector2 b) {
            return a.x * b.y - b.x * a.y;
        }
        public static void Subdivide(List<Vector3> points, List<Vector3> result, int subSegments) {
            for (int i = 0; i < points.Count - 1; i++)
                for (int j = 0; j < subSegments; j++)
                    result.Add(Vector3.Lerp(points[i], points[i + 1], j / (float)subSegments));

            result.Add(points[points.Count - 1]);
        }
        /// <summary>
        /// Returns if p lies on the left side of the line a - b.
        /// Uses XY space. Also returns true if the points are colinear.
        /// </summary>
        public static bool RightOrColinearXY(Vector3 a, Vector3 b, Vector3 p) {
            return (b.x - a.x) * (p.y - a.y) - (p.x - a.x) * (b.y - a.y) <= 0;
        }
        /// <summary>
        /// Returns the intersection point between the two line segments in XY space.
        /// Lines are NOT treated as infinite. start1 is returned if the line segments do not intersect
        /// The point will be returned along the line [start1, end1] (this matters only for the y coordinate).
        /// </summary>
        public static Vector3 SegmentIntersectionPointXY(Vector3 start1, Vector3 end1, Vector3 start2, Vector3 end2, out bool intersects) {
            Vector3 dir1 = end1 - start1;
            Vector3 dir2 = end2 - start2;

            float den = dir2.y * dir1.x - dir2.x * dir1.y;

            if (den == 0) {
                intersects = false;
                return start1;
            }

            float nom = dir2.x * (start1.y - start2.y) - dir2.y * (start1.x - start2.x);
            float nom2 = dir1.x * (start1.y - start2.y) - dir1.y * (start1.x - start2.x);
            float u = nom / den;
            float u2 = nom2 / den;

            if (u < 0F || u > 1F || u2 < 0F || u2 > 1F) {
                intersects = false;
                return start1;
            }

            intersects = true;
            return start1 + dir1 * u;
        }
        /// <summary>
        /// Clips a line segment in graph space to the graph bounds.
        /// That is (0,0,0) is the bottom left corner of the graph and (width,0,depth) is the top right corner.
        /// The first node is placed at (0.5,y,0.5). One unit distance is the same as nodeSize.
        ///
        /// Returns false if the line segment does not intersect the graph at all.
        /// </summary>
        public static bool ClipLineSegmentToBounds(Vector3 a, Vector3 b, out Vector3 outA, out Vector3 outB, int maxX, int maxY) {
            // If the start or end points are outside
            // the graph then clamping is needed
            if (a.x < 0 || a.y < 0 || a.x > maxX || a.y > maxY ||
                b.x < 0 || b.y < 0 || b.x > maxX || b.y > maxY) {
                // Boundary of the grid
                var p1 = new Vector3(0, 0, 0);
                var p2 = new Vector3(0, maxY, 0);
                var p3 = new Vector3(maxX, maxY, 0);
                var p4 = new Vector3(maxX, 0, 0);

                int intersectCount = 0;

                bool intersect;
                Vector3 intersection;

                intersection = SegmentIntersectionPointXY(a, b, p1, p2, out intersect);

                if (intersect) {
                    intersectCount++;
                    if (!RightOrColinearXY(p1, p2, a)) {
                        a = intersection;
                    } else {
                        b = intersection;
                    }
                }
                intersection = SegmentIntersectionPointXY(a, b, p2, p3, out intersect);

                if (intersect) {
                    intersectCount++;
                    if (!RightOrColinearXY(p2, p3, a)) {
                        a = intersection;
                    } else {
                        b = intersection;
                    }
                }
                intersection = SegmentIntersectionPointXY(a, b, p3, p4, out intersect);

                if (intersect) {
                    intersectCount++;
                    if (!RightOrColinearXY(p3, p4, a)) {
                        a = intersection;
                    } else {
                        b = intersection;
                    }
                }
                intersection = SegmentIntersectionPointXY(a, b, p4, p1, out intersect);

                if (intersect) {
                    intersectCount++;
                    if (!RightOrColinearXY(p4, p1, a)) {
                        a = intersection;
                    } else {
                        b = intersection;
                    }
                }

                if (intersectCount == 0) {
                    // The line does not intersect with the grid
                    outA = Vector3.zero;
                    outB = Vector3.zero;
                    return false;
                }
            }

            outA = a;
            outB = b;
            return true;
        }

    }

}