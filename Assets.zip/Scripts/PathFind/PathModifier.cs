using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;
using TJ;
using UnityEngine;

namespace MyAstar {
    public interface IPathModifier {
        int Order { get; }
        void Apply(Path path);
        void PreProcess(Path path);
    }
    public abstract class PathModifier : IPathModifier {
        public PathFindManager seeker;
        public abstract int Order { get; }

        public void Awake() {
            this.seeker = PathFindManager.Instance;
            if (seeker != null) {
                seeker.RegisterModifier(this);
            }
        }

        public void OnDestroy() {
            if (seeker != null) {
                seeker.DeregisterModifier(this);
            }
        }

        public virtual void PreProcess(Path path) {
            // Required by IPathModifier
        }

        public abstract void Apply(Path path);
    }

    // simple smooth path modifier from A* pathfinding project 4.2.8
    public class SimpleSmoothPathModifier : PathModifier {
        public override int Order { get { return 60; } }
        int iterations = 5;

        int subdivisions = 2;
        public override void Apply(Path path) {
            if (path.vectorPath == null || path.vectorPath.Count <= 2)
                return;
            // Subdivisions should not be less than zero
            subdivisions = Mathf.Max(subdivisions, 0);

            // Prevent unknowing users from entering bad values
            if (subdivisions > 12) {
                Debug.LogWarning("Subdividing a path more than 12 times is quite a lot, it might cause memory problems and it will certainly slow the game down.\n" +
                    "When this message is logged, no smoothing will be applied");
                subdivisions = 12;
                return;
            }

            // Create a new list to hold the smoothed path
            List<Vector3> newPath = new List<Vector3>();
            List<Vector3> originalPath = path.vectorPath;

            // One segment (line) in the original array will be subdivided to this number of smaller segments
            int subSegments = (int)Mathf.Pow(2, subdivisions);
            float fractionPerSegment = 1F / subSegments;
            for (int i = 0; i < originalPath.Count - 1; i++) {
                for (int j = 0; j < subSegments; j++) {
                    // Use Vector3.Lerp to place the points at their correct positions along the line
                    newPath.Add(Vector3.Lerp(originalPath[i], originalPath[i + 1], j * fractionPerSegment));
                }
            }

            // Add the last point
            newPath.Add(originalPath[originalPath.Count - 1]);

            // Smooth the path [iterations] number of times
            for (int it = 0; it < iterations; it++) {
                // Loop through all points except the first and the last
                for (int i = 1; i < newPath.Count - 1; i++) {
                    // Set the new point to the average of the current point and the two adjacent points
                    Vector3 newpoint = (newPath[i] + newPath[i - 1] + newPath[i + 1]) / 3F;
                    newPath[i] = newpoint;
                }
            }

            // Assign the new path to the p.vectorPath field
            path.vectorPath = newPath;
        }
    }

    // raycast modifier modify from A* pathfinding project 4.2.8
    public class RaycastModifier : PathModifier {
        public override int Order { get { return 40; } }

        public bool useGraphRaycasting = true;

        /// <summary>
        /// Higher quality modes will try harder to find a shorter path.
        /// Higher qualities may be significantly slower than low quality.
        /// [Open online documentation to see images]
        /// </summary>
        public Quality quality = Quality.Medium;

        public enum Quality {
            /// <summary>One iteration using a greedy algorithm</summary>
            Low,
            /// <summary>Two iterations using a greedy algorithm</summary>
            Medium,
            /// <summary>One iteration using a dynamic programming algorithm</summary>
            High,
            /// <summary>Three iterations using a dynamic programming algorithm</summary>
            Highest
        }

        static readonly int[] iterationsByQuality = new [] { 1, 2, 1, 3 };
        static List<Vector3> buffer = new List<Vector3>();
        static float[] DPCosts = new float[16];
        static int[] DPParents = new int[16];

        public override void Apply(Path p) {
            if (!useGraphRaycasting || p.vectorPath.Count == 0)
                return;

            var points = p.vectorPath;

            if (ValidateLine(null, null, p.vectorPath[0], p.vectorPath[p.vectorPath.Count - 1])) {
                // A very common case is that there is a straight line to the target.
                var s = p.vectorPath[0];
                var e = p.vectorPath[p.vectorPath.Count - 1];
                points.Clear();
                points.Add(s);
                points.Add(e);
            } else {
                int iterations = iterationsByQuality[(int)quality];
                for (int it = 0; it < iterations; it++) {
                    if (it != 0) {
                        Util.Subdivide(points, buffer, 3);
                        Memory.Swap(ref buffer, ref points);
                        buffer.Clear();
                        points.Reverse();
                    }

                    points = quality >= Quality.High ? ApplyDP(p, points) : ApplyGreedy(p, points);
                }
                if ((iterations % 2) == 0)points.Reverse();
            }

            p.vectorPath = points;
        }

        List<Vector3> ApplyGreedy(Path p, List<Vector3> points) {
            bool canBeOriginalNodes = points.Count == p.path.Count;
            int startIndex = 0;

            while (startIndex < points.Count) {
                Vector3 start = points[startIndex];
                var startNode = canBeOriginalNodes && points[startIndex] == (Vector3)p.path[startIndex].position ? p.path[startIndex] : null;
                buffer.Add(start);

                // Do a binary search to find the furthest node we can see from this node
                int mn = 1, mx = 2;
                while (true) {
                    int endIndex = startIndex + mx;
                    if (endIndex >= points.Count) {
                        mx = points.Count - startIndex;
                        break;
                    }
                    Vector3 end = points[endIndex];
                    var endNode = canBeOriginalNodes && end == (Vector3)p.path[endIndex].position ? p.path[endIndex] : null;
                    if (!ValidateLine(startNode, endNode, start, end))break;
                    mn = mx;
                    mx *= 2;
                }

                while (mn + 1 < mx) {
                    int mid = (mn + mx) / 2;
                    int endIndex = startIndex + mid;
                    Vector3 end = points[endIndex];
                    var endNode = canBeOriginalNodes && end == (Vector3)p.path[endIndex].position ? p.path[endIndex] : null;

                    if (ValidateLine(startNode, endNode, start, end)) {
                        mn = mid;
                    } else {
                        mx = mid;
                    }
                }
                startIndex += mn;
            }

            Memory.Swap(ref buffer, ref points);
            buffer.Clear();
            return points;
        }

        List<Vector3> ApplyDP(Path p, List<Vector3> points) {
            if (DPCosts.Length < points.Count) {
                DPCosts = new float[points.Count];
                DPParents = new int[points.Count];
            }
            for (int i = 0; i < DPParents.Length; i++)DPCosts[i] = DPParents[i] = -1;
            bool canBeOriginalNodes = points.Count == p.path.Count;

            for (int i = 0; i < points.Count; i++) {
                float d = DPCosts[i];
                Vector3 start = points[i];
                var startIsOriginalNode = canBeOriginalNodes && start == (Vector3)p.path[i].position;
                for (int j = i + 1; j < points.Count; j++) {
                    // Total distance from the start to this point using the best simplified path
                    // The small additive constant is to make sure that the number of points is kept as small as possible
                    // even when the total distance is the same (which can happen with e.g multiple colinear points).
                    float d2 = d + (points[j] - start).magnitude + 0.0001f;
                    if (DPParents[j] == -1 || d2 < DPCosts[j]) {
                        var endIsOriginalNode = canBeOriginalNodes && points[j] == (Vector3)p.path[j].position;
                        if (j == i + 1 || ValidateLine(startIsOriginalNode ? p.path[i] : null, endIsOriginalNode ? p.path[j] : null, start, points[j])) {
                            DPCosts[j] = d2;
                            DPParents[j] = i;
                        } else {
                            break;
                        }
                    }
                }
            }

            int c = points.Count - 1;
            while (c != -1) {
                buffer.Add(points[c]);
                c = DPParents[c];
            }
            buffer.Reverse();
            Memory.Swap(ref buffer, ref points);
            buffer.Clear();
            return points;
        }

        /// <summary>
        /// Check if a straight path between v1 and v2 is valid.
        /// If both n1 and n2 are supplied it is assumed that the line goes from the center of n1 to the center of n2 and a more optimized graph linecast may be done.
        /// </summary>
        protected bool ValidateLine(Node n1, Node n2, Vector3 v1, Vector3 v2) {
            if (useGraphRaycasting) {
                bool betweenNodeCenters = n1 != null && n2 != null;
                // Use graph raycasting to check if a straight path between v1 and v2 is valid
                if (betweenNodeCenters) {
                    // If the linecast is exactly between the centers of two nodes on a grid graph then a more optimized linecast can be used.
                    // This method is also more stable when raycasting along a diagonal when the line just touches an obstacle.
                    // The normal linecast method may or may not detect that as a hit depending on floating point errors
                    // however this method never detect it as an obstacle (and that is very good for this component as it improves the simplification).
                    return !this.seeker.Linecast(n1, n2);
                } else {
                    return !this.seeker.Linecast(v1, v2);
                }
            }
            return true;
        }
    }
}