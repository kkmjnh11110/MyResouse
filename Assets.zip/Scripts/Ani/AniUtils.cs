using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;
using Spine;
using Spine.Unity;
using TJ;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class AniAssetInfo {
    public string mat;
    public string atlas;
    public string skeleton;
}
public class AniUtils {

    static UnityEngine.Object LoadAniAsset(string asset_name, bool async = false) {
        if (!BundleManager.Instance.AssetExists(asset_name)) {
            Debug.Log("asset:" + asset_name + " not existed!");
            return null;
        }
        if (async == false) {
            Asset asset = BundleManager.Instance.LoadAsset(asset_name);
            return asset.RawAsset;
        }
        return null;
        //StartCoroutine(delayLoad(asset_name));
    }
    static public SkeletonAnimation LoadSpineComponent(GameObject go, AniAssetInfo info) {
        SkeletonAnimation sa;
        SkeletonDataAsset sda;
        sda = ScriptableObject.CreateInstance<SkeletonDataAsset>();
        sda.fromAnimation = new string[0];
        sda.toAnimation = new string[0];
        sda.duration = new float[0];
        sda.scale = 0.01f;
        sda.defaultMix = 0.15f;

        AtlasAsset[] arrAtlasData = new AtlasAsset[1];
        AtlasAsset atlasdata = ScriptableObject.CreateInstance<AtlasAsset>();
        atlasdata.atlasFile = LoadAniAsset(info.atlas)as TextAsset;
        atlasdata.materials = new Material[1];
        atlasdata.materials[0] = LoadAniAsset(info.mat)as Material;
        // atlasdata.Reset();
        arrAtlasData[0] = atlasdata;
        sda.atlasAssets = arrAtlasData;
        sda.skeletonJSON = LoadAniAsset(info.skeleton)as TextAsset;
        sa = go.AddComponent<SkeletonAnimation>();
        sa.skeletonDataAsset = sda;
        // sa.calculateNormals = true;
        // sa.skeletonDataAsset.Reset();
        go.GetComponent<MeshRenderer>().sortingLayerName = "Layer2";
        if (sda.skeletonJSON != null) {
            sa.Initialize(false);
            sa.loop = true;
            sa.AnimationName = "idle_s";
        }
        return sa;
    }
    static public bool Raycast(Ray ray, out RaycastHit hit, int maxDistance, int layerMask = Physics.DefaultRaycastLayers) {
        return Physics.Raycast(ray, out hit, maxDistance, layerMask);
    }

    static public List<RaycastResult> DoGraphicRaycaster(GraphicRaycaster raycaster, PointerEventData eventData) {
        List<RaycastResult> results = new List<RaycastResult>();
        raycaster.Raycast(eventData, results);
        return results;
    }
    static public List<RaycastResult> EventSystemRaycastAll(PointerEventData eventData) {
        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);
        return results;
    }

    // 设置Physics2DRaycaster 组件的layMask
    static public void Physics2DRaycasterAdjustLayerMask(Physics2DRaycaster raycaster, string layer_name, bool on) {
        LayerMask layerMask = raycaster.eventMask;
        LayerMask disableLayerMask = 1 << LayerMask.NameToLayer(layer_name);
        if (on) {
            raycaster.eventMask = layerMask | disableLayerMask;
        } else {
            raycaster.eventMask = layerMask & ~disableLayerMask;
        }
    }

    static void RemoveEvent<T>(T c, string name) {
        Delegate[] invokeList = GetObjectEventList(c, name);
        if (invokeList == null)
            return;
        foreach (Delegate del in invokeList) {
            typeof(T).GetEvent(name).RemoveEventHandler(c, del);
        }
    }

    static Delegate[] GetObjectEventList(object p_Object, string p_EventName) {
        // Get event field
        FieldInfo _Field = p_Object.GetType().GetField(p_EventName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public | BindingFlags.Static);
        if (_Field == null) {
            return null;
        }
        // get the value of event field which should be a delegate
        object _FieldValue = _Field.GetValue(p_Object);

        // if it is a delegate
        if (_FieldValue != null && _FieldValue is Delegate) {
            // cast the value to a delegate
            Delegate _ObjectDelegate = (Delegate)_FieldValue;
            // get the invocation list
            return _ObjectDelegate.GetInvocationList();
        }
        return null;
    }

    // 移除spine animationstate 的事件回调
    public static void ClearAnimationStateEvent(Spine.AnimationState ani_state, string event_name) {
        RemoveEvent<Spine.AnimationState>(ani_state, event_name);
    }

}