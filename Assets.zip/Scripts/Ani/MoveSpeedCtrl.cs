using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;
using Spine;
using Spine.Unity;
using TJ;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;
using XLua;

public class MoveSpeedCtrl : MonoBehaviour {
    public float speed = 1.0f;
    float lua_speed = 1.0f;

    LuaTable luaInst;

    LuaFunction lua_func_setspeed;
    // public 
    void Start() {

    }

    // [CSharpCallLua]
    public void Init(LuaTable lt) {
        luaInst = lt;
        lua_func_setspeed = luaInst.GetInPath<LuaFunction>("SetMoveSpeed");
        // lua_speed = luaInst.GetInPath<float>("speed");
    }

    void Update() {
        if (lua_func_setspeed != null) {
            if (lua_speed != speed) {
                lua_func_setspeed.Call(luaInst, speed);
                lua_speed = speed;
            }
        }
    }

}