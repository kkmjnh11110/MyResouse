using UnityEngine;
using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.IO;


namespace ConsoleUtils
{
    
    public class ConsoleInput {
        //public delegate void InputText( string strInput );
        public event System.Action<string> OnInputText;
        public string inputString;

        public void ClearLine() {
            //System.Text.Encoding test = Console.InputEncoding;
            Console.CursorLeft = 0;
            Console.Write(new String(' ', Console.BufferWidth));
            Console.CursorTop--;
            Console.CursorLeft = 0;
        }

        public void RedrawInputLine() {
            if (inputString.Length == 0)return;

            if (Console.CursorLeft > 0)
                ClearLine();

            System.Console.ForegroundColor = ConsoleColor.Green;
            System.Console.Write(inputString);
        }

        internal void OnBackspace() {
            if (inputString.Length < 1)return;

            inputString = inputString.Substring(0, inputString.Length - 1);
            RedrawInputLine();
        }

        internal void OnEscape() {
            ClearLine();
            inputString = "";
        }

        internal void OnEnter() {
            ClearLine();
            System.Console.ForegroundColor = ConsoleColor.Green;
            System.Console.WriteLine("> " + inputString);

            var strtext = inputString;
            inputString = "";

            if (OnInputText != null) {
                OnInputText(strtext);
            }
        }

        public void Update() {
            if (!Console.KeyAvailable)return;
            var key = Console.ReadKey();

            if (key.Key == ConsoleKey.Enter) {
                OnEnter();
                return;
            }

            if (key.Key == ConsoleKey.Backspace) {
                OnBackspace();
                return;
            }

            if (key.Key == ConsoleKey.Escape) {
                OnEscape();
                return;
            }

            if (key.KeyChar != '\u0000') {
                inputString += key.KeyChar;
                RedrawInputLine();
                return;
            }
        }
    }

    public class ConsoleWindow {
        TextWriter oldOutput;

        public void Initialize() {
            //
            // Attach to any existing consoles we have
            // failing that, create a new one.
            //
            if (!AttachConsole(0x0ffffffff)) {
                AllocConsole();
            }

            oldOutput = Console.Out;

            try {
                IntPtr stdHandle = GetStdHandle(STD_OUTPUT_HANDLE);
                Microsoft.Win32.SafeHandles.SafeFileHandle safeFileHandle = new Microsoft.Win32.SafeHandles.SafeFileHandle(stdHandle, true);
                FileStream fileStream = new FileStream(safeFileHandle, FileAccess.Write);
                System.Text.Encoding encoding = System.Text.Encoding.Default;
                StreamWriter standardOutput = new StreamWriter(fileStream, encoding);
                standardOutput.AutoFlush = true;
                Console.SetOut(standardOutput);
            } catch (System.Exception e) {
                Debug.Log("Couldn't redirect output: " + e.Message);
            }
        }

        public void Shutdown() {
            Console.SetOut(oldOutput);
            FreeConsole();
        }

        public void SetTitle(string strName) {
            SetConsoleTitle(strName);
        }

        private const int STD_OUTPUT_HANDLE = -11;

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool AttachConsole(uint dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool AllocConsole();

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool FreeConsole();

        [DllImport("kernel32.dll", EntryPoint = "GetStdHandle", SetLastError = true, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr GetStdHandle(int nStdHandle);

        [DllImport("kernel32.dll")]
        static extern bool SetConsoleTitle(string lpConsoleTitle);
    }
    
}