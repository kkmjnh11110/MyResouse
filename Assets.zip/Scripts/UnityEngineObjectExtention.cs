﻿using System;
using XLua;

[LuaCallCSharp]
public static class UnityEngineObjectExtention
{
    public static bool IsNull(this UnityEngine.Object o)
    {
        return o == null;
    }

    public static UnityEngine.Component UniqueComponent(this UnityEngine.GameObject go, Type componentType) 
    {
        var comp = go.GetComponent(componentType);
        if (comp == null)
            comp = go.AddComponent(componentType);
        return comp;
    }
}