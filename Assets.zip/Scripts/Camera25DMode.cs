﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera25DMode : MonoBehaviour
{
    private void Awake()
    {
        var camera = GetComponent<Camera>();
        camera.transparencySortMode = TransparencySortMode.CustomAxis;
        camera.transparencySortAxis = Vector3.up;
    }

}
