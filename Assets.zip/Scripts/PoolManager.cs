﻿using UnityEngine;
using System.Collections.Generic;
using System;
using TJ;

[DisallowMultipleComponent]
[AddComponentMenu("")]
public class GameObjectPool : MonoBehaviour
{
    private Stack<GameObject> cacheGos = new Stack<GameObject>();

    public PoolManager mgr;
    public string poolName;
    public Asset asset;
    public GameObject cloneGo;

    public int MaxCount { get; set; } = -1;
    public int Count => cacheGos.Count;

    private void PreTake(GameObject go, bool active)
    {
        go.SetActive(active);
    }

    public GameObject Instantiate(bool active = true)
    {
        GameObject go = Take(active);
        if (go != null)
            return go;

        if (asset != null)
        {
            go = asset.Instantiate();
            PreTake(go, active);
            return go;
        }

        if (cloneGo != null)
        {
            go = GameObject.Instantiate(cloneGo);
            go.name = cloneGo.name;
            PreTake(go, active);
            return go;
        }

        throw new Exception("Can't Instantiate! Pool Name: " + poolName);
    }

    public GameObject Take(bool active = true)
    {
        if (cacheGos.Count == 0)
            return null;

        var go = cacheGos.Pop();
        PreTake(go, active);
        return go;
    }

    public void Recovery(GameObject go)
    {
        if (MaxCount >= 0 && Count >= MaxCount)
        {
            Destroy(go);
            return;
        }

        go.SetActive(false);
        cacheGos.Push(go);
        go.transform.SetParent(transform, false);
    }

    public void DestroySelf()
    {
        mgr.DestroyPool(poolName);
    }
}


[DisallowMultipleComponent]
[AddComponentMenu("")]
public class PoolManager : Singleton<PoolManager>, IDisposable
{
    private int autoId = 0;
    private Dictionary<string, GameObjectPool> poolDict = new Dictionary<string, GameObjectPool>();
    //public Transform cloneGosTf;
    //public Transform waitForTakeTf;

    private void Awake()
    {
        transform.localPosition = new Vector3(9999999, 9999999, 9999999);

        //cloneGosTf = new GameObject("_CloneGos").transform;
        //cloneGosTf.SetParent(transform, false);

        //waitForTakeTf = new GameObject("_WaitForTake").transform;
        //waitForTakeTf.SetParent(transform, false);
    }

    public void Dispose()
    {
        //貌似啥都不用做
    }

    public GameObjectPool GetPool(string poolName)
    {
        if (poolDict.ContainsKey(poolName))
            return poolDict[poolName];
        else
            return null;
    }

    public void DestroyPool(string poolName)
    {
        if (!poolDict.ContainsKey(poolName))
            return;

        var pool = poolDict[poolName];
        poolDict.Remove(poolName);

        //
        //if (pool.cloneGo != null)
        //    Destroy(pool.cloneGo);

        Destroy(pool.gameObject);
    }

    //纯粹缓存. 不要调用GameObjectPool.Instantiate
    //如果poolName为空字符串"", 或者"(*auto)", 则管理器会自动命名
    public GameObjectPool CreatePool(string poolName)
    {
        if (poolName == null || poolName == "" || poolName == "(*auto)")
        {
            poolName = String.Format("AutoPool{0:D4}", ++autoId);
        }
        if (poolDict.ContainsKey(poolName))
        {
            throw new Exception(poolName + " exist");
        }

        GameObject poolGo = new GameObject(poolName);
        poolGo.transform.SetParent(transform, false);
        var pool = poolGo.AddComponent<GameObjectPool>();
        pool.mgr = this;
        pool.poolName = poolName;
        poolDict[poolName] = pool;

        return pool;
    }

    //TJ.Asset的形式创建Pool, 可以确保Asset的引用, 而不会被资源回收掉
    public GameObjectPool CreatePool(string poolName, Asset asset)
    {
        var pool = CreatePool(poolName);
        pool.asset = asset;
        return pool;
    }

    //cloneGo使用由管理器接管. 如果后续用户还想使用, 请提前clone
    public GameObjectPool CreatePool(string poolName, GameObject cloneGo)
    {
        var pool = CreatePool(poolName);
        cloneGo.transform.SetParent(pool.transform, false);
        pool.cloneGo = cloneGo;
        return pool;
    }
}