﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using System;

public class DOTweenController : MonoBehaviour
{
    public class TweenItem
    {
        public Tween tw;
        public Action OnKill;
        public string alias = "";
    }

    public readonly List<TweenItem> tweenItems = new List<TweenItem>();
    public int Count { get { return tweenItems.Count; } }
    public bool KillOnDisable { get; set; } = false;
    public bool PauseWhenDisable { get; set; } = false;     //disable时暂停, enbale的时候继续

    //alias可以重名, 系统会管理OnKill, 所以如果需要OnKill, 则从这里传入
    public void Add(Tween tw, string alias = "", Action OnKill = null)
    {
        if (!tw.IsActive())
            return;

        if (tweenItems.Find(t => ReferenceEquals(t.tw, tw)) != null)
            return;

        TweenItem ti = new TweenItem
        {
            tw = tw,
            OnKill = OnKill,
            alias = alias,
        };
        tw.OnKill(() =>
        {
            //Debug.Log("count ::: " + tweenItems.Count);
            tweenItems.Remove(ti);
            ti.OnKill?.Invoke();
        });

        tweenItems.Add(ti);
    }

    public void Remove(Tween tw)
    {
        var ti = tweenItems.Find(t => ReferenceEquals(t.tw, tw));
        if (ti != null) tweenItems.Remove(ti);
    }

    public void RemoveAll()
    {
        tweenItems.Clear();
    }

    public void SetAlias(Tween tw, string alias)
    {
        if (alias == null)
            alias = "";

        var ti = tweenItems.Find(t => ReferenceEquals(t.tw, tw));
        if (ti != null)
        {
            ti.alias = alias;
        }
    }

    public Tween GetTweenByAlias(string alias)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti == null)
            return null;

        return ti.tw;
    }

    public void Kill(string alias, bool complete = false)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti != null)
        {
            ti.tw.Kill(complete);
            //OnKill的通知未必是立即的, 所以直接移除
            tweenItems.Remove(ti);
        }
    }

    public void KillAll(bool complete = false)
    {
        List<TweenItem> tis = new List<TweenItem>();
        tweenItems.ForEach(t => tis.Add(t));
        //tis.Reverse();

        foreach (var ti in tis)
        {
            if (ti.tw.IsActive())
                ti.tw.Kill(complete);
        }

        tweenItems.Clear();
        //Debug.Assert(tweenItems.Count == 0);
    }

    public void Pause(string alias)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti != null) ti.tw.Pause();
    }

    public void PauseAll()
    {
        foreach (var ti in tweenItems)
            ti.tw.Pause();
    }

    public void Play(string alias)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti != null) ti.tw.Play();
    }

    public void PlayAll()
    {
        foreach (var ti in tweenItems)
            ti.tw.Play();
    }

    public void Restart(string alias, bool includeDelay = true, float changeDelayTo = -1)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti != null) ti.tw.Restart(includeDelay, changeDelayTo);
    }

    public void RestartAll(bool includeDelay = true, float changeDelayTo = -1)
    {
        foreach (var ti in tweenItems)
            ti.tw.Restart(includeDelay, changeDelayTo);
    }

    public void Goto(string alias, float to, bool andPlay = false)
    {
        var ti = tweenItems.Find(t => t.alias == alias);
        if (ti != null) ti.tw.Goto(to, andPlay);
    }

    public void GotoAll(float to, bool andPlay = false)
    {
        foreach (var ti in tweenItems)
            ti.tw.Goto(to, andPlay);
    }

    private void OnEnable()
    {
        if (PauseWhenDisable)
            PauseAll();
    }

    private void OnDisable()
    {
        if (PauseWhenDisable)
            PlayAll();

        if (KillOnDisable)
            KillAll();
    }

    private void OnDestroy()
    {
        KillAll();
    }
}
