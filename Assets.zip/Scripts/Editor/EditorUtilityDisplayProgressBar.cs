﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.Threading.Tasks;
public class EditorUtilityDisplayProgressBar : EditorWindow
{
    public static float secs = 10f;
    public static float startVal = 0f;
    public static float progress = 0f;
    // [MenuItem("Examples/Progress Bar Usage")]
    public static void Init()
    {
        UnityEditor.EditorWindow window = GetWindow(typeof(EditorUtilityDisplayProgressBar));
        window.Show();
    }

    public static void OpenProgressBar()
    {
        EditorUtility.DisplayProgressBar("一键发布", "清理XLua生成的代码，要在切换平台前清除否则切换后会报错", 0.2f);
    }
    public static void OpenProgressBar1()
    {
        EditorUtility.DisplayProgressBar("一键发布", "切换平台", 0.4f);
    }
    public static void OpenProgressBar2()
    {
        EditorUtility.DisplayProgressBar("一键发布", "重新生成XLua代码", 0.6f);
    }
    public static void OpenProgressBar3()
    {
        EditorUtility.DisplayProgressBar("一键发布", "生成AB包", 0.7f);
    }
    public static void OpenProgressBar4()
    {
        EditorUtility.DisplayProgressBar("一键发布", "删除Assets/streamingAssets下的目录，减少打包PC端时间", 0.8f);
    }
    public static void OpenProgressBar5()
    {
        EditorUtility.DisplayProgressBar("一键发布", "发布项目", 0.9f);
    }
    public static void OpenProgressBar6()
    {
        EditorUtility.DisplayProgressBar("一键发布", "发布项目完成", 1.0f);
        #region /*------------------------------------------.Invoke_Delay_Threading在编辑状态能执行的延时*/
        //命名空间：System.Threading.Tasks;
        System.Func<Task> func = async () =>
        {
            await Task.Delay(System.TimeSpan.FromSeconds(2));
            //需要延迟执行的方法体...
            ClearProgressBar();
        };
        func();
        //https://blog.csdn.net/QverOo/article/details/88172657
        #endregion  /*------------------------------------------.Invoke_Delay_Threading在编辑状态能执行的延时*/
    }
    public static void OpenProgressBar7()
    {
        EditorUtility.DisplayProgressBar("一键发布", "发布失败", 1.0f);
        #region /*------------------------------------------.Invoke_Delay_Threading在编辑状态能执行的延时*/
        //命名空间：System.Threading.Tasks;
        System.Func<Task> func = async () =>
        {
            await Task.Delay(System.TimeSpan.FromSeconds(2));
            //需要延迟执行的方法体...
            ClearProgressBar();
        };
        func();
        //https://blog.csdn.net/QverOo/article/details/88172657
        #endregion  /*------------------------------------------.Invoke_Delay_Threading在编辑状态能执行的延时*/
    }
    public static void ClearProgressBar()
    {
        EditorUtility.ClearProgressBar();
    }

}