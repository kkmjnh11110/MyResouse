using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CSObjectWrapEditor;
using TJ;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

public static class Builder
{

    public static void BuildForWindow()
    {
        Build("Windows", true);

    }

    public static void BuildForAndroid()
    {
        Build("Android", true);
    }

    public static void BuildForAndroid2()
    {
        Build("Android", false);
    }

    public static void BuildForIOS()
    {
        Build("Ios", false);
    }

    private static void Build(string platfrom, bool rebuild_ab)
    {
        //如果非编辑器状态的PC端就设置为不在后台跑
// #if (UNITY_STANDALONE_WIN == true)
//         Application.runInBackground = false;
// #endif
        string currentPath = System.Environment.CurrentDirectory;
        string buildPath = Path.Combine(currentPath, "Build/" + platfrom + "/");
        DirectoryInfo dir = new DirectoryInfo(buildPath);
        if (dir.Exists)
            dir.Delete(true);
        else
            dir.Create();

        // regenerate xlua code
        Generator.ClearAll();
        Generator.GenAll();

        if (rebuild_ab)
        {
            BuildAssetBundles();
        }

        // copy version.manifest to target
        CopyVersionFile(Config.AB_Build_Path);

        List<string> levels = new List<string>();
        levels.Add("Assets/Scenes/Launch.unity");
        // foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes) {
        //     if (!scene.enabled)
        //         continue;
        //     levels.Add(scene.path);
        // }

        BuildPlayerOptions option = new BuildPlayerOptions();
        option.scenes = levels.ToArray();
        option.locationPathName = buildPath + Application.productName;
        if (platfrom == "Windows")
        {
            option.locationPathName += ".exe";
            option.target = BuildTarget.StandaloneWindows64;
        }
        else if (platfrom == "Android")
        {
            option.locationPathName += ".apk";
            option.target = BuildTarget.Android;

        }
        else if (platfrom == "Ios")
        {
            // option.locationPathName += ".ipa";
            option.target = BuildTarget.iOS;
        }
        option.options = BuildOptions.None;

        BuildReport report = BuildPipeline.BuildPlayer(option);
        BuildSummary summary = report.summary;

        if (summary.result == BuildResult.Succeeded)
        {
            Debug.Log("Build succeeded: " + summary.totalSize + " bytes" + " output:" + summary.outputPath);
            // Application.runInBackground = true;
        }
        else if (summary.result == BuildResult.Failed)
        {
            Debug.LogError("Build failed! total errors:" + summary.totalErrors);
            // Application.runInBackground = true;
        }

    }

    private static void CopyVersionFile(string TargetPath)
    {
        string verfile = Path.Combine(System.Environment.CurrentDirectory, "Assets/version.manifest");
        string tgtfile = Path.Combine(System.Environment.CurrentDirectory, TargetPath + "/version.manifest");

        File.Copy(verfile, tgtfile, true);
        Debug.Log("copy verfile from:" + verfile + " to:" + tgtfile);
    }

    public static void BuildAssetBundles()
    {
        AssetBundleBuilder builder = new AssetBundleBuilder(Config.AB_Build_Path, Config.AssetBundleBuildRulePath);
        builder.Begin();
        builder.ParseRule();
        builder.Export();
        builder.End();
        Debug.Log("Build AssetBundles OK!");
    }

}