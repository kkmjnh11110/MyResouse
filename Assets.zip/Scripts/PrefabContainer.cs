﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabContainer : MonoBehaviour
{
    [Serializable]
    public struct PrefabPair
    {
        public string name;
        public GameObject prefab;
    }
    public PrefabPair[] prefabs;

    [Serializable]
    public struct PrefabsPair
    {
        public string name;
        public GameObject[] prefabs;
    }
    public PrefabsPair[] prefabsArr;

    Dictionary<string, GameObject> prefabDic = new Dictionary<string, GameObject>();
    Dictionary<string, GameObject[]> prefabsDic = new Dictionary<string, GameObject[]>();

    private void Awake()
    {
        for (int i = 0; i < prefabs.Length; i++)
        {
            if (!prefabDic.ContainsKey(prefabs[i].name))
            {
                prefabDic.Add(prefabs[i].name, prefabs[i].prefab);
            }
        }

        for (int i = 0; i < prefabsArr.Length; i++)
        {
            if (!prefabsDic.ContainsKey(prefabsArr[i].name))
            {
                prefabsDic.Add(prefabsArr[i].name, prefabsArr[i].prefabs);
            }
        }
    }

    public GameObject Get(string name)
    {
        return prefabDic[name];
    }

    public GameObject[] GetArr(string name)
    {
        return prefabsDic[name];
    }
}
