using System;
using System.Collections.Generic;
using UnityEngine;

namespace TJ {
    public static class UpdateManager {
        public delegate void UpdateFunc(float deltaTime);

        private class UpdateHolder : MonoBehaviour {
            private LinkedList<UpdateFunc> updateList = new LinkedList<UpdateFunc>();
            public void Update() {
                var node = updateList.First;
                var deltaTime = Time.deltaTime;
                while (node != null) {
                    node.Value(deltaTime);
                    node = node.Next;
                }
            }

            public LinkedListNode<UpdateFunc> RemoveNode(LinkedListNode<UpdateFunc> node) {
                var currentNode = node;
                node = node.Next;
                updateList.Remove(currentNode);
                return node;
            }

            public LinkedListNode<UpdateFunc> AddUpdateFunc(UpdateFunc func) {
                return updateList.AddLast(func);
            }

            public int GetFuncCount() {
                return updateList.Count;
            }
        }

        private static UpdateHolder _runner;
        private static UpdateHolder runner {
            get {
                if (_runner == null) {
                    _runner = new GameObject("Static Update Holder").AddComponent<UpdateHolder>();
                    UnityEngine.Object.DontDestroyOnLoad(_runner);
                }
                return _runner;
            }
        }

        public static LinkedListNode<UpdateFunc> AddUpdateFunc(UpdateFunc func) {
            return runner.AddUpdateFunc(func);
        }

        public static int GetFuncCount() {
            return runner.GetFuncCount();
        }

        public static void RemoveUpdateFunc(LinkedListNode<UpdateFunc> node) {
            try {
                if (_runner == null) {
                    return;
                }
                runner.RemoveNode(node);
            } catch (Exception e) {
                Debug.LogFormat("remove node exception: {0}", e);
            }
        }
    }
}