using System;
using UnityEngine;
using XLua;

namespace TJ {

    namespace Timer {

        [CSharpCallLua]
        public delegate void TimeOutAction();

        public class TimerHandler {
            Action stopFunc;
            public Action onStopped;
            public TimerHandler(Action stop) {
                stopFunc = stop;
            }

            public void Stop() {
                stopFunc();
            }

            public void OnStopped(Action f) {
                stopFunc += f;
            }
        }

        internal class TimeData : IComparable<TimeData>, IUserData<int> {
            public float timeStarted;

            public float timeOut;

            public float peroid;

            public TimeOutAction timeOutAction;

            public int UserData { get; set; }

            public int CompareTo(TimeData other) {
                if (timeOut > other.timeOut)
                    return 1;
                return -1;
            }

            public bool IsTimeOut(float curTime) {
                return curTime >= timeOut;
            }

            public bool OnTimeOut() {
                timeOutAction();
                if (peroid == 0.0) {
                    return false;
                }
                timeOut += peroid;
                return true;
            }
        }

        public static class DefaultTimerMgr {
            public static TimerManager defaultMgr = new TimerManager();

            public static void Init() {
                UpdateManager.AddUpdateFunc(defaultMgr.Update);
            }
        }

        public class TimerManager {
            private float curTime;
            private readonly Heap<TimeData> timerList = new Heap<TimeData>(64);

            public void Reset() {
                timerList.Clear();
            }

            public TimerHandler StartTimer(float seconds, TimeOutAction action) {
                var timeData = new TimeData() {
                    timeOut = curTime + seconds,
                    timeStarted = curTime,
                    timeOutAction = action,
                };
                timerList.Push(timeData);

                return new TimerHandler(() => { timerList.Remove(timeData); });
            }

            public TimerHandler StartTicker(float seconds, TimeOutAction action) {
                var timeData = new TimeData() {
                    timeOut = curTime + seconds,
                    timeStarted = curTime,
                    peroid = seconds,
                    timeOutAction = action,
                };
                timerList.Push(timeData);
                return new TimerHandler(() => { timeData.peroid = 0; timerList.Remove(timeData); });
            }

            public void Update(float deltaTime) {
                curTime += deltaTime;

                while (timerList.HasElem()) {
                    var top = timerList.Peek();
                    if (!top.IsTimeOut(curTime)) {
                        return;
                    }
                    timerList.Pop();
                    try {
                        if (top.OnTimeOut()) {
                            timerList.Push(top);
                        };
                    } catch (Exception ex) {
                        Debug.Log("Process timer exception " + ex);
                    }
                }
            }
        }
    }
}