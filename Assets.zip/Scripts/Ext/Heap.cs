using System;
using UnityEngine;

namespace TJ {

    public interface IUserData<T> {
        T UserData { get; set; }
    }

    public class Heap<T> where T : IComparable<T>, IUserData<int> {
        private T[] container_;
        private int size_;
        private int currentCap_;

        public Heap(int capacity) {
            container_ = new T[capacity];
            currentCap_ = capacity;
            size_ = 0;
        }

        public void Clear() {
            size_ = 0; // just ignore dirty data
        }

        private void ensureCap(int minCap) {
            if (currentCap_ > minCap) {
                return;
            }
            currentCap_ *= 2;
            Array.Resize<T>(ref container_, currentCap_);
        }

        private void up(int j) {
            while (true) {
                var i = (j - 1) / 2; //parent
                if (i == j)
                    break;
                var iElem = container_[i];
                var jElem = container_[j];
                if (jElem.CompareTo(iElem) > 0) {
                    break;
                }
                swap(i, j);
                j = i;
            }
        }

        private void swap(int i, int j) {
            var iElem = container_[i];
            var jElem = container_[j];
            container_[i] = jElem;
            container_[j] = iElem;
            jElem.UserData = i;
            iElem.UserData = j;
        }

        private bool down(int start, int n) {
            var i = start;
            while (true) {
                var j = 2 * i + 1;
                if (j >= n || j < 0)
                    break;
                var iElem = container_[i];
                var leftChild = j;
                var rightChild = j + 1;
                if (rightChild < n) {
                    var lElem = container_[leftChild];
                    var rElem = container_[rightChild];
                    if (rElem.CompareTo(lElem) < 0) {
                        j = rightChild;
                    }
                }
                var jElem = container_[j];
                if (jElem.CompareTo(iElem) > 0) {
                    break;
                }
                swap(i, j);
                i = j;
            }
            return i > start;
        }

        public bool HasElem() {
            return size_ > 0;
        }

        public void Push(T elem) {
            ensureCap(size_ + 1);
            elem.UserData = size_;
            container_[size_++] = elem;
            up(size_ - 1);
        }

        public T Pop() {
            if (!HasElem()) {
                return default(T);
            }
            swap(0, size_ - 1);
            down(0, size_ - 1);
            var last = container_[size_ - 1];
            size_--;
            last.UserData = -1;
            return last;
        }

        public T Peek() {
            return container_[0];
        }

        public T Remove(T elem) {
            if (elem.UserData < 0) {
                return elem;
            }
            return RemoveAt(elem.UserData);
        }

        private T RemoveAt(int idx) {
            var n = size_ - 1;
            if (n != idx) {
                swap(idx, n);
                if (!down(idx, n)) {
                    up(idx);
                }
            }
            size_--;
            var elem = container_[n];
            container_[n] = default(T);
            elem.UserData = -1;
            return elem;
        }
    }
}