﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.UI.Extensions;
using XLua;

public static class UnityEventTool
{
    public static UnityAction Add(UnityEvent _event, LuaFunction func)
    {
        UnityAction action = () =>
        {
            func.Action();
        };
        _event.AddListener(action);
        return action;
    }

    //EventTrigger
    public static UnityAction<BaseEventData> Add(EventTrigger.TriggerEvent _event, LuaFunction func)
    {
        UnityAction<BaseEventData> action = (BaseEventData eventData) =>
        {
            func.Action(eventData);
        };
        _event.AddListener(action);
        return action;
    }

    //Button
    public static UnityAction Add(Button.ButtonClickedEvent _event, LuaFunction func)
    {
        UnityAction action = () =>
        {
            func.Action();
        };
        _event.AddListener(action);
        return action;
    }

    //Slider
    public static UnityAction<float> Add(Slider.SliderEvent _event, LuaFunction func)
    {
        UnityAction<float> action = (float value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //Toggle
    public static UnityAction<bool> Add(Toggle.ToggleEvent _event, LuaFunction func)
    {
        UnityAction<bool> action = (bool value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //Dropdown
    public static UnityAction<int> Add(Dropdown.DropdownEvent _event, LuaFunction func)
    {
        UnityAction<int> action = (int value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //InputField
    public static UnityAction<string> Add(InputField.OnChangeEvent _event, LuaFunction func)
    {
        UnityAction<string> action = (string value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    public static UnityAction<string> Add(InputField.SubmitEvent _event, LuaFunction func)
    {
        UnityAction<string> action = (string value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //DragEventTrigger
    public static UnityAction<PointerEventData> Add(DragEventTrigger.DragEvent _event, LuaFunction func)
    {
        UnityAction<PointerEventData> action = (PointerEventData pointerEventData) =>
        {
            func.Action(pointerEventData);
        };
        _event.AddListener(action);
        return action;
    }

    public static UnityAction<List<GameObject>> Add(DragEventTrigger.DropEvent _event, LuaFunction func)
    {
        UnityAction<List<GameObject>> action = (List<GameObject> list) =>
        {
            func.Action(list);
        };
        _event.AddListener(action);
        return action;
    }

    //DragEndEventTrigger
    public static UnityAction<PointerEventData> Add(DragEndEventTrigger.DragEvent _event, LuaFunction func)
    {
        UnityAction<PointerEventData> action = (PointerEventData pointerEventData) =>
        {
            func.Action(pointerEventData);
        };
        _event.AddListener(action);
        return action;
    }

    //LoopScrollRect
    public static UnityAction<Vector2> Add(LoopScrollRect.ScrollRectEvent _event, LuaFunction func)
    {
        UnityAction<Vector2> action = (Vector2 value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }
    
    //TextPic
    public static UnityAction<string> Add(TextPic.HrefClickEvent _event, LuaFunction func)
    {
        UnityAction<string> action = (string value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //ScrollRect
    public static UnityAction<Vector2> Add(ScrollRect.ScrollRectEvent _event, LuaFunction func)
    {
        UnityAction<Vector2> action = (Vector2 value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }

    //ScrollBar
    public static UnityAction<float> Add(Scrollbar.ScrollEvent _event, LuaFunction func)
    {
        UnityAction<float> action = (float value) =>
        {
            func.Action(value);
        };
        _event.AddListener(action);
        return action;
    }
}
