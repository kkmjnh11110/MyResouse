﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using Newtonsoft.Json;
using TJ;
using UnityEngine;
using UnityEngine.Networking;
#if UNITY_EDITOR
using UnityEditor;
#endif

// 支持断点续传的自定义downloadhandler类 (未调用SetWebRequest就是普通非断点续传下载)
public class DownloadHandlerFileEx : DownloadHandlerScript {
    private string target_file;
    private UnityWebRequest web_request;
    private long local_file_size = 0;
    private long total_file_size = 0;
    private long cur_file_size = 0;
    private float last_time = 0;
    private float last_file_size = 0;
    private float download_speed = 0;

    Action<string> progress_info_callback = null;

    // 构造函数，提供1M缓冲区用于下载数据
    public DownloadHandlerFileEx(string path, Action<string> cb) : base(new byte[1024 * 1024]) {
        target_file = path;
        progress_info_callback = cb;

    }

    public string FileName {
        get {
            return Path.GetFileName(target_file);
        }
    }

    // 下载速度
    public float Speed {
        get {
            return ((int)(download_speed / 1024 * 100)) / 100.0f; // 单位 kB/s
        }
    }

    // 文件大小
    public long FileSize {
        get {
            return total_file_size;
        }
    }

    // 获取下载进度
    public float DownloadProgress {
        get {
            return GetProgress();
        }
    }

    // 设置untiyWebRequest使用断点续传模式。
    public void SetWebRequest(UnityWebRequest req) {
        web_request = req;
        if (File.Exists(target_file)) {
            local_file_size = new System.IO.FileInfo(target_file).Length;
        }
        cur_file_size = local_file_size;
        web_request.SetRequestHeader("Range", "bytes=" + local_file_size + "-");
        Debug.LogFormat("file:{0} set_range:{1}", target_file, local_file_size);
    }

    protected override void CompleteContent() {
        download_speed = 0.0f;
        progress_info_callback = null;
        base.CompleteContent();
    }

    protected override byte[] GetData() {
        return null;
    }

    protected override float GetProgress() {
        return total_file_size == 0 ? 0 : ((float)cur_file_size) / total_file_size;
    }

    protected override string GetText() {
        return null;
    }

    protected override void ReceiveContentLength(int content_length) {
        string content_length_str = "";
        if (web_request != null)
            content_length_str = web_request.GetResponseHeader("Content-Length");
        if (!string.IsNullOrEmpty(content_length_str)) {

            try {
                total_file_size = long.Parse(content_length_str);
            } catch (System.FormatException e) {
                Debug.Log("parse content_length failed str:" + content_length_str + "," + e.Message);
                total_file_size = content_length;
            } catch (System.Exception e) {
                Debug.Log("parse content_length failed str:" + content_length_str + "," + e.Message);
                total_file_size = content_length;
            }
        } else {
            total_file_size = content_length;
        }
        total_file_size += local_file_size;
        last_time = UnityEngine.Time.time;
        last_file_size = cur_file_size;
        UpdateInfo();
        Debug.LogFormat("file:{0} total filesize:{1} last_file_size:{2} content_length:{3}", target_file, total_file_size, last_file_size, content_length);

    }

    protected override bool ReceiveData(byte[] data, int length) {
        if (data == null || length == 0) {
            return false;
        }
        if (web_request != null && (web_request.responseCode != 206 && web_request.responseCode != 200)) {
            Debug.LogFormat("http response code:{0} data_len:{1}", web_request.responseCode, length);
            return false;
        }
        // if( web_request != null )
        //     Debug.LogFormat("http response code:{0} data_len:{1}",web_request.responseCode,length);
        // else
        //     Debug.LogFormat("http response data_len:{0}",length);
        FileStream fs = null;
        if (cur_file_size == 0)
            fs = new FileStream(target_file, FileMode.Create, FileAccess.Write);
        else
            fs = new FileStream(target_file, FileMode.Append, FileAccess.Write);

        // string str = System.Text.Encoding.Default.GetString( data );
        // Debug.Log("data:"+str);
        fs.Write(data, 0, length);
        cur_file_size += length;
        // calc download speed
        if (UnityEngine.Time.time - last_time >= 0.1f || cur_file_size >= total_file_size) {
            float delta = UnityEngine.Time.time - last_time;
            if (delta < 0.1)
                delta = 0.1f;
            download_speed = (cur_file_size - last_file_size) / delta;
            last_time = UnityEngine.Time.time;
            last_file_size = cur_file_size;
            UpdateInfo();
        }
        fs.Flush();
        fs.Dispose();
        fs = null;
        return true;

    }

    void UpdateInfo() {
        if (progress_info_callback != null) {
            var info = new { fn = FileName, size = FileSize, progress = (int)(DownloadProgress * 100), speed = Speed };
            var t = new { t = 1, i = info };
            progress_info_callback(JsonConvert.SerializeObject(t));
        }
    }

}

public class VERSION_MANIFEST {
    public string version { get; set; }
}

public class PROJECT_ASSET {
    public string file { get; set; }
    public bool compressed { get; set; }
    public string md5 { get; set; }
    public int size { get; set; }
    public string ver { get; set; }
    public string redirect_uri { get; set; }
}

public class PROJECT_MANIFEST {
    public List<PROJECT_ASSET> assets { get; set; }
    public string packageUrl { get; set; }
    public string remoteManifestUrl { get; set; }
    public string remoteVersionUrl { get; set; }
    // public string searchPaths { get; set; }
    public string gitVersion { get; set; }
    public string version { get; set; }
}

public struct VersionInfo {
    public string local_version;
    public string version_manifest_uri;
    public string project_manifest_uri;
}

public class Updater : MonoBehaviour {
    VersionInfo vi = new VersionInfo();
    string remote_version = "";
    string package_url = "";
    string patch_dir = "";
    string tmp_dir = "";
    int flag = 0;

    int total_download_size = 0;

    Action<string> progress_info_callback = null;
    Action<string, string> version_update_callback = null;
    Action<long, string> error_callback = null;

    List<PROJECT_ASSET> assets_infos = new List<PROJECT_ASSET>();

    void DownloadOneFile(string uri, DownloadHandler handler, Action<UnityWebRequest> cb) {
        StartCoroutine(Proc(uri, handler, cb));
    }

    IEnumerator Proc(string uri, DownloadHandler handler, Action<UnityWebRequest> cb) {
        // uri add some salt 
        uri = uri + "?" + UnityEngine.Random.Range(100, 9999);
        //Debug.Log("uri:"+uri);
        UnityWebRequest req = new UnityWebRequest(uri);
        req.chunkedTransfer = true;
        req.disposeDownloadHandlerOnDispose = true;
        req.downloadHandler = handler;
        //req.redirectLimit = 32; // default value
        //req.timeout = 0; // default timeout value : no timeout
        if (handler.GetType() == typeof(DownloadHandlerFileEx)) {
            DownloadHandlerFileEx t = (DownloadHandlerFileEx)handler;
            t.SetWebRequest(req);
        }
        yield return req.SendWebRequest();
        if (req.isNetworkError || req.isHttpError) {
            Debug.LogError(req.error+" uri:"+req.uri);
            cb(req);
        } else {
            cb(req);
        }
        req.Dispose();
    }
    void Start() {
        // VersionInfo vi = new VersionInfo {
        //     local_version = "0.0.9",
        //     version_manifest_uri = "http://cdnsrc1.taojingame.com/dungeon3/t1/info/version.manifest",
        //     project_manifest_uri = "http://cdnsrc1.taojingame.com/dungeon3/t1/info/project.manifest"
        // };
        // Init(vi, ShowDownloadInfo, onVersionUpdated, onError);
        //Begin();        
    }

    void OnDestroy() {
        // this.vi = null;
        progress_info_callback = null;
        version_update_callback = null;
        error_callback = null;
    }

    // 初始化更新需要的信息和设置更新回调函数
    // vi : 版本信息
    // cb : 更新进度信息回调,参数是：json字符串 cb2 : 版本更新成功回调 参数表示 <旧版本，新版本>,需要调用者更新本地存储的版本信息记录。
    // cb3 : 错误信息回调， <错误码,错误信息>  错误码等于0表示更新正常完成。
    public void Init(VersionInfo vi, Action<string> cb, Action<string, string> cb2, Action<long, string> cb3) {
        this.vi = vi;
        progress_info_callback = cb;
        version_update_callback = cb2;
        error_callback = cb3;
        // 获取更新信息
        Prepare();
        Debug.Log("local ver:" + vi.local_version);
        DownloadOneFile(vi.version_manifest_uri, new DownloadHandlerBuffer(), onGetVersionFile);
    }

    // 开始更新
    public void Begin() {
        if (CompareVersion(vi.local_version, remote_version) < 0)
            DownloadPackages();
        else {
            error_callback(0, "ok");
        }
    }

    // 获得游戏包内的默认版本信息字符串(json),
    public string GetDefaultVersionString() {
#if UNITY_EDITOR
        string file_path = "Assets/version.manifest";
        TextAsset jstr = (TextAsset)AssetDatabase.LoadAssetAtPath(file_path, typeof(TextAsset));
        if (jstr != null) {
            string ret = System.Text.Encoding.UTF8.GetString(jstr.bytes);
            return ret;
        }
#else
        string file_path = Path.Combine(ResourceUtils.AssetBundleFolder, "version.manifest");
        if (!ResourceUtils.IsStreamingAssetsExists(file_path))
            return "";
        byte[] jstr = ResourceUtils.LoadFromStreamingAssets(file_path);
        if (jstr != null) {
            string ret = System.Text.Encoding.UTF8.GetString(jstr);
            return ret;
        }
#endif
        return "";
    }

    void Prepare() {
        remote_version = "";
        total_download_size = 0;
        package_url = "";
        flag = 0;
        tmp_dir = Path.Combine(Application.persistentDataPath, "tmp");
        DirectoryInfo di = new DirectoryInfo(tmp_dir);
        di.Create();
        Debug.Log("tmp_dir:" + tmp_dir);
        patch_dir = ResourceUtils.HotUpdatePath;
        di = new DirectoryInfo(patch_dir);
        di.Create();
        Debug.Log("patch_dir:" + patch_dir);
    }

    public void ClearPatchPath() {
        string path = ResourceUtils.HotUpdatePath;
        DirectoryInfo di = new DirectoryInfo(path);
        if (di.Exists) {
            Directory.Delete(path, true);
            Debug.Log("clear patch path:" + path);
        }
    }

    // 0: 相等  -1:小于 1:大于
    int CompareVersion(string one, string two) {
        string[] ones = one.Split('.');
        string[] twos = two.Split('.');
        int ln = ones.Length <= twos.Length ? ones.Length : twos.Length;

        try {
            for (int i = 0; i < ln; i++) {
                if (Convert.ToInt32(ones[i]) == Convert.ToInt32(twos[i]))
                    continue;
                if (Convert.ToInt32(ones[i]) > Convert.ToInt32(twos[i]))
                    return 1;
                return -1;
            }
        } catch (FormatException e) {
            Debug.Log(e.Message + " one:" + one + " two:" + two);
            return 0;
        }
        return ones.Length >= twos.Length ? 0 : -1;
    }

    void onGetVersionFile(UnityWebRequest req) {
        if (req.isNetworkError || req.isHttpError) {
            error_callback(req.responseCode != 0 ? req.responseCode : -1, req.error);
            return;
        } else {
            // Debug.Log(req.downloadHandler.text);
            VERSION_MANIFEST vf = null;
            try {
                vf = JsonConvert.DeserializeObject<VERSION_MANIFEST>(req.downloadHandler.text);
            } catch (JsonException e) {
                Debug.LogError(e.ToString());
                error_callback(-1, e.ToString());
                return;
            }
            Debug.LogFormat("remote ver:{0} {1}", vf.version, CompareVersion(vi.local_version, vf.version));
            if (CompareVersion(vi.local_version, vf.version) < 0) {
                DownloadOneFile(vi.project_manifest_uri, new DownloadHandlerBuffer(), onGetProjectFile);
            } else {
                Debug.Log("local version >= remote version. can skip download patch!");
                remote_version = vf.version;
                object info = new { count = 0, size = 0 };
                object t = new { t = 0, i = info };
                progress_info_callback(JsonConvert.SerializeObject(t));
            }
        }
    }

    void CollectDownloadInfo(PROJECT_MANIFEST pf) {
        assets_infos = new List<PROJECT_ASSET>();
        package_url = pf.packageUrl;
        remote_version = pf.version;
        total_download_size = 0;
        foreach (PROJECT_ASSET one in pf.assets) {
            if (CompareVersion(vi.local_version, one.ver) >= 0)
                continue;
            assets_infos.Add(one);
            total_download_size += one.size;
        }

        object info = new { count = assets_infos.Count, size = total_download_size };
        object t = new { t = 0, i = info };
        progress_info_callback(JsonConvert.SerializeObject(t));
    }

    void onGetProjectFile(UnityWebRequest req) {
        if (req.isNetworkError || req.isHttpError) {
            error_callback(req.responseCode != 0 ? req.responseCode : -1, req.error);
            return;
        } else {
            //Debug.LogFormat("file:{0}",req.downloadHandler.text);
            PROJECT_MANIFEST pf = null;
            try {
                pf = JsonConvert.DeserializeObject<PROJECT_MANIFEST>(req.downloadHandler.text);
            } catch (JsonException e) {
                Debug.LogError(e.ToString());
                error_callback(-1, e.ToString());
                return;
            }
            CollectDownloadInfo(pf);
            Debug.LogFormat("pf=> need_download_assets_count:{0} remote_version:{1} packUrl:{2}", assets_infos.Count, remote_version, package_url);
        }
    }

    void DownloadPackages() {
        if (flag >= assets_infos.Count) {
            error_callback(0, "ok");
            return;
        }
        PROJECT_ASSET one = assets_infos[flag];
        string remote_file = package_url + one.file;
        if (!string.IsNullOrEmpty(one.redirect_uri))
            remote_file = one.redirect_uri;
        string local_file = Path.Combine(tmp_dir, one.file);
        long size = 0;
        // 本地文件大小检查，如果已经下载就跳过下载流程（需要测试续传416错误可暂时屏蔽）
        if (File.Exists(local_file)) {
            size = new System.IO.FileInfo(local_file).Length;
        }
        if (size >= (long)one.size) {
            Debug.Log("local_file existed,no need download! ");
            onDownloaded(null);
        } else {
            DownloadOneFile(remote_file, new DownloadHandlerFileEx(Path.Combine(tmp_dir, one.file), progress_info_callback), onDownloaded);
        }
    }

    bool unzipFile(string zip_file) {

        object info = new { pkg = zip_file, tgt = patch_dir };
        object t = new { t = 2, i = info };
        progress_info_callback(JsonConvert.SerializeObject(t));

        FastZip fastZip = new FastZip();
        string fileFilter = null;
        // Will always overwrite if target filenames already exist
        fastZip.ExtractZip(zip_file, patch_dir, fileFilter);
        Debug.Log("extract zip file:" + zip_file + " to target:" + patch_dir + " ok!");
        return true;
    }

    void onDownloaded(UnityWebRequest req) {
        if (req != null && ((req.isNetworkError || req.isHttpError) && req.responseCode != 416)) {
            // use redirect uri download again.
            if (req.responseCode == 301 || req.responseCode == 302) {
                string redirect_uri = req.GetResponseHeader("Location");
                if (!string.IsNullOrEmpty(redirect_uri)) {
                    Debug.Log("http err:" + req.error + " uri redirect_to:" + redirect_uri);
                    assets_infos[flag].redirect_uri = redirect_uri;
                    DownloadPackages();
                    return;
                }
            }

            error_callback(req.responseCode != 0 ? req.responseCode : -1, req.error);
            return;
        }
        PROJECT_ASSET one = assets_infos[flag];
        bool isCompressed = one.compressed;
        string md5 = one.md5;
        string new_version = one.ver;
        string file = Path.Combine(tmp_dir, one.file);
        Debug.Log("downloaded file " + file);
        // check md5
        if (BuildFileMd5(file) != md5) {
            string info = "md5 check failed! delete tmp file:" + file;
            Debug.Log(info);
            File.Delete(file);
            error_callback(-2, info);
            return;
        }
        if (!unzipFile(file)) {
            Debug.LogError("can't unzip file:" + file + " to target!");
            return;
        }
        flag += 1;
        version_update_callback(vi.local_version, new_version);
        vi.local_version = new_version;
        DownloadPackages();
    }

    void ShowDownloadInfo(string json_str) {
        dynamic jobj = JsonConvert.DeserializeObject(json_str);
        int type = (int)jobj["t"];
        if (type == 0) {
            StartCoroutine(delayProc(() => { Begin(); }));
        }
        Debug.Log("download info:" + json_str);
    }

    IEnumerator delayProc(Action ddd) {
        yield return null;
        ddd();
    }

    void onVersionUpdated(string old_version, string new_version) {
        Debug.LogFormat("vi.local_version from:{0} to {1}", vi.local_version, new_version);
    }

    string BuildFileMd5(string filename) {
        string filemd5 = null;
        try {
            using(var fileStream = File.OpenRead(filename)) {
                var md5 = System.Security.Cryptography.MD5.Create();
                var fileMD5Bytes = md5.ComputeHash(fileStream);
                filemd5 = System.BitConverter.ToString(fileMD5Bytes).Replace("-", "").ToUpper();
                Debug.Log(filename + " md5:" + filemd5);
            }
        } catch (System.Exception ex) {
            Debug.LogError("can't calc file:" + filename + " md5! exception:" + ex.ToString());
        }
        return filemd5;
    }

    void onError(long errno, string info) {
        if (errno == 0) {
            // update all ok!
            Debug.Log("update ok!");
        } else {
            // update failed! try again?
            Debug.LogFormat("errno:{0}, info:{1}", errno, info);
        }
    }

}