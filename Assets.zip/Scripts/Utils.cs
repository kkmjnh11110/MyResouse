﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Spine.Unity;
using XLua;
using TJ;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class Utils
{
    //获取毫秒级别的时间戳, 是自从1970.1.1以来的毫秒数
    public static long GetTimeStamp()
    {
        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
        return Convert.ToInt64(ts.TotalMilliseconds);
    }

    public static void DestroyAllChildren(Transform transform)
    {
        foreach (Transform child in transform)
        {
            UnityEngine.Object.Destroy(child.gameObject);
        }
        transform.DetachChildren();
    }

    public static Tweener DOTweenDelay(float tm)
    {
        float myFloat = 0.0f;
        return DOTween.To(() => myFloat, x => myFloat = x, 0.0f, tm);
    }

    //endValue取值 0 ~ 1
    public static TweenerCore<float, float, FloatOptions> DOFade(this SkeletonAnimation target, float endValue, float duration)
    {
        TweenerCore<float, float, FloatOptions> t = DOTween.To(() => target.skeleton.A, x => target.skeleton.A = x, endValue, duration);
        t.SetTarget(target);
        //target.DOKill
        //t.OnComplete()
        //target.transform.DOMoveX(1,1).OnComplete()
        return t;
    }

    public static TweenerCore<Color, Color, ColorOptions> DOColor(this SkeletonAnimation target, Color endValue, float duration)
    {
        TweenerCore<Color, Color, ColorOptions> t = DOTween.To(
            () => {
                return new Color(target.skeleton.R, target.skeleton.G, target.skeleton.B, target.skeleton.A);
            }, 
            x => {
                target.skeleton.R = x.r;
                target.skeleton.G = x.g;
                target.skeleton.B = x.b;
                target.skeleton.A = x.a;
            },
            endValue, duration);
        t.SetTarget(target);
        return t;
    }

    public static float GetClipLength(this Animator animator, string clip)
    {
        if (null == animator || string.IsNullOrEmpty(clip) || null == animator.runtimeAnimatorController)
            return 0;

        RuntimeAnimatorController ac = animator.runtimeAnimatorController;
        AnimationClip[] tAnimationClips = ac.animationClips;
        if (null == tAnimationClips || tAnimationClips.Length <= 0) return 0;
        AnimationClip tAnimationClip;
        for (int tCounter = 0, tLen = tAnimationClips.Length; tCounter < tLen; tCounter++)
        {
            tAnimationClip = ac.animationClips[tCounter];
            if (null != tAnimationClip && tAnimationClip.name == clip)
                return tAnimationClip.length;
        }
        return 0;
    }

    public static object AnalysisJsonStr(string strJson)
    {
        bool JTokenIsArray(JToken jToken)
        {
            return jToken.Type == JTokenType.Array;
        }

        bool JTokenIsInArray(JToken jToken)
        {
            return jToken.Parent != null && JTokenIsArray(jToken.Parent);
        }

        bool JTokenIsInArrayAndIsNull(JToken jToken)
        {
            return JTokenIsInArray(jToken) &&
                (jToken.Type == JTokenType.None || jToken.Type == JTokenType.Null || jToken.Type == JTokenType.Undefined);
        }

        object AnalysisJTokenToLuaTable(JToken jToken)
        {
            //特殊处理jToken为array时，jp.Value为null时需要转换为false
            if (JTokenIsInArrayAndIsNull(jToken))
            {
                return false;
            }

            if (JTokenIsArray(jToken))
            {
                return AnalysisJArrayToLuaTable(JArray.FromObject(jToken));
            }

            if (JTokenIsInArray(jToken))
            {
                return GetJTokenValue(jToken);
            }

                        LuaTable luaTable = LuaManager.Instance.LuaEnv.NewTable();
            foreach (JProperty jp in jToken)
            {
                object value = GetJTokenValue(jp.Value);
                luaTable.Set(jp.Name, value);
            }
            return luaTable;
        }

        LuaTable AnalysisJArrayToLuaTable(JArray jArray)
        {
            LuaTable luaTable = LuaManager.Instance.LuaEnv.NewTable();
            int index = 1;
            foreach (JToken jToken in jArray)
            {
                luaTable.Set(index, AnalysisJTokenToLuaTable(jToken));
                index++;
            }
            return luaTable;
        }

        object GetJTokenValue(JToken jToken)
        {
            switch (jToken.Type)
            {
                case JTokenType.Array:
                    return AnalysisJArrayToLuaTable(JArray.FromObject(jToken));
                case JTokenType.Integer:
                    return jToken.ToObject<int>();
                case JTokenType.Float:
                    return jToken.ToObject<double>();
                case JTokenType.Null:
                case JTokenType.None:
                    //空值的话返回null
                    return null;
                case JTokenType.Object:
                    return AnalysisJTokenToLuaTable(JToken.FromObject(jToken));
                case JTokenType.Boolean:
                    return jToken.ToObject<bool>();
                default:
                    return jToken.ToObject<string>();
            }
        }

        return AnalysisJTokenToLuaTable(JToken.Parse(strJson));
    }
}
