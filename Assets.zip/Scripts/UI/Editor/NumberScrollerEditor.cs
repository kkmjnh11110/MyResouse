﻿using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(NumberScroller), true)]
public class NumberScrollerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        EditorGUILayout.Space();

        //NumberScroller scroll = (NumberScroller)target;

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("重置"))
        {
            ResetNumber();
        }
        if (GUILayout.Button("设置为随机数"))
        {
            SetToRandomNumber();
        }
        if (GUILayout.Button("滚动到随机数"))
        {
            ScrollToRandomNum();
        }
        if (GUILayout.Button("动画"))
        {
            ScrollAnimateTest();
        }
        if (GUILayout.Button("多次动画"))
        {
            ScrollSeveralTimeTest();
        }

        EditorGUILayout.EndHorizontal();
    }

    private void ResetNumber()
    {
        NumberScroller scroll = (NumberScroller)target;
        scroll.ResetNumber();
    }

    private void SetToRandomNumber()
    {
        int number = Random.Range(0, 10000);
        Debug.Log("随机数是:" + number);
        NumberScroller scroll = (NumberScroller)target;
        scroll.SetNumberWithGenerateText(number);
    }

    private void ScrollToRandomNum()
    {
        int number = UnityEngine.Random.Range(0, 1000000);
        Debug.Log("随机数是:" + number);
        NumberScroller scroll = (NumberScroller)target;
        if (Application.isPlaying)
        {
            scroll.ScrollToNumber(number);
        }
        else
        {
            scroll.SetNumberWithGenerateText(number);
        }
    }
    private void ScrollAnimateTest()
    {
        ResetNumber();
        ScrollToRandomNum();
    }

    private void ScrollSeveralTimeTest()
    {
        NumberScroller scroll = (NumberScroller)target;
        scroll.ResetNumber();
        ScrollToRandomNum();
        ScrollToRandomNum();
        ScrollToRandomNum();
    }
}