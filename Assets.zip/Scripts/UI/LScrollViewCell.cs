﻿using UnityEngine;
using UnityEngine.UI;
using TJ;
using FancyScrollView;

public class LScrollViewCell : FancyScrollViewCell<int, LScrollViewContext>
{
    private float currentPosition = 0;

    [SerializeField]
    Button button = null;

    private bool isInitFinished = false;
    private bool updateContentFailed = false;
    private bool updatePositionFailed = false;
    private int tempItemData = -1;

    void Start()
    {
        if (button != null)
        {
            button.onClick.AddListener(OnPressedCell);
        }

        if (Context != null)
        {
            Context.OnCellStart(this);
        }
        else
        {
            Debug.Log("Cell Start Failed:" + gameObject);
        }

        isInitFinished = true;

        if (updateContentFailed)
        {
            UpdateContent(tempItemData);
        }

        if (updatePositionFailed)
        {
            UpdatePosition(currentPosition);
        }
    }

    public override void UpdateContent(int itemData)
    {
        if (!isInitFinished)
        {
            updateContentFailed = true;
            tempItemData = itemData;
            return;
        }

        if (Context != null)
        {
            Context.OnCellUpdateContent(this, itemData);
        }
        else
        {
            Debug.Log("UpdateContent Failed:" + itemData);
        }
    }

    public override void UpdatePosition(float position)
    {
        currentPosition = position;
        if (Context != null)
        {
            Context.OnCellUpdatePosition(this, position);
        }
        else
        {
            updatePositionFailed = true;
        }
    }

    void OnPressedCell()
    {
        if (Context != null)
        {
            Context.OnPressedCell(this);
        }
        else
        {
            Debug.Log("OnPressedCell Failed:"+ gameObject);
        }
    }

    private void OnEnable()
    {
        UpdatePosition(currentPosition);
    }
}
