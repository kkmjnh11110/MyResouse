﻿using System;

public class LScrollViewContext
{
    public Action<LScrollViewCell> OnCellStart;
    public Action<LScrollViewCell, int> OnCellUpdateContent;
    public Action<LScrollViewCell, float> OnCellUpdatePosition;
    public Action<LScrollViewCell> OnPressedCell;

    public int SelectedIndex = -1;
}
