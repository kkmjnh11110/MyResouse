﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class ArcSlider : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    public Image handleButton;
    public Slider slider;
    public Image progressBar;
    float circleRadius = 0.0f;

    private float m_Value;
    public float value
    {
        get
        {
            return m_Value;
        }
        set
        {
            SetValue(value);
        }
    }

    bool isPointerDown = false;

    //忽略圈内的交互
    public float ignoreInTouchRadiusHandleOffset = 10;

    private RectTransform handleButtonTf;
    Vector3 handleButtonLocation;

    [Tooltip("初始角度到终止角度")]
    public float firstAngle = 30;
    public float secondAngle = 150;

    float tempAngle = 30;//用来缓动
    public void Start()
    {
        handleButtonTf = handleButton.GetComponent<RectTransform>();
        handleButtonLocation = handleButtonTf.localPosition;

        circleRadius = Mathf.Sqrt(Mathf.Pow(handleButtonLocation.x, 2) + Mathf.Pow(handleButtonLocation.y, 2));
        ignoreInTouchRadiusHandleOffset = circleRadius - ignoreInTouchRadiusHandleOffset;
    }
    public void Update()
    {
        //用来重置
        if (Input.GetKeyDown(KeyCode.R))
        {
            ReSet();
        }
    }
    public void ReSet()
    {
        handleButtonTf.localPosition = handleButtonLocation;
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        StartCoroutine("TrackPointer");
    }

    //如果需要移动到外部时仍然有效可以去掉这里的
    public void OnPointerExit(PointerEventData eventData)
    {
        StopCoroutine("TrackPointer");
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        isPointerDown = true;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isPointerDown = false;
    }

    IEnumerator TrackPointer()
    {
        var ray = GetComponentInParent<GraphicRaycaster>();
        var input = FindObjectOfType<StandaloneInputModule>();

        if (ray != null && input != null)
        {
            while (Application.isPlaying)
            {
                //这个是左侧的
                if (isPointerDown)
                {
                    Vector2 localPos;
                    //获取鼠标当前位置out里赋值
                    RectTransformUtility.ScreenPointToLocalPointInRectangle(transform as RectTransform, Input.mousePosition, ray.eventCamera, out localPos);

                    localPos.x = -localPos.x;

                    //半径
                    float mouseRadius = Mathf.Sqrt(localPos.x * localPos.x + localPos.y * localPos.y);

                    //阻止圆内部点击的响应，只允许在一个圆环上进行响应
                    if (mouseRadius > ignoreInTouchRadiusHandleOffset)// && handleButton.GetComponent<RectTransform>().localPosition.x <= 0
                    {
                        //0-180  -180-0偏移后的角度 从第一象限校正到0-360
                        float angle = (Mathf.Atan2(localPos.y, localPos.x)) * Mathf.Rad2Deg;
                        if (angle < 0) angle = 360 + angle; ;

                        if (angle < firstAngle) angle = firstAngle;
                        if (angle > secondAngle) angle = secondAngle;

                        angle = (tempAngle + angle) / 2f;
                        tempAngle = angle;

                        //数值的偏移值
                        float value = (angle - firstAngle) / (secondAngle - firstAngle);
                        SetValue(value);
                    }
                }
                yield return 0;
            }
        }
    }

    public void SetValue(float value)
    {
        if (m_Value == value)
        {
            return;
        }
        m_Value = value;

        float angle = value * (secondAngle - firstAngle) + firstAngle;

        // 改变滑动块的位置
        handleButtonTf.localPosition = new Vector3(Mathf.Cos(-angle / Mathf.Rad2Deg + 45.0f * Mathf.PI) * circleRadius, Mathf.Sin(-angle / Mathf.Rad2Deg + 45.0f * Mathf.PI) * circleRadius, 0);

        // 改变进度条的长度
        if (progressBar)
        {
            progressBar.fillAmount = (firstAngle + value * (secondAngle - firstAngle)) / 360;
        }

        if (slider)
        {
            // 设置Slider的value，触发onValueChangeds
            slider.value = slider.maxValue * value;
        }
    }
}