﻿using System;
using UnityEngine;
using UnityEngine.UI;


public class LLoopScrollDataSource : LoopScrollDataSource
{
    public Action<RectTransform, int> OnCellUpdateContent;

    public override void ProvideData(Transform transform, int idx)
    {
        OnCellUpdateContent?.Invoke(transform as RectTransform, idx);
    }
}