﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

public class DragEventTrigger : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public RectTransform limitTransform;           //限制在指定区域内
    private Vector2 minOffset = new Vector2();
    private Vector2 maxOffset = new Vector2();
    private Vector3 pos;                           //控件初始位置
    private Vector2 mousePos;                      //鼠标初始位置（画布空间）
    private RectTransform canvasTf;                //控件所在画布
    private bool dragging;
    [HideInInspector]
    public GraphicRaycaster m_RayCaster;

    [Serializable]
    public class DragEvent : UnityEvent<PointerEventData> { }

    [Serializable]
    public class DropEvent : UnityEvent<List<GameObject>> { }

    public DragEvent onBeginDrag
    {
        get { return m_OnBeginDrag; }
        set { m_OnBeginDrag = value; }
    }
    [FormerlySerializedAs("onBeginDrag")]
    [SerializeField]
    private DragEvent m_OnBeginDrag = new DragEvent();

    public DragEvent onDrag
    {
        get { return m_OnDrag; }
        set { m_OnDrag = value; }
    }
    [FormerlySerializedAs("onDrag")]
    [SerializeField]
    private DragEvent m_OnDrag = new DragEvent();

    public DragEvent onEndDrag
    {
        get { return m_OnEndDrag; }
        set { m_OnEndDrag = value; }
    }
    [FormerlySerializedAs("onEndDrag")]
    [SerializeField]
    private DragEvent m_OnEndDrag = new DragEvent();

    public DropEvent onDrop
    {
        get { return m_OnDrop; }
        set { m_OnDrop = value; }
    }
    [FormerlySerializedAs("onDrop")]
    [SerializeField]
    private DropEvent m_OnDrop = new DropEvent();

    private Vector3[] corners = new Vector3[4];
    // Start is called before the first frame update
    void Start()
    {
        var canvas = this.GetComponentInParent<Canvas>();
        if (canvas == null)
        {
            Debug.LogErrorFormat("DragEventTrigger:{0} can't found Canvas in it's Parent: {1}", transform, transform.parent);
            return;
        }
        canvasTf = canvas.transform as RectTransform;
        m_RayCaster = canvasTf.GetComponent<GraphicRaycaster>();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        dragging = true;
        pos = this.GetComponent<RectTransform>().anchoredPosition;
        Camera camera = eventData.pressEventCamera;
        //将屏幕空间鼠标位置eventData.position转换为鼠标在画布空间的鼠标位置
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasTf, eventData.position, camera, out mousePos);

        m_OnBeginDrag.Invoke(eventData);
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        if (!dragging)
            return;

        Vector2 newVec = new Vector2();
        Camera camera = eventData.pressEventCamera;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasTf, eventData.position, camera, out newVec);
        //鼠标移动在画布空间的位置增量
        Vector3 offset = new Vector3(newVec.x - mousePos.x, newVec.y - mousePos.y, 0);
        //原始位置增加位置增量即为现在位置
        newVec = pos + offset;
        (transform as RectTransform).anchoredPosition = newVec;

        if (limitTransform != null)
        {
            limitTransform.GetWorldCorners(corners);

            Vector3 leftBottom = corners[0];
            Vector3 rightTop = corners[2];

            minOffset.x = leftBottom.x;
            minOffset.y = leftBottom.y;

            maxOffset.x = rightTop.x;
            maxOffset.y = rightTop.y;

            // 限制在区域内
            float x = Mathf.Clamp((transform as RectTransform).position.x, minOffset.x, maxOffset.x);
            float y = Mathf.Clamp((transform as RectTransform).position.y, minOffset.y, maxOffset.y);
            (transform as RectTransform).position = new Vector3(x, y, transform.position.z);
        }
        m_OnDrag.Invoke(eventData);
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        dragging = false;
        // 先调用拖拽结束的事件
        m_OnEndDrag.Invoke(eventData);

        // 射线检测
        List<GameObject> hitGameObjects = Raycast(eventData);
        m_OnDrop.Invoke(hitGameObjects);
    }

    public List<GameObject> Raycast(PointerEventData eventData)
    {
        // 射线检测
        List<RaycastResult> results = new List<RaycastResult>();
        m_RayCaster.Raycast(eventData, results);

        List<GameObject> hitGameObjects = new List<GameObject>();
        foreach (RaycastResult ret in results)
        {
            hitGameObjects.Add(ret.gameObject);
        }
        return hitGameObjects;
    }
}
