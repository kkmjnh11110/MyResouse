﻿using TJ;
using UnityEngine;
using UnityEngine.UI;

public class LLoopScrollPrefabSource : LoopScrollPrefabSource
{
    public GameObject templateObject;
    public Asset asset;
    public string poolName = "";
    public int poolSize = 0;
    private GameObjectPool pool;

    public override GameObject GetObject()
    {
        if (pool == null)
        {
            pool = PoolManager.Instance.GetPool(poolName);
            if (pool == null)
            {
                if (templateObject != null)
                {
                    pool = PoolManager.Instance.CreatePool(poolName, templateObject);
                }else if (asset != null)
                {
                    pool = PoolManager.Instance.CreatePool(poolName, asset);
                }
            }
        }

        return pool.Instantiate();
    }

    public override void ReturnObject(Transform go)
    {
        go.SendMessage("ScrollCellReturn", SendMessageOptions.DontRequireReceiver);
        pool.Recovery(go.gameObject);
    }
}
