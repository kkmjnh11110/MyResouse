﻿using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

public class PressEventTrigger : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    public float interval = 0.1f;

    public UnityEvent onPressStart
    {
        get { return m_OnPressStart; }
        set { m_OnPressStart = value; }
    }

    [FormerlySerializedAs("onPressStart")]
    [SerializeField]
    private UnityEvent m_OnPressStart = new UnityEvent();
    
    public UnityEvent onPress
    {
        get { return m_OnPress; }
        set { m_OnPress = value; }
    }

    [FormerlySerializedAs("onPress")]
    [SerializeField]
    private UnityEvent m_OnPress = new UnityEvent();

    public UnityEvent onPressEnd
    {
        get { return m_OnPressEnd; }
        set { m_OnPressEnd = value; }
    }

    [FormerlySerializedAs("onPressEnd")]
    [SerializeField]
    private UnityEvent m_OnPressEnd = new UnityEvent();

    private bool isPointDown = false;
    private float lastInvokeTime;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (isPointDown && interval > 0)
        {
            if (Time.time - lastInvokeTime > interval)
            {
                m_OnPress.Invoke();
                lastInvokeTime = Time.time;
            }
        }
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        UISystemProfilerApi.AddMarker("PressEventTrigger.onPress", this);
        m_OnPressStart.Invoke();
        m_OnPress.Invoke();
        SetPointerDown(true);
        lastInvokeTime = Time.time;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        SetPointerDown(false);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        SetPointerDown(false);
    }

    private void SetPointerDown(bool isDown)
    {
        if (isPointDown && !isDown)
        {
            m_OnPressEnd.Invoke();
        }
        isPointDown = isDown;
    }
}
