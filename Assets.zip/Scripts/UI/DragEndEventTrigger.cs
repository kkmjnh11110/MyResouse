﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

public class DragEndEventTrigger : MonoBehaviour, IEndDragHandler
{
    [Serializable]
    public class DragEvent : UnityEvent<PointerEventData> { }

    [SerializeField]
    public DragEvent onEndDrag
    {
        get { return m_OnEndDrag; }
        set { m_OnEndDrag = value; }
    }
    [FormerlySerializedAs("onEndDrag")]
    [SerializeField]
    private DragEvent m_OnEndDrag = new DragEvent();
    public void OnEndDrag(PointerEventData eventData)
    {
        m_OnEndDrag.Invoke(eventData);
    }
}
