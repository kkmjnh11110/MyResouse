﻿using DG.Tweening;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

[ExecuteAlways]
public class NumberScroller : MonoBehaviour
{
    [Tooltip("每个数字滚动到下个数字的时间间隔")]
    [SerializeField]
    [Range(0, 1.0f)]
    private float rollingDuration = 0.05f;
    private float rollingHeight = 0;
    [Tooltip("用于调整整个组件中所有数字的横向间距")]
    [SerializeField]
    private float cellSpacingX = 0;
    [Tooltip("组件中所有数字的对齐方式")]
    [SerializeField]
    private TextAlignment alignment = TextAlignment.Left;
    [Tooltip("当前组件显示的数值")]
    [SerializeField]
    private long currentNumber = 0;

    [Header("Add Text")]
    [Tooltip("数字变动文本出现后静止延迟的时间")]
    [SerializeField]
    [Range(0, 5.0f)]
    private float addMoveDelay = 0.2f;
    [Tooltip("数字变动文本移动的时间")]
    [SerializeField]
    [Range(0, 5.0f)]
    private float addMoveDuration = 0.5f;
    [Tooltip("数字变动文本移动的变速方式")]
    [SerializeField]
    private Ease addMoveEase = Ease.InBack;
    [Tooltip("数字变动文本移动的起点")]
    [SerializeField]
    private RectTransform.Edge addMoveStart = RectTransform.Edge.Bottom;
    [Tooltip("数字变动文本移动后发光的时间延迟")]
    [SerializeField]
    private float addGlowDelay = -0.1f;
    [Tooltip("数字变动文本移动后发光的淡出淡入总时间")]
    [SerializeField]
    private float addGlowDuration = 0.4f;

    public UnityEvent onComplete
    {
        get { return m_OnComplete; }
        set { m_OnComplete = value; }
    }
    [SerializeField]
    private UnityEvent m_OnComplete = new UnityEvent();

    public long curNumber
    {
        set
        {
            currentNumber = value;
            SetNumberShown(value);
        }
        get { return currentNumber; }
    }

    private Text template;
    private Image glow;
    private Text[] textList;
    private float spacingY;     // 每个数字的间距
    private string defaultText = "0123456789";
    private bool isPlaying = false;

    enum CommandType
    {
        Set,
        Scroll
    }

    struct Command
    {
        public CommandType type;
        public long number;
    }
    private List<Command> commandList = new List<Command>();
    void Awake()
    {
        textList = GetComponentsInChildren<Text>();

        var firstText = textList[0];
        template = firstText;
        template.text = defaultText;

        var image = transform.Find("Image");
        glow = image?.GetComponent<Image>();
        if (glow)
        {
            glow.color = template.color;
            glow.gameObject.SetActive(false);
        }
    }

    void Start()
    {
        var firstText = textList[0];
        LayoutRebuilder.ForceRebuildLayoutImmediate(firstText.rectTransform);
        float height = firstText.preferredHeight;

        spacingY = height / defaultText.Length;
        rollingHeight = spacingY * defaultText.Length;

        GenerateTextByNumber(curNumber);
        SetNumberShown(curNumber);
    }

#if UNITY_EDITOR
    void OnValidate()
    {
        UnityEditor.EditorApplication.delayCall += () =>
        {
            GenerateTextByNumber(currentNumber);
            curNumber = currentNumber;
        };
    }
#endif

    private void GenerateTextByNumber(long number)
    {
        if (!template)
        {
            return;
        }

        string strNum = number.ToString();
        for (int i = textList.Length; i < strNum.Length * 2; i++)
        {
            var go = Object.Instantiate(template.gameObject, template.rectTransform.parent);
            var lab = go.GetComponent<Text>();
            lab.text = defaultText;
        }

        int removeIndex = strNum.Length * 2;
        for (int i = removeIndex; i < textList.Length; i++)
        {
            var go = textList[i].gameObject;
            Object.DestroyImmediate(go);
        }

        textList = GetComponentsInChildren<Text>();

        DoLayout();
    }

    
    

    private void DoLayout()
    {

        Vector2 pos = new Vector2();
        float offsetX = template.rectTransform.rect.width;
        if (alignment == TextAlignment.Left)
        {
            pos.x = offsetX * 0.5f;

            for (int index = 1; index <= textList.Length; index++)
            {
                var text = textList[index - 1];
                var tf = text.rectTransform;
                tf.anchorMin = Vector2.up;
                tf.anchorMax = Vector2.up;

                var column = Mathf.Floor(index / 2);
                if (index % 2 == 1)
                {
                    if (column > 0)
                    {
                        pos.x += offsetX + cellSpacingX;
                    }
                    tf.anchoredPosition = pos;
                }
                else
                {
                    pos.y = -rollingHeight;
                    tf.anchoredPosition = pos;
                    pos.y = 0;
                }
            }
        }
        else if (alignment == TextAlignment.Right)
        {
            pos.x = -offsetX * 0.5f;
            for (int index = 1; index <= textList.Length; index++)
            {
                var text = textList[textList.Length - index];
                var tf = text.rectTransform;
                tf.anchorMin = Vector2.one;
                tf.anchorMax = Vector2.one;

                var column = Mathf.Floor(index / 2);
                if (index % 2 == 1)
                {
                    if (column > 0)
                    {
                        pos.x -= offsetX + cellSpacingX;
                    }
                    tf.anchoredPosition = pos;
                }
                else
                {
                    pos.y = -rollingHeight;
                    tf.anchoredPosition = pos;
                    pos.y = 0;
                }
            }
        }
        else if (alignment == TextAlignment.Center)
        {
            Vector2 mid = new Vector2(0.5f, 1.0f);

            float num = textList.Length * 0.5f;
            float size = num * offsetX + (num - 1) * cellSpacingX;
            pos.x = size * 0.5f - offsetX * 0.5f;
            for (int index = 1; index <= textList.Length; index++)
            {
                var text = textList[textList.Length - index];
                var tf = text.rectTransform;
                tf.anchorMin = mid;
                tf.anchorMax = mid;

                var column = Mathf.Floor(index / 2);
                if (index % 2 == 1)
                {
                    if (column > 0)
                    {
                        pos.x -= offsetX + cellSpacingX;
                    }
                    tf.anchoredPosition = pos;
                }
                else
                {
                    pos.y = -rollingHeight;
                    tf.anchoredPosition = pos;
                    pos.y = 0;
                }
            }
        }
    }

    private Sequence ScrollTextToNumber(int textIndex, int number)
    {
        if (number < 0 || number > 9)
        {
            return null;
        }

        var tf = textList[textIndex * 2].rectTransform;

        int moveNumber = 10;
        float moveY = GetNumberY(moveNumber);

        int endMoveNum = 0;

        Sequence seq = DOTween.Sequence();
        seq.Append(tf.DOAnchorPosY(moveY, rollingDuration * endMoveNum));
        seq.Append(tf.DOAnchorPosY(0, 0));
        seq.Append(tf.DOAnchorPosY(spacingY * number, rollingDuration * number));

        return seq;
    }

    private System.Collections.IEnumerator CheckPlayScroll()
    {
        if (commandList.Count > 0)
        {
            if (!isPlaying)
            {
                Command command = commandList[0];
                commandList.RemoveAt(0);

                if (command.type == CommandType.Scroll)
                {
                    isPlaying = true;
                    PlayScrollToNumber(command.number, () =>
                    {
                        isPlaying = false;
                        if (isActiveAndEnabled)
                        {
                            StartCoroutine(CheckPlayScroll());
                        }
                    });
                }
                else
                {
                    ResetNumber();
                    SetNumberWithGenerateText(command.number);
                    StartCoroutine(CheckPlayScroll());
                }
            }
        }
        else if (commandList.Count == 0)
        {
            onComplete.Invoke();
        }
        yield return null;
    }

    private void AddCommand(CommandType type, long number)
    {
        Command command;
        command.type = type;
        command.number = number;
        commandList.Add(command);

        StartCoroutine(CheckPlayScroll());
    }

    // 将滚动的目标数字加入到队列中
    public void ScrollToNumber(long number)
    {
        AddCommand(CommandType.Scroll, number);
    }

    // 将要设置的目标数字加入到队列中
    public void SetToNumber(long number)
    {
        AddCommand(CommandType.Set, number);
    }

    // 播放滚动到某个数字
    public void PlayScrollToNumber(long number, TweenCallback onCompleteCallback)
    {
        if (curNumber < number)
        {
            GenerateTextByNumber(number);
        }
        SetNumberShown(curNumber);

        if (!isActiveAndEnabled)
        {
            // 如果组件被禁用，则不播放动画
            curNumber = number;
            return;
        }

        string curStrNum = curNumber.ToString();
        int curStrLenght = curStrNum.Length;

        long numDelta = number - curNumber;
        currentNumber = number;

        if (textList != null && textList.Length != 0)
        {
            Sequence seq = DOTween.Sequence();

            string strNum = number.ToString();
            int textListNum = System.Convert.ToInt32(textList.Length * 0.5);
            int strLength = strNum.Length;

            if (numDelta > 0)
            {
                // 播放数字增加
                var thisTf = transform as RectTransform;
                var go = Object.Instantiate(template.gameObject, thisTf.parent);
                var lab = go.GetComponent<Text>();
                var tf = lab.rectTransform;
                float offsetX = template.rectTransform.rect.width;
                tf.anchorMin = thisTf.anchorMin;
                tf.anchorMax = thisTf.anchorMax;
                tf.pivot = thisTf.pivot;

                var pos = thisTf.anchoredPosition;
                offsetX = thisTf.rect.width - (offsetX * strLength + cellSpacingX * strLength);
                
                var targetPos = new Vector2();
                targetPos.x = pos.x;
                if (addMoveStart == RectTransform.Edge.Right)
                {
                    pos.x += thisTf.rect.width;
                }
                else if (addMoveStart == RectTransform.Edge.Left)
                {
                    pos.x -= thisTf.rect.width;
                }
                else
                {
                    if (alignment == TextAlignment.Left)
                    {
                        pos.x -= offsetX;
                    }
                    else if (alignment == TextAlignment.Center)
                    {
                        pos.x -= offsetX * 0.5f;
                    }
                    targetPos.x = pos.x;
                }

                targetPos.y = pos.y;
                if (addMoveStart == RectTransform.Edge.Bottom)
                {
                    pos.y -= spacingY;
                }
                else if (addMoveStart == RectTransform.Edge.Top)
                {
                    pos.y += spacingY;
                }

                tf.anchoredPosition = pos;

                lab.alignment = TextAnchor.MiddleRight;

                var strAdd = string.Format("+{0}", numDelta);
                tf.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, thisTf.rect.width);
                tf.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, spacingY);

                lab.text = strAdd;

                seq.Append(tf.DOAnchorPos(targetPos, addMoveDuration)
                    .SetDelay(addMoveDelay)
                    .SetEase(addMoveEase)
                    .OnComplete(() =>
                    {
                        DestroyImmediate(lab.gameObject);
                    }
                ));

                if (glow != null)
                {
                    var glowTf = glow.rectTransform;
                    int strAddNum = strAdd.Length - 1;
                    int offsetIndex = strAddNum - Mathf.FloorToInt(strAddNum * 0.5f);
                    int glowPosIndex = strLength - offsetIndex;
                    Text posNum = textList[glowPosIndex * 2];

                    glowTf.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, spacingY * strAddNum + cellSpacingX * (strAddNum-1) );
                    var localPos = glowTf.localPosition;
                    localPos.x = posNum.rectTransform.localPosition.x;
                    if (strAddNum % 2 == 0)
                    {
                        localPos.x = localPos.x - cellSpacingX - spacingY * 0.5f;
                    }
                    glowTf.localPosition = localPos;
                    
                    float glowDelay = addMoveDuration + addMoveDelay + addGlowDelay;
                    float glowDuration = addGlowDuration * 0.5f;
                    seq.Insert(glowDelay, glow.DOFade(1.0f, glowDuration).OnStart(() =>
                    {
                        glow.gameObject.SetActive(true);
                    }));

                    seq.Insert(glowDelay + glowDuration, glow.DOFade(0.0f, glowDuration).OnComplete(() =>
                    {
                        glow.gameObject.SetActive(false);
                    }));
                }

                seq.InsertCallback(addMoveDuration + addMoveDelay, () =>
                {

                });
            }

            int index = 0;

            for (; index < strLength; index++)
            {
                int curIdx = curStrLenght - index - 1;
                int curNum = 0;
                if (curIdx >= 0 && curIdx < curStrLenght)
                {
                    curNum = System.Convert.ToInt32(curStrNum[curStrLenght - index - 1].ToString());
                }
                int num = System.Convert.ToInt32(strNum[strLength - index - 1].ToString());
                if (curNum != num)
                {
                    Sequence subSeq = ScrollTextToNumber((textListNum - index - 1), num);
                    if (subSeq != null)
                    {
                        seq.Join(subSeq);
                    }
                }
            }

            for (; index < textListNum; index++)
            {
                Sequence subSeq = ScrollTextToNumber((textListNum - index - 1), 0);
                if (subSeq != null)
                {
                    seq.Join(subSeq);
                }
            }

            if (onCompleteCallback != null)
            {
                seq.AppendCallback(onCompleteCallback);
            }
        }
    }

    // 获取显示某个数字，Text组件的坐标
    private float GetNumberY(int number)
    {
        return spacingY * number;
    }

    private void SetNumberTransformPosition(RectTransform tf, int number)
    {
        if (tf == null)
        {
            return;
        }
        var pos = tf.anchoredPosition;
        pos.y = GetNumberY(number);
        tf.anchoredPosition = pos;
    }

    // 设置组件上某个位置的数字
    private void SetNumberByIndex(int textIndex, int number)
    {
        var tf = textList[textIndex * 2].rectTransform;
        var rollingTf = textList[textIndex * 2 + 1].rectTransform;

        SetNumberTransformPosition(tf, number);
        SetNumberTransformPosition(rollingTf, number - 10);
    }

    // 设置组件上显示的数字
    private void SetNumberShown(long number)
    {
        if (textList != null && textList.Length != 0)
        {
            string strNum = number.ToString();
            int textListNum = System.Convert.ToInt32(textList.Length * 0.5);
            int strLength = strNum.Length;
            int index = 0;

            for (; index < strLength; index++)
            {
                int num = System.Convert.ToInt32(strNum[strLength - index - 1].ToString());
                SetNumberByIndex((textListNum - index - 1), num);
            }

            for (; index < textListNum; index++)
            {
                SetNumberByIndex((textListNum - index - 1), 0);
            }
        }
    }

    // 设置显示的数字，如果用于显示的文本不够会自动创建
    public void SetNumberWithGenerateText(long number)
    {
        if (curNumber < number)
        {
            GenerateTextByNumber(number);
        }
        curNumber = number;
    }

    public void ResetNumber()
    {
        commandList.Clear();
        foreach (var text in textList)
        {
            if (text != template)
            {
                DestroyImmediate(text.gameObject);
            }
        }
        textList = GetComponentsInChildren<Text>();
        GenerateTextByNumber(0);
        curNumber = 0;
    }
}
