﻿using UnityEngine;

/// <summary>
/// RectTransform 从安全区域调整为全屏
/// </summary>
public class RectTransformSafeAreaToFull : MonoBehaviour
{
    void Awake()
    {
        if (NeedScreenSafeArea())
        {
            var transform = GetComponent<RectTransform>();
            var vec = transform.offsetMin;
            vec.y = -88;
            transform.offsetMin = vec;

            vec = transform.offsetMax;
            vec.y = 88;
            transform.offsetMax = vec;
        }
    }

    bool NeedScreenSafeArea()
    {
        //兼容更多的刘海机器
        double r = 2.073;
        double rr = (double)UnityEngine.Screen.height / (double)UnityEngine.Screen.width;
        return (rr > r);
    }

}

