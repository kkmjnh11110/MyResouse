﻿using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using TJ;
using XLua;
using FancyScrollView;
using EasingCore;

[RequireComponent(typeof(Scroller), typeof(LBehaviour))]
public class LScrollView : FancyScrollView<int, LScrollViewContext>
{
    [SerializeField] Scroller scroller = default;
    [SerializeField] GameObject cellPrefab = default;

    Action<int> onSelectionChanged;

    public float pressedScrollDuration = 0.4f;

    public int selectedIndex
    {
        get
        {
            return Context.SelectedIndex;
        }
    }

    public Transform container
    {
        get
        {
            return cellContainer;
        }
    }

    private LuaTable luaInst = null;
    private LuaFunction cbCellStart = null;
    private LuaFunction cbCellUpdateContent = null;
    private LuaFunction cbCellUpdatePosition = null;

    protected override GameObject CellPrefab => cellPrefab;

    void Awake()
    {
        Context.OnCellStart = OnCellStart;
        Context.OnCellUpdateContent = OnCellUpdateContent;
        Context.OnCellUpdatePosition = OnCellUpdatePosition;
        Context.OnPressedCell = OnPressedCell;

        luaInst = GetComponent<LBehaviour>().luaInst;

        cbCellStart = luaInst.Get<LuaFunction>("OnCellStart");
        cbCellUpdateContent = luaInst.Get<LuaFunction>("OnCellUpdateContent");
        cbCellUpdatePosition = luaInst.Get<LuaFunction>("OnCellUpdatePosition");
    }

    void Start()
    {
        scroller.OnValueChanged(UpdatePosition);
        scroller.OnSelectionChanged(UpdateSelection);
    }

    void OnDestroy()
    {
        cbCellStart = null;
        cbCellUpdateContent = null;
        cbCellUpdatePosition = null;
        onSelectionChanged = null;
    }

    public void SetDataCount(int dataCount)
    {
        var data = Enumerable.Range(0, dataCount)
            .Select(i => i+1)
            .ToList();

        UpdateData(data);
    }

    public void UpdateSelection(int index)
    {
        if (Context.SelectedIndex == index)
        {
            return;
        }

        Context.SelectedIndex = index;
        Refresh();
        // 此处索引从0开始，但是Lua的索引是从1开始的，因此调用Lua函数时索引转换成从1开始
        onSelectionChanged?.Invoke(index+1);
    }

    public void UpdateData(IList<int> items)
    {
        UpdateContents(items);
        scroller.SetTotalCount(items.Count);
    }

    public void OnSelectionChanged(Action<int> callback)
    {
        onSelectionChanged = callback;
    }

    public void SelectCell(int index, bool force = false, float duration = 0.35f, Ease easing = Ease.OutCubic)
    {
        if (index < 0 || index >= ItemsSource.Count || (!force && index == Context.SelectedIndex))
        {
            return;
        }

        if (force && index == Context.SelectedIndex)
        {
            // 强制刷新
            Refresh();
            // 此处索引从0开始，但是Lua的索引是从1开始的，因此调用Lua函数时索引转换成从1开始
            onSelectionChanged?.Invoke(index+1);
            return;
        }
        else
        {
            UpdateSelection(index);
        }
        scroller.ScrollTo(index, duration, easing);
    }

    public float GetScrollOffset()
    {
        return scrollOffset;
    }

    void OnCellStart(LScrollViewCell cell)
    {
        cbCellStart?.Call(luaInst, cell);
    }

    void OnCellUpdateContent(LScrollViewCell cell, int index)
    {
        cbCellUpdateContent?.Call(luaInst, cell, index);
    }

    void OnCellUpdatePosition(LScrollViewCell cell, float position)
    {
        cbCellUpdatePosition?.Call(luaInst, cell, position);
    }

    void OnPressedCell(LScrollViewCell cell)
    {
        scroller.ScrollTo(cell.Index, pressedScrollDuration);
        SelectCell(cell.Index);
    }
}
