﻿using System;
using TJ;
using UnityEngine;
using UnityEngine.UI;
using XLua;

// 用于桥接LoopScrollRect组件和Lua部分，挂在拥有LoopScrollRect组件的节点之下
[RequireComponent(typeof(LBehaviour))]
public class LLoopScrollRect : MonoBehaviour
{
    private LuaTable luaInst = null;
    private LuaFunction cbCellUpdateContent = null;

    [NonSerialized]
    [HideInInspector]
    public LoopScrollRect scrollRect = null;

    private LLoopScrollDataSource dataSource = new LLoopScrollDataSource();
    private LLoopScrollPrefabSource prefabSource = new LLoopScrollPrefabSource();
    private int dataCount = 0;

    void Awake()
    {
        luaInst = GetComponent<LBehaviour>().luaInst;

        cbCellUpdateContent = luaInst.Get<LuaFunction>("OnCellUpdateContent");

        scrollRect = GetComponent<LoopScrollRect>();

        dataSource.OnCellUpdateContent = OnCellUpdateContent;
        scrollRect.dataSource = dataSource;
        scrollRect.prefabSource = prefabSource;
        scrollRect.totalCount = dataCount;
    }

    void OnDestroy()
    {
        cbCellUpdateContent = null;
    }

    public void SetTemplate(string poolName, GameObject templateObject, int poolSize = 5)
    {
        prefabSource.poolName = poolName;
        prefabSource.templateObject = templateObject;
        prefabSource.asset = null;
        prefabSource.poolSize = poolSize;
    }

    public void SetTemplate(string poolName, Asset asset, int poolSize = 5)
    {
        prefabSource.poolName = poolName;
        prefabSource.templateObject = null;
        prefabSource.asset = asset;
        prefabSource.poolSize = poolSize;
    }

    public void SetDataCount(int count)
    {
        dataCount = count;
        if (scrollRect != null)
        {
            scrollRect.totalCount = count;
        }
    }

    void OnCellUpdateContent(RectTransform cell, int index)
    {
        // 此处索引从0开始，但是Lua的索引是从1开始的，因此调用Lua函数时索引转换成从1开始
        cbCellUpdateContent?.Call(luaInst, cell, index+1);
    }
}
