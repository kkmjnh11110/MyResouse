﻿using UnityEngine;
using System.Collections;

namespace UnityEngine.UI
{
    [System.Serializable]
    public abstract class LoopScrollPrefabSource 
    {
        public abstract GameObject GetObject();
        public abstract void ReturnObject(Transform go);
    }
}
