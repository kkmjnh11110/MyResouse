﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.ImageEffects;
[ExecuteInEditMode]
public class StencilBloom : PostEffectsBase {

    //public Shader BloomEffect;
    [Tooltip("Bloom效果Material")]
    public Shader BloomShader;
    [Tooltip("迭代次数")]
    [Range(0, 4)]
    public int Iterations = 3;
    [Tooltip("模糊范围")]
    [Range(0.2f, 3.0f)]
    public float BlurSpread = 0.6f;
    [Tooltip("降采样倍数")]
    [Range(1, 8)]
    public int DownSample = 2;
    [Tooltip("产生Bloom效果的最小阈值")]
    [Range(0.0f, 4.0f)]
    public float LuminanceThreshold = 0.1f;

    private RenderTexture CameraRenderTexture;
    private RenderTexture Buffer;
    private Material PostprocessMaterial;
    private Vector2 ScreenResolution;
    private bool AllowMSAA;
    protected override void Start()
    {
        base.Start();
        PostprocessMaterial=CheckShaderAndCreateMaterial(BloomShader, PostprocessMaterial);
        AllowMSAA = !GetComponent<Camera>().allowMSAA;
        if (PostprocessMaterial)
        {
            UpdateRenderSize();
        }
    }

    private void Update()
    {
        CheckResolutionChang();
        if (GetComponent<Camera>().allowMSAA)
        {
            transform.GetComponent<Camera>().targetTexture = CameraRenderTexture;
        }

    }
    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (Buffer&& PostprocessMaterial)
        {
            Graphics.Blit(source, destination, PostprocessMaterial, 3);
            //Graphics.Blit(Buffer, destination);
            Buffer.Release();
        }
        else
        {
            Graphics.Blit(source,destination);
        }
        if (GetComponent<Camera>().allowMSAA)
        {
            transform.GetComponent<Camera>().targetTexture = null;
        }
        else
        {
            if (transform.GetComponent<Camera>().targetTexture)
            {
                transform.GetComponent<Camera>().targetTexture = null;
            }
        }
            
    }

    void OnPostRender()
    {

        if (CameraRenderTexture&& Buffer&& PostprocessMaterial)
        {
            int rtW = Screen.width / DownSample;
            int rtH = Screen.height / DownSample;
            RenderTexture buffer0 = RenderTexture.GetTemporary(rtW, rtH, 0);
            buffer0.filterMode = FilterMode.Point;

            Graphics.SetRenderTarget(Buffer);
            //GL.Clear(true, true, Color.black);//清空Buffer
            if (GetComponent<Camera>().allowMSAA)
            {
                Graphics.SetRenderTarget(Buffer.colorBuffer, CameraRenderTexture.depthBuffer);//两个Texture尺寸必须一样
            }
            else
            {
                Graphics.SetRenderTarget(Buffer.colorBuffer, Camera.main.activeTexture.depthBuffer);//两个Texture尺寸必须一样
            }
            
            PostprocessMaterial.SetFloat("_LuminanceThreshold", LuminanceThreshold);
            Graphics.Blit(Camera.main.activeTexture, PostprocessMaterial, 0);//提取目标Stencil物体图像
            Graphics.Blit(Buffer, buffer0);//应用降采样

            for (int i = 0; i < Iterations; i++)
            {
                PostprocessMaterial.SetFloat("_BlurSize", 1.0f + i * BlurSpread);
                RenderTexture buffer1 = RenderTexture.GetTemporary(rtW, rtH, 0);

                // Render the vertical pass
                Graphics.Blit(buffer0, buffer1, PostprocessMaterial, 1);
                RenderTexture.ReleaseTemporary(buffer0);
                buffer0 = buffer1;
                buffer1 = RenderTexture.GetTemporary(rtW, rtH, 0);

                // Render the horizontal pass
                Graphics.Blit(buffer0, buffer1, PostprocessMaterial, 2);
                RenderTexture.ReleaseTemporary(buffer0);
                buffer0 = buffer1;
            }
            RenderTexture.active = null;
            Graphics.Blit(buffer0, Buffer);
            RenderTexture.ReleaseTemporary(buffer0);

            //RenderTexture.active = null;
            //Graphics.Blit(Buffer, SimpleRender);
        }
    }

    private void OnDisable()
    {
        if (Buffer)
        {
            Buffer.Release();
        }
        if (CameraRenderTexture)
        {
            CameraRenderTexture.Release();
        }
        transform.GetComponent<Camera>().targetTexture = null;
    }

    private void CheckResolutionChang()
    {
        if (ScreenResolution.x!= Screen.width|| ScreenResolution.y != Screen.height|| AllowMSAA!=GetComponent<Camera>().allowMSAA)
        {
            UpdateRenderSize();
            ScreenResolution.x = Screen.width;
            ScreenResolution.y = Screen.height;
            AllowMSAA = GetComponent<Camera>().allowMSAA;
        }
    }

    private void UpdateRenderSize()
    {
        if (CameraRenderTexture)
        {
            CameraRenderTexture.Release();
        }
        if (Buffer)
        {
            Buffer.Release();
        }
        if (GetComponent<Camera>().allowMSAA)
        {
            CameraRenderTexture = new RenderTexture(Screen.width, Screen.height, 24);
            CameraRenderTexture.filterMode = FilterMode.Point;
        }
        Buffer = new RenderTexture(Screen.width, Screen.height, 0);
        Buffer.filterMode = FilterMode.Point;
        if (PostprocessMaterial)
        {
            PostprocessMaterial.SetTexture("_Bloom", Buffer);
        }

    }
}
