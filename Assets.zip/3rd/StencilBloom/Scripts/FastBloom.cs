﻿using System;
using UnityEngine;


namespace UnityStandardAssets.ImageEffects
{
    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    [AddComponentMenu("Image Effects/Bloom and Glow/FastBloom (Optimized)")]
    public class FastBloom : PostEffectsBase
    {

        public enum Resolution
        {
            Low = 0,
            High = 1,
        }

        public enum BlurType
        {
            Standard = 0,
            Sgx = 1,
        }

        [Range(0.0f, 1.5f)]
        public float threshold = 0.25f;
        [Range(0.0f, 2.5f)]
        public float intensity = 0.75f;

        [Range(0.25f, 5.5f)]
        public float blurSize = 1.0f;

        Resolution resolution = Resolution.Low;
        [Range(1, 4)]
        public int blurIterations = 1;

        public BlurType blurType = BlurType.Standard;
        public Shader fastBloomShader = null;

        private Camera StencilCamera;//没用
        private RenderTexture CameraRenderTexture;
        private RenderTexture Buffer;
        private Material fastBloomMaterial = null;
        private Vector2 ScreenResolution;
        private bool AllowMSAA;


        public override bool CheckResources()
        {
            CheckSupport(false);

            fastBloomMaterial = CheckShaderAndCreateMaterial(fastBloomShader, fastBloomMaterial);

            if (!isSupported)
                ReportAutoDisable();
            return isSupported;
        }

        protected override void Start()
        {
            base.Start();
            fastBloomMaterial = CheckShaderAndCreateMaterial(fastBloomShader, fastBloomMaterial);
            AllowMSAA = !GetComponent<Camera>().allowMSAA;
            if (fastBloomMaterial)
            {
                UpdateRenderSize();
            }
        }
        private void Update()
        {
            CheckResolutionChang();
            if (GetComponent<Camera>().allowMSAA)
            {
                transform.GetComponent<Camera>().targetTexture = CameraRenderTexture;
            }
        }
        private void Awake()
        {
        }

        void OnDisable()
        {
            if (fastBloomMaterial)
                DestroyImmediate(fastBloomMaterial);
        }

        void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            if (CheckResources() == false)
            {
                Graphics.Blit(source, destination);
                return;
            }

            int divider = resolution == Resolution.Low ? 4 : 2;
            float widthMod = resolution == Resolution.Low ? 0.5f : 1.0f;

            fastBloomMaterial.SetVector("_Parameter", new Vector4(blurSize * widthMod, 0.0f, threshold, intensity));
            source.filterMode = FilterMode.Bilinear;

            var rtW = source.width / divider;
            var rtH = source.height / divider;


            // downsample
            RenderTexture rt = RenderTexture.GetTemporary(rtW, rtH, 0, source.format);
            rt.filterMode = FilterMode.Bilinear;

            Graphics.Blit(Buffer, rt);

            var passOffs = blurType == BlurType.Standard ? 0 : 2;
            for (int i = 0; i < blurIterations; i++)
            {
                fastBloomMaterial.SetVector("_Parameter", new Vector4(blurSize * widthMod + (i * 1.0f), 0.0f, threshold, intensity));

                // vertical blur
                RenderTexture rt2 = RenderTexture.GetTemporary(rtW, rtH, 0, source.format);
                rt2.filterMode = FilterMode.Bilinear;
                Graphics.Blit(rt, rt2, fastBloomMaterial, 2 + passOffs);
                RenderTexture.ReleaseTemporary(rt);
                rt = rt2;

                // horizontal blur
                rt2 = RenderTexture.GetTemporary(rtW, rtH, 0, source.format);
                rt2.filterMode = FilterMode.Bilinear;
                Graphics.Blit(rt, rt2, fastBloomMaterial, 3 + passOffs);
                RenderTexture.ReleaseTemporary(rt);
                rt = rt2;
            }
            fastBloomMaterial.SetTexture("_Bloom", rt);
            //Graphics.Blit(Buffer,destination);
            //Graphics.Blit(rt, destination);
            //Graphics.Blit(source,destination);
            Graphics.Blit(source, destination, fastBloomMaterial, 0);

            RenderTexture.ReleaseTemporary(rt);
            Buffer.Release();
            if (GetComponent<Camera>().allowMSAA)
            {
                GetComponent<Camera>().targetTexture = null;
            }
        }

        private void OnPostRender()
        {

            if (CheckResources() == false)
            {
                return;
            }

            Graphics.SetRenderTarget(Buffer);
            GL.Clear(true, true, Color.black);//清空Buffer
            if (GetComponent<Camera>().allowMSAA)
            {
                Graphics.SetRenderTarget(Buffer.colorBuffer, CameraRenderTexture.depthBuffer);//两个Texture尺寸必须一样 
            }
            else
            {
                //在改变后的下一帧，尺寸可能没有统一
                Graphics.SetRenderTarget(Buffer.colorBuffer, Camera.main.activeTexture.depthBuffer);//两个Texture尺寸必须一样 
            }
            Graphics.Blit(Camera.main.activeTexture, fastBloomMaterial, 1);//提取目标Stencil物体图像到Buffer
            RenderTexture.active = null;
        }

        private void CheckResolutionChang()
        {
            if (ScreenResolution.x != Screen.width || ScreenResolution.y != Screen.height|| AllowMSAA!=GetComponent<Camera>().allowMSAA)
            {
                UpdateRenderSize();
                AllowMSAA = GetComponent<Camera>().allowMSAA;
                ScreenResolution.x = Screen.width;
                ScreenResolution.y = Screen.height;
            }
        }

        private void UpdateRenderSize()
        {
            if (CameraRenderTexture)
            {
                CameraRenderTexture.Release();
            }
            if (Buffer)
            {
                Buffer.Release();
            }
            if (GetComponent<Camera>().allowMSAA)
            {
                CameraRenderTexture = new RenderTexture(Screen.width, Screen.height, 24);
                CameraRenderTexture.filterMode = FilterMode.Point;
            }
            Buffer = new RenderTexture(Screen.width, Screen.height, 0);
            Buffer.filterMode = FilterMode.Point;
        }
    }
}
