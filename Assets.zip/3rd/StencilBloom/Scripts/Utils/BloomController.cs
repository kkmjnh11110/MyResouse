﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloomController : MonoBehaviour {

    public MonoBehaviour m_StencilBloom;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Close()
    {
        m_StencilBloom.enabled = false;
    }

    public void Open()
    {
        m_StencilBloom.enabled = true;
    }
}
