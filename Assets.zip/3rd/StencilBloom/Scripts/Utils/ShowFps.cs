﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowFps : MonoBehaviour
{
    private float m_fps;
    private float m_fpsUpdateInterval = 0.5f;
    private float m_accumTime = 0.0f;
    private float m_timeLeft = 0.0f;
    private int m_frameCount = 0;

    // Update is called once per frame
    void Update()
    {
        float dt = Time.deltaTime / Time.timeScale;
        m_accumTime += dt;
        m_timeLeft -= dt;
        ++m_frameCount;
        if (m_timeLeft <= 0.0f)
        {
            m_fps = m_frameCount / m_accumTime;
            m_accumTime = 0.0f;
            //m_meshSearchTime = m_meshSearchAccumTime / m_frameCount;
            //m_meshSearchAccumTime = 0.0f;
            m_timeLeft = m_fpsUpdateInterval;
            m_frameCount = 0;
        }

    }

    void OnGUI()
    {
        GUILayoutOption height = GUILayout.Height(50);
        GUILayout.BeginArea(new Rect(0, 0, 200, 150));
        GUIStyle style = new GUIStyle();
        style.fontSize = 30;
        GUILayout.Label("FPS: " + m_fps.ToString("f2"),style);
        GUILayout.EndArea();

    }
}
