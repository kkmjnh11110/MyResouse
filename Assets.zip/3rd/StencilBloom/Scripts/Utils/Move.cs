﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour {


    public float m_OffSet = 3;
    float step = 3;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.z > m_OffSet)
        {
            step *= -1;
        }
        if (transform.position.z < -m_OffSet)
        {
            step *= -1;
        }
        transform.Translate(transform.forward * step * Time.deltaTime);
    }
}
