﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class EZCameraShakeCameraShakerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(EZCameraShake.CameraShaker);
			Utils.BeginObjectRegister(type, L, translator, 0, 3, 5, 4);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Shake", _m_Shake);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ShakeOnce", _m_ShakeOnce);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StartShake", _m_StartShake);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "ShakeInstances", _g_get_ShakeInstances);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "DefaultPosInfluence", _g_get_DefaultPosInfluence);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "DefaultRotInfluence", _g_get_DefaultRotInfluence);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "RestPositionOffset", _g_get_RestPositionOffset);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "RestRotationOffset", _g_get_RestRotationOffset);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "DefaultPosInfluence", _s_set_DefaultPosInfluence);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "DefaultRotInfluence", _s_set_DefaultRotInfluence);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "RestPositionOffset", _s_set_RestPositionOffset);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "RestRotationOffset", _s_set_RestRotationOffset);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 2, 1, 1);
			Utils.RegisterFunc(L, Utils.CLS_IDX, "GetInstance", _m_GetInstance_xlua_st_);
            
			
            
			Utils.RegisterFunc(L, Utils.CLS_GETTER_IDX, "Instance", _g_get_Instance);
            
			Utils.RegisterFunc(L, Utils.CLS_SETTER_IDX, "Instance", _s_set_Instance);
            
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					EZCameraShake.CameraShaker gen_ret = new EZCameraShake.CameraShaker();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to EZCameraShake.CameraShaker constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetInstance_xlua_st_(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
            
                
                {
                    string _name = LuaAPI.lua_tostring(L, 1);
                    
                        EZCameraShake.CameraShaker gen_ret = EZCameraShake.CameraShaker.GetInstance( _name );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Shake(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    EZCameraShake.CameraShakeInstance _shake = (EZCameraShake.CameraShakeInstance)translator.GetObject(L, 2, typeof(EZCameraShake.CameraShakeInstance));
                    
                        EZCameraShake.CameraShakeInstance gen_ret = gen_to_be_invoked.Shake( _shake );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ShakeOnce(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)) 
                {
                    float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
                    float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
                    float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 4);
                    float _fadeOutTime = (float)LuaAPI.lua_tonumber(L, 5);
                    
                        EZCameraShake.CameraShakeInstance gen_ret = gen_to_be_invoked.ShakeOnce( _magnitude, _roughness, _fadeInTime, _fadeOutTime );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 7&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& translator.Assignable<UnityEngine.Vector3>(L, 6)&& translator.Assignable<UnityEngine.Vector3>(L, 7)) 
                {
                    float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
                    float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
                    float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 4);
                    float _fadeOutTime = (float)LuaAPI.lua_tonumber(L, 5);
                    UnityEngine.Vector3 _posInfluence;translator.Get(L, 6, out _posInfluence);
                    UnityEngine.Vector3 _rotInfluence;translator.Get(L, 7, out _rotInfluence);
                    
                        EZCameraShake.CameraShakeInstance gen_ret = gen_to_be_invoked.ShakeOnce( _magnitude, _roughness, _fadeInTime, _fadeOutTime, _posInfluence, _rotInfluence );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to EZCameraShake.CameraShaker.ShakeOnce!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartShake(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 4&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)) 
                {
                    float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
                    float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
                    float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 4);
                    
                        EZCameraShake.CameraShakeInstance gen_ret = gen_to_be_invoked.StartShake( _magnitude, _roughness, _fadeInTime );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 6&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& translator.Assignable<UnityEngine.Vector3>(L, 5)&& translator.Assignable<UnityEngine.Vector3>(L, 6)) 
                {
                    float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
                    float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
                    float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 4);
                    UnityEngine.Vector3 _posInfluence;translator.Get(L, 5, out _posInfluence);
                    UnityEngine.Vector3 _rotInfluence;translator.Get(L, 6, out _rotInfluence);
                    
                        EZCameraShake.CameraShakeInstance gen_ret = gen_to_be_invoked.StartShake( _magnitude, _roughness, _fadeInTime, _posInfluence, _rotInfluence );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to EZCameraShake.CameraShaker.StartShake!");
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ShakeInstances(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.ShakeInstances);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    translator.Push(L, EZCameraShake.CameraShaker.Instance);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DefaultPosInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.DefaultPosInfluence);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DefaultRotInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.DefaultRotInfluence);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_RestPositionOffset(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.RestPositionOffset);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_RestRotationOffset(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.RestRotationOffset);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Instance(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			    EZCameraShake.CameraShaker.Instance = (EZCameraShake.CameraShaker)translator.GetObject(L, 1, typeof(EZCameraShake.CameraShaker));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DefaultPosInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.DefaultPosInfluence = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DefaultRotInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.DefaultRotInfluence = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_RestPositionOffset(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.RestPositionOffset = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_RestRotationOffset(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShaker gen_to_be_invoked = (EZCameraShake.CameraShaker)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.RestRotationOffset = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
