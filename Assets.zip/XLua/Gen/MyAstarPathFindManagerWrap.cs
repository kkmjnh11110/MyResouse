﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MyAstarPathFindManagerWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(MyAstar.PathFindManager);
			Utils.BeginObjectRegister(type, L, translator, 0, 17, 6, 4);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "FindOnePathNow", _m_FindOnePathNow);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "FindOnePath", _m_FindOnePath);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "FindPathTrace", _m_FindPathTrace);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Dispose", _m_Dispose);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "onFindedPath", _m_onFindedPath);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "getGrid", _m_getGrid);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "LoadFromAPFPdump", _m_LoadFromAPFPdump);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GridToLocal", _m_GridToLocal);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "LocalToGrid", _m_LocalToGrid);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetGridNodeSize", _m_GetGridNodeSize);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RegisterModifier", _m_RegisterModifier);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "DeregisterModifier", _m_DeregisterModifier);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "RunModifiers", _m_RunModifiers);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Linecast", _m_Linecast);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetMapConfigString", _m_GetMapConfigString);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SetGridWalkable", _m_SetGridWalkable);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "isGridWalkable", _m_isGridWalkable);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "startNodePosition", _g_get_startNodePosition);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "endNodePosition", _g_get_endNodePosition);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "Find", _g_get_Find);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "use_modifier", _g_get_use_modifier);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "neighbourXOffsets", _g_get_neighbourXOffsets);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "neighbourYOffsets", _g_get_neighbourYOffsets);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "startNodePosition", _s_set_startNodePosition);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "endNodePosition", _s_set_endNodePosition);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "Find", _s_set_Find);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "use_modifier", _s_set_use_modifier);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					MyAstar.PathFindManager gen_ret = new MyAstar.PathFindManager();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FindOnePathNow(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 4);
                    bool _use_path_modifier = LuaAPI.lua_toboolean(L, 5);
                    
                        System.Collections.Generic.List<UnityEngine.Vector3> gen_ret = gen_to_be_invoked.FindOnePathNow( _start, _target, _local_coordinate, _use_path_modifier );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 4&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 4)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 4);
                    
                        System.Collections.Generic.List<UnityEngine.Vector3> gen_ret = gen_to_be_invoked.FindOnePathNow( _start, _target, _local_coordinate );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    
                        System.Collections.Generic.List<UnityEngine.Vector3> gen_ret = gen_to_be_invoked.FindOnePathNow( _start, _target );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager.FindOnePathNow!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FindOnePath(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 6&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 5);
                    bool _use_path_modifier = LuaAPI.lua_toboolean(L, 6);
                    
                    gen_to_be_invoked.FindOnePath( _start, _target, _completeCallback, _local_coordinate, _use_path_modifier );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 5&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 5);
                    
                    gen_to_be_invoked.FindOnePath( _start, _target, _completeCallback, _local_coordinate );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    
                    gen_to_be_invoked.FindOnePath( _start, _target, _completeCallback );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager.FindOnePath!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FindPathTrace(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 8&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 7)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 8)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    int _user_param = LuaAPI.xlua_tointeger(L, 5);
                    int _check_range = LuaAPI.xlua_tointeger(L, 6);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 7);
                    bool _use_path_modifier = LuaAPI.lua_toboolean(L, 8);
                    
                    gen_to_be_invoked.FindPathTrace( _start, _target, _completeCallback, _user_param, _check_range, _local_coordinate, _use_path_modifier );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 7&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 7)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    int _user_param = LuaAPI.xlua_tointeger(L, 5);
                    int _check_range = LuaAPI.xlua_tointeger(L, 6);
                    bool _local_coordinate = LuaAPI.lua_toboolean(L, 7);
                    
                    gen_to_be_invoked.FindPathTrace( _start, _target, _completeCallback, _user_param, _check_range, _local_coordinate );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 6&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)&& translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 6)) 
                {
                    UnityEngine.Vector3 _start;translator.Get(L, 2, out _start);
                    UnityEngine.Vector3 _target;translator.Get(L, 3, out _target);
                    MyAstar.PathFindManager.PathfindingJobComplete _completeCallback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
                    int _user_param = LuaAPI.xlua_tointeger(L, 5);
                    int _check_range = LuaAPI.xlua_tointeger(L, 6);
                    
                    gen_to_be_invoked.FindPathTrace( _start, _target, _completeCallback, _user_param, _check_range );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager.FindPathTrace!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Dispose(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.Dispose(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_onFindedPath(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.Collections.Generic.List<UnityEngine.Vector3> _path = (System.Collections.Generic.List<UnityEngine.Vector3>)translator.GetObject(L, 2, typeof(System.Collections.Generic.List<UnityEngine.Vector3>));
                    
                    gen_to_be_invoked.onFindedPath( _path );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getGrid(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        MyAstar.GridBase gen_ret = gen_to_be_invoked.getGrid(  );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_LoadFromAPFPdump(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 3)) 
                {
                    string _asset_name = LuaAPI.lua_tostring(L, 2);
                    bool _async = LuaAPI.lua_toboolean(L, 3);
                    
                        bool gen_ret = gen_to_be_invoked.LoadFromAPFPdump( _asset_name, _async );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 2&& (LuaAPI.lua_isnil(L, 2) || LuaAPI.lua_type(L, 2) == LuaTypes.LUA_TSTRING)) 
                {
                    string _asset_name = LuaAPI.lua_tostring(L, 2);
                    
                        bool gen_ret = gen_to_be_invoked.LoadFromAPFPdump( _asset_name );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager.LoadFromAPFPdump!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GridToLocal(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    UnityEngine.Vector3 _grid_coord;translator.Get(L, 2, out _grid_coord);
                    
                        UnityEngine.Vector3 gen_ret = gen_to_be_invoked.GridToLocal( _grid_coord );
                        translator.PushUnityEngineVector3(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_LocalToGrid(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    UnityEngine.Vector3 _local_coord;translator.Get(L, 2, out _local_coord);
                    
                        UnityEngine.Vector3 gen_ret = gen_to_be_invoked.LocalToGrid( _local_coord );
                        translator.PushUnityEngineVector3(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetGridNodeSize(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        float gen_ret = gen_to_be_invoked.GetGridNodeSize(  );
                        LuaAPI.lua_pushnumber(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RegisterModifier(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    MyAstar.IPathModifier _modifier = (MyAstar.IPathModifier)translator.GetObject(L, 2, typeof(MyAstar.IPathModifier));
                    
                    gen_to_be_invoked.RegisterModifier( _modifier );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_DeregisterModifier(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    MyAstar.IPathModifier _modifier = (MyAstar.IPathModifier)translator.GetObject(L, 2, typeof(MyAstar.IPathModifier));
                    
                    gen_to_be_invoked.DeregisterModifier( _modifier );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_RunModifiers(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    MyAstar.ModifierPass _pass;translator.Get(L, 2, out _pass);
                    MyAstar.Path _path = (MyAstar.Path)translator.GetObject(L, 3, typeof(MyAstar.Path));
                    
                    gen_to_be_invoked.RunModifiers( _pass, _path );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Linecast(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& translator.Assignable<MyAstar.Node>(L, 2)&& translator.Assignable<MyAstar.Node>(L, 3)) 
                {
                    MyAstar.Node _fromNode = (MyAstar.Node)translator.GetObject(L, 2, typeof(MyAstar.Node));
                    MyAstar.Node _toNode = (MyAstar.Node)translator.GetObject(L, 3, typeof(MyAstar.Node));
                    
                        bool gen_ret = gen_to_be_invoked.Linecast( _fromNode, _toNode );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& translator.Assignable<UnityEngine.Vector3>(L, 2)&& translator.Assignable<UnityEngine.Vector3>(L, 3)) 
                {
                    UnityEngine.Vector3 _from;translator.Get(L, 2, out _from);
                    UnityEngine.Vector3 _to;translator.Get(L, 3, out _to);
                    
                        bool gen_ret = gen_to_be_invoked.Linecast( _from, _to );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.PathFindManager.Linecast!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetMapConfigString(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        string gen_ret = gen_to_be_invoked.GetMapConfigString(  );
                        LuaAPI.lua_pushstring(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetGridWalkable(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int _x = LuaAPI.xlua_tointeger(L, 2);
                    int _y = LuaAPI.xlua_tointeger(L, 3);
                    bool _isWalkable = LuaAPI.lua_toboolean(L, 4);
                    int _user_param1 = LuaAPI.xlua_tointeger(L, 5);
                    int _user_param2 = LuaAPI.xlua_tointeger(L, 6);
                    
                    gen_to_be_invoked.SetGridWalkable( _x, _y, _isWalkable, _user_param1, _user_param2 );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_isGridWalkable(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int _x = LuaAPI.xlua_tointeger(L, 2);
                    int _y = LuaAPI.xlua_tointeger(L, 3);
                    
                        bool gen_ret = gen_to_be_invoked.isGridWalkable( _x, _y );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_startNodePosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector2(L, gen_to_be_invoked.startNodePosition);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_endNodePosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector2(L, gen_to_be_invoked.endNodePosition);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Find(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.Find);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_use_modifier(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.use_modifier);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_neighbourXOffsets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.neighbourXOffsets);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_neighbourYOffsets(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.neighbourYOffsets);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_startNodePosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector2 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.startNodePosition = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_endNodePosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector2 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.endNodePosition = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Find(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.Find = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_use_modifier(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.PathFindManager gen_to_be_invoked = (MyAstar.PathFindManager)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.use_modifier = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
