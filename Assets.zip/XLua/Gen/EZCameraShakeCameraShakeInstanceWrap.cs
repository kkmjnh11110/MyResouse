﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class EZCameraShakeCameraShakeInstanceWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(EZCameraShake.CameraShakeInstance);
			Utils.BeginObjectRegister(type, L, translator, 0, 3, 9, 7);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "UpdateShake", _m_UpdateShake);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StartFadeOut", _m_StartFadeOut);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "StartFadeIn", _m_StartFadeIn);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "ScaleRoughness", _g_get_ScaleRoughness);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "ScaleMagnitude", _g_get_ScaleMagnitude);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "NormalizedFadeTime", _g_get_NormalizedFadeTime);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "CurrentState", _g_get_CurrentState);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "Magnitude", _g_get_Magnitude);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "Roughness", _g_get_Roughness);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "PositionInfluence", _g_get_PositionInfluence);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "RotationInfluence", _g_get_RotationInfluence);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "DeleteOnInactive", _g_get_DeleteOnInactive);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "ScaleRoughness", _s_set_ScaleRoughness);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "ScaleMagnitude", _s_set_ScaleMagnitude);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "Magnitude", _s_set_Magnitude);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "Roughness", _s_set_Roughness);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "PositionInfluence", _s_set_PositionInfluence);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "RotationInfluence", _s_set_RotationInfluence);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "DeleteOnInactive", _s_set_DeleteOnInactive);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 5 && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2) && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3) && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4) && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5))
				{
					float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
					float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
					float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 4);
					float _fadeOutTime = (float)LuaAPI.lua_tonumber(L, 5);
					
					EZCameraShake.CameraShakeInstance gen_ret = new EZCameraShake.CameraShakeInstance(_magnitude, _roughness, _fadeInTime, _fadeOutTime);
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				if(LuaAPI.lua_gettop(L) == 3 && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2) && LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3))
				{
					float _magnitude = (float)LuaAPI.lua_tonumber(L, 2);
					float _roughness = (float)LuaAPI.lua_tonumber(L, 3);
					
					EZCameraShake.CameraShakeInstance gen_ret = new EZCameraShake.CameraShakeInstance(_magnitude, _roughness);
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to EZCameraShake.CameraShakeInstance constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_UpdateShake(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                        UnityEngine.Vector3 gen_ret = gen_to_be_invoked.UpdateShake(  );
                        translator.PushUnityEngineVector3(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartFadeOut(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    float _fadeOutTime = (float)LuaAPI.lua_tonumber(L, 2);
                    
                    gen_to_be_invoked.StartFadeOut( _fadeOutTime );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_StartFadeIn(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    float _fadeInTime = (float)LuaAPI.lua_tonumber(L, 2);
                    
                    gen_to_be_invoked.StartFadeIn( _fadeInTime );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ScaleRoughness(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.ScaleRoughness);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_ScaleMagnitude(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.ScaleMagnitude);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_NormalizedFadeTime(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.NormalizedFadeTime);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_CurrentState(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.CurrentState);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Magnitude(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.Magnitude);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_Roughness(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.Roughness);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_PositionInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.PositionInfluence);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_RotationInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                translator.PushUnityEngineVector3(L, gen_to_be_invoked.RotationInfluence);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_DeleteOnInactive(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.DeleteOnInactive);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ScaleRoughness(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.ScaleRoughness = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_ScaleMagnitude(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.ScaleMagnitude = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Magnitude(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.Magnitude = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_Roughness(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.Roughness = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_PositionInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.PositionInfluence = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_RotationInfluence(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                UnityEngine.Vector3 gen_value;translator.Get(L, 2, out gen_value);
				gen_to_be_invoked.RotationInfluence = gen_value;
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_DeleteOnInactive(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                EZCameraShake.CameraShakeInstance gen_to_be_invoked = (EZCameraShake.CameraShakeInstance)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.DeleteOnInactive = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
