﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MyAstarPathfinderWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(MyAstar.Pathfinder);
			Utils.BeginObjectRegister(type, L, translator, 0, 4, 5, 5);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Start", _m_Start);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SetTraceParamCheck", _m_SetTraceParamCheck);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "NotifyComplete", _m_NotifyComplete);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clear", _m_Clear);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "startPosition", _g_get_startPosition);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "endPosition", _g_get_endPosition);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "jobDone", _g_get_jobDone);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "foundPath", _g_get_foundPath);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "is_trace_finder", _g_get_is_trace_finder);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "startPosition", _s_set_startPosition);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "endPosition", _s_set_endPosition);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "jobDone", _s_set_jobDone);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "foundPath", _s_set_foundPath);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "is_trace_finder", _s_set_is_trace_finder);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 6 && translator.Assignable<MyAstar.Node>(L, 2) && translator.Assignable<MyAstar.Node>(L, 3) && translator.Assignable<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4) && LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5) && LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 6))
				{
					MyAstar.Node _start = (MyAstar.Node)translator.GetObject(L, 2, typeof(MyAstar.Node));
					MyAstar.Node _target = (MyAstar.Node)translator.GetObject(L, 3, typeof(MyAstar.Node));
					MyAstar.PathFindManager.PathfindingJobComplete _callback = translator.GetDelegate<MyAstar.PathFindManager.PathfindingJobComplete>(L, 4);
					bool _local_coordinate = LuaAPI.lua_toboolean(L, 5);
					bool _use_path_modifier = LuaAPI.lua_toboolean(L, 6);
					
					MyAstar.Pathfinder gen_ret = new MyAstar.Pathfinder(_start, _target, _callback, _local_coordinate, _use_path_modifier);
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.Pathfinder constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Start(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 3&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)) 
                {
                    bool _use_thread = LuaAPI.lua_toboolean(L, 2);
                    int _timeout = LuaAPI.xlua_tointeger(L, 3);
                    
                    gen_to_be_invoked.Start( _use_thread, _timeout );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 2&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 2)) 
                {
                    bool _use_thread = LuaAPI.lua_toboolean(L, 2);
                    
                    gen_to_be_invoked.Start( _use_thread );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.Pathfinder.Start!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetTraceParamCheck(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int __user_param = LuaAPI.xlua_tointeger(L, 2);
                    int _check_range = LuaAPI.xlua_tointeger(L, 3);
                    
                    gen_to_be_invoked.SetTraceParamCheck( __user_param, _check_range );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_NotifyComplete(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.NotifyComplete(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clear(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.Clear(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_startPosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.startPosition);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_endPosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.endPosition);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_jobDone(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.jobDone);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_foundPath(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.foundPath);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_is_trace_finder(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushboolean(L, gen_to_be_invoked.is_trace_finder);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_startPosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.startPosition = (MyAstar.Node)translator.GetObject(L, 2, typeof(MyAstar.Node));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_endPosition(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.endPosition = (MyAstar.Node)translator.GetObject(L, 2, typeof(MyAstar.Node));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_jobDone(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.jobDone = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_foundPath(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.foundPath = (System.Collections.Generic.List<UnityEngine.Vector3>)translator.GetObject(L, 2, typeof(System.Collections.Generic.List<UnityEngine.Vector3>));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_is_trace_finder(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.Pathfinder gen_to_be_invoked = (MyAstar.Pathfinder)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.is_trace_finder = LuaAPI.lua_toboolean(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
