﻿#if USE_UNI_LUA
using LuaAPI = UniLua.Lua;
using RealStatePtr = UniLua.ILuaState;
using LuaCSFunction = UniLua.CSharpFunctionDelegate;
#else
using LuaAPI = XLua.LuaDLL.Lua;
using RealStatePtr = System.IntPtr;
using LuaCSFunction = XLua.LuaDLL.lua_CSFunction;
#endif

using XLua;
using System.Collections.Generic;


namespace XLua.CSObjectWrap
{
    using Utils = XLua.Utils;
    public class MyAstarGridBaseWrap 
    {
        public static void __Register(RealStatePtr L)
        {
			ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			System.Type type = typeof(MyAstar.GridBase);
			Utils.BeginObjectRegister(type, L, translator, 0, 10, 8, 8);
			
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Init", _m_Init);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetNode", _m_GetNode);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "NodeWalkable", _m_NodeWalkable);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "getNodeUserParam", _m_getNodeUserParam);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "SetExternalBlockData", _m_SetExternalBlockData);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "checkExternalBlock", _m_checkExternalBlock);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "GetNodeFromVector3", _m_GetNodeFromVector3);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "FindNearestWalkableNode", _m_FindNearestWalkableNode);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "ForeachNode", _m_ForeachNode);
			Utils.RegisterFunc(L, Utils.METHOD_IDX, "Clear", _m_Clear);
			
			
			Utils.RegisterFunc(L, Utils.GETTER_IDX, "maxX", _g_get_maxX);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "maxY", _g_get_maxY);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "maxZ", _g_get_maxZ);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "offsetX", _g_get_offsetX);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "offsetY", _g_get_offsetY);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "offsetZ", _g_get_offsetZ);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "node_size", _g_get_node_size);
            Utils.RegisterFunc(L, Utils.GETTER_IDX, "grid", _g_get_grid);
            
			Utils.RegisterFunc(L, Utils.SETTER_IDX, "maxX", _s_set_maxX);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "maxY", _s_set_maxY);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "maxZ", _s_set_maxZ);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "offsetX", _s_set_offsetX);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "offsetY", _s_set_offsetY);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "offsetZ", _s_set_offsetZ);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "node_size", _s_set_node_size);
            Utils.RegisterFunc(L, Utils.SETTER_IDX, "grid", _s_set_grid);
            
			
			Utils.EndObjectRegister(type, L, translator, null, null,
			    null, null, null);

		    Utils.BeginClassRegister(type, L, __CreateInstance, 1, 0, 0);
			
			
            
			
			
			
			Utils.EndClassRegister(type, L, translator);
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int __CreateInstance(RealStatePtr L)
        {
            
			try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
				if(LuaAPI.lua_gettop(L) == 1)
				{
					
					MyAstar.GridBase gen_ret = new MyAstar.GridBase();
					translator.Push(L, gen_ret);
                    
					return 1;
				}
				
			}
			catch(System.Exception gen_e) {
				return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
			}
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.GridBase constructor!");
            
        }
        
		
        
		
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Init(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TBOOLEAN == LuaAPI.lua_type(L, 5)) 
                {
                    int _grid_x_size = LuaAPI.xlua_tointeger(L, 2);
                    int _grid_y_size = LuaAPI.xlua_tointeger(L, 3);
                    float _node_s = (float)LuaAPI.lua_tonumber(L, 4);
                    bool _random_block = LuaAPI.lua_toboolean(L, 5);
                    
                    gen_to_be_invoked.Init( _grid_x_size, _grid_y_size, _node_s, _random_block );
                    
                    
                    
                    return 0;
                }
                if(gen_param_count == 4&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 2)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)) 
                {
                    int _grid_x_size = LuaAPI.xlua_tointeger(L, 2);
                    int _grid_y_size = LuaAPI.xlua_tointeger(L, 3);
                    float _node_s = (float)LuaAPI.lua_tonumber(L, 4);
                    
                    gen_to_be_invoked.Init( _grid_x_size, _grid_y_size, _node_s );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.GridBase.Init!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetNode(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int _x = LuaAPI.xlua_tointeger(L, 2);
                    int _y = LuaAPI.xlua_tointeger(L, 3);
                    int _z = LuaAPI.xlua_tointeger(L, 4);
                    
                        MyAstar.Node gen_ret = gen_to_be_invoked.GetNode( _x, _y, _z );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_NodeWalkable(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    MyAstar.Node _n = (MyAstar.Node)translator.GetObject(L, 2, typeof(MyAstar.Node));
                    
                        bool gen_ret = gen_to_be_invoked.NodeWalkable( _n );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_getNodeUserParam(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    bool _walkable = LuaAPI.lua_toboolean(L, 2);
                    int _x = LuaAPI.xlua_tointeger(L, 3);
                    int _y = LuaAPI.xlua_tointeger(L, 4);
                    
                        uint gen_ret = gen_to_be_invoked.getNodeUserParam( _walkable, _x, _y );
                        LuaAPI.xlua_pushuint(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_SetExternalBlockData(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    byte[] _b = LuaAPI.lua_tobytes(L, 2);
                    bool _APFP = LuaAPI.lua_toboolean(L, 3);
                    
                    gen_to_be_invoked.SetExternalBlockData( _b, _APFP );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_checkExternalBlock(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    int _x = LuaAPI.xlua_tointeger(L, 2);
                    int _y = LuaAPI.xlua_tointeger(L, 3);
                    
                        bool gen_ret = gen_to_be_invoked.checkExternalBlock( _x, _y );
                        LuaAPI.lua_pushboolean(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_GetNodeFromVector3(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    UnityEngine.Vector3 _pos;translator.Get(L, 2, out _pos);
                    
                        MyAstar.Node gen_ret = gen_to_be_invoked.GetNodeFromVector3( _pos );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_FindNearestWalkableNode(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
			    int gen_param_count = LuaAPI.lua_gettop(L);
            
                if(gen_param_count == 5&& translator.Assignable<UnityEngine.Vector2>(L, 2)&& translator.Assignable<UnityEngine.Vector2>(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 5)) 
                {
                    UnityEngine.Vector2 _pos;translator.Get(L, 2, out _pos);
                    UnityEngine.Vector2 _orig;translator.Get(L, 3, out _orig);
                    float _maxNearestNodeDistance = (float)LuaAPI.lua_tonumber(L, 4);
                    int _getNearestForceOverlap = LuaAPI.xlua_tointeger(L, 5);
                    
                        MyAstar.Node gen_ret = gen_to_be_invoked.FindNearestWalkableNode( _pos, _orig, _maxNearestNodeDistance, _getNearestForceOverlap );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 4&& translator.Assignable<UnityEngine.Vector2>(L, 2)&& translator.Assignable<UnityEngine.Vector2>(L, 3)&& LuaTypes.LUA_TNUMBER == LuaAPI.lua_type(L, 4)) 
                {
                    UnityEngine.Vector2 _pos;translator.Get(L, 2, out _pos);
                    UnityEngine.Vector2 _orig;translator.Get(L, 3, out _orig);
                    float _maxNearestNodeDistance = (float)LuaAPI.lua_tonumber(L, 4);
                    
                        MyAstar.Node gen_ret = gen_to_be_invoked.FindNearestWalkableNode( _pos, _orig, _maxNearestNodeDistance );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                if(gen_param_count == 3&& translator.Assignable<UnityEngine.Vector2>(L, 2)&& translator.Assignable<UnityEngine.Vector2>(L, 3)) 
                {
                    UnityEngine.Vector2 _pos;translator.Get(L, 2, out _pos);
                    UnityEngine.Vector2 _orig;translator.Get(L, 3, out _orig);
                    
                        MyAstar.Node gen_ret = gen_to_be_invoked.FindNearestWalkableNode( _pos, _orig );
                        translator.Push(L, gen_ret);
                    
                    
                    
                    return 1;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
            return LuaAPI.luaL_error(L, "invalid arguments to MyAstar.GridBase.FindNearestWalkableNode!");
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_ForeachNode(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    System.Action<MyAstar.Node> _cb = translator.GetDelegate<System.Action<MyAstar.Node>>(L, 2);
                    
                    gen_to_be_invoked.ForeachNode( _cb );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _m_Clear(RealStatePtr L)
        {
		    try {
            
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
            
            
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
            
            
                
                {
                    
                    gen_to_be_invoked.Clear(  );
                    
                    
                    
                    return 0;
                }
                
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            
        }
        
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_maxX(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, gen_to_be_invoked.maxX);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_maxY(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, gen_to_be_invoked.maxY);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_maxZ(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.xlua_pushinteger(L, gen_to_be_invoked.maxZ);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_offsetX(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.offsetX);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_offsetY(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.offsetY);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_offsetZ(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.offsetZ);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_node_size(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                LuaAPI.lua_pushnumber(L, gen_to_be_invoked.node_size);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _g_get_grid(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                translator.Push(L, gen_to_be_invoked.grid);
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 1;
        }
        
        
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_maxX(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.maxX = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_maxY(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.maxY = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_maxZ(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.maxZ = LuaAPI.xlua_tointeger(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_offsetX(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.offsetX = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_offsetY(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.offsetY = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_offsetZ(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.offsetZ = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_node_size(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.node_size = (float)LuaAPI.lua_tonumber(L, 2);
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
        [MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
        static int _s_set_grid(RealStatePtr L)
        {
		    try {
                ObjectTranslator translator = ObjectTranslatorPool.Instance.Find(L);
			
                MyAstar.GridBase gen_to_be_invoked = (MyAstar.GridBase)translator.FastGetCSObj(L, 1);
                gen_to_be_invoked.grid = (MyAstar.Node[,,])translator.GetObject(L, 2, typeof(MyAstar.Node[,,]));
            
            } catch(System.Exception gen_e) {
                return LuaAPI.luaL_error(L, "c# exception:" + gen_e);
            }
            return 0;
        }
        
		
		
		
		
    }
}
