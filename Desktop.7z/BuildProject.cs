﻿/**  *****************************Description:一键发布*****************************
 *Copyright(C) 2019 by DefaultCompany
 *All rights reserved.
 *ProductName:  Dungeon3
 *Author:       gaoyc，futf-Tony，lilc
 *Version:      1.0
 *UnityVersion: 2018.4.0f1
 *CreateTime:   August 21st, 2019 3:05pm
 */
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CSObjectWrapEditor;
using TJ;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
public static class BuildProject
{
    #region ===============================变量===============================
    public static List<string> levels = new List<string>();
    private static bool IsBuild = false;//是否点击构建，否既是点击生成ab包
    #endregion

    #region ===============================菜单功能===============================
    //-------------------------------windows平台打包-------------------------------
    /// <summary>
    ///-------------------------------windows平台打包-------------------------------
    /// </summary>
    [MenuItem("Build/Windows", false, 1)]
    static void BuildWindows()
    {
        IsBuild = true;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar();
#if (UNITY_STANDALONE_WIN == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.StandaloneWindows64); //切换平台
        AssetDatabase.Refresh();
#else
        PCTargerBuild();
#endif
    }

    //-------------------------------android平台打包-------------------------------
    /// <summary>
    ///-------------------------------android平台打包-------------------------------
    /// </summary>
    [MenuItem("Build/Android", false, 2)]
    static void BuildAndroid()
    {
        IsBuild = true;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();

#if (UNITY_ANDROID == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.Android); //切换平台
        AssetDatabase.Refresh();
        return;
#else
        AndroidTargerBuild();
#endif
    }

    //-------------------------------ios平台打包-------------------------------
    /// <summary>
    ///-------------------------------ios平台打包-------------------------------
    /// </summary>
    [MenuItem("Build/IOS", false, 3)]
    static void BuildIOS()
    {
        IsBuild = true;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();
#if (UNITY_IOS == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.iOS); //切换平台
        AssetDatabase.Refresh();
#else
        IOSTargerBuild();
#endif
    }

    //-------------------------------删除外部AB包目录-------------------------------
    /// <summary>
    ///-------------------------------删除外部AB包目录-------------------------------
    /// </summary>
    [MenuItem("Build/Clean ExternalAB", false, 14)]
    static void CleanExternalAB()
    {
        // 判断平台，再删除平台对应的目录
        string currentPath = System.Environment.CurrentDirectory;
        string buildPath = "";
#if UNITY_STANDALONE_WIN
        buildPath = Path.Combine(currentPath, Config.AB_Build_External_Path_PC).Replace("\\", "/");
#endif

#if UNITY_ANDROID
        buildPath = Path.Combine(currentPath, Config.AB_Build_External_Path_Android).Replace("\\", "/");
#endif

#if UNITY_IOS
        buildPath = Path.Combine(currentPath, Config.AB_Build_External_Path_IOS).Replace("\\", "/");
#endif
        DeleteDirectory(buildPath);
    }

    //-------------------------------删除StreamingAsset目录下的AB包-------------------------------
    /// <summary>
    /// -------------------------------删除StreamingAsset目录下的AB包-------------------------------
    /// </summary>
    [MenuItem("Build/Clean StreamingAssetsAB", false, 15)]
    static void CleanStreamingAssetsAB()
    {
        // 判断平台，再删除平台对应的目录
        DeleteDirectory(Config.AB_Build_Path);
    }

    //-------------------------------导出AB包并拷贝到外部热更位置(PC)-------------------------------
    /// <summary>
    /// -------------------------------导出AB包并拷贝到外部热更位置(PC)-------------------------------
    /// </summary>
    [MenuItem("Build/Build AssetBundlesPC")]
    static public void BuildAssetBundlesPC()
    {
        IsBuild = false;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();
#if (UNITY_STANDALONE_WIN == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.StandaloneWindows64); //切换平台
        AssetDatabase.Refresh();
#else
        PCTargerAssetBundles();
#endif
    }

    //-------------------------------导出AB包并拷贝到外部热更位置(Android)-------------------------------
    /// <summary>
    /// -------------------------------导出AB包并拷贝到外部热更位置(Android)-------------------------------
    /// </summary>
    [MenuItem("Build/Build AssetBundlesAndroid")]
    static public void BuildAssetBundlesAndroid()
    {
        IsBuild = false;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();

#if (UNITY_ANDROID == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.Android); //切换平台
        AssetDatabase.Refresh();
        return;
#else
        AndroidTargerAssetBundles();
#endif
    }

    //-------------------------------导出AB包并拷贝到外部热更位置(IOS)-------------------------------
    /// <summary>
    /// -------------------------------导出AB包并拷贝到外部热更位置(IOS)-------------------------------
    /// </summary>
    [MenuItem("Build/Build AssetBundlesIOS")]
    static public void BuildAssetBundlesIOS()
    {
        IsBuild = false;
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();
        AssetDatabase.Refresh();
#if (UNITY_IOS == false)
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.iOS); //切换平台
        AssetDatabase.Refresh();
#else
        IOSTargerAssetBundles();
#endif
    }

    #endregion

    #region ===============================调用方法===============================
    //-------------------------------监听切换场景事件回调函数-------------------------------
    /// <summary>
    /// -------------------------------监听切换场景事件回调函数-------------------------------
    /// </summary>
    public class ActiveBuildTargetListener : IActiveBuildTargetChanged
    {
        public int callbackOrder { get { return 0; } }
        public void OnActiveBuildTargetChanged(BuildTarget previousTarget, BuildTarget newTarget)
        {
            Debug.Log("转换到什么平台： " + newTarget);

            if (newTarget == BuildTarget.StandaloneWindows64)
            {
                //是否点击构建，否既是点击生成ab包
                if (IsBuild)
                {
                    PCTargerBuild();
                }
                else
                {
                    PCTargerAssetBundles();
                }
                IsBuild = false;
            }
            else if (newTarget == BuildTarget.Android)
            {
                if (IsBuild)
                {
                    AndroidTargerBuild();
                }
                else
                {
                    AndroidTargerAssetBundles();
                }
                IsBuild = false;
            }
            else if (newTarget == BuildTarget.iOS)
            {
                if (IsBuild)
                {
                    IOSTargerBuild();
                }
                else
                {
                    IOSTargerAssetBundles();
                }
                IsBuild = false;
            }
            EditorUtilityDisplayProgressBar.OpenProgressBar1();
        }
    }

    //-------------------------------PCTargerBuild方法功能：直接构建-------------------------------
    /// <summary>
    ///-------------------------------PCTargerBuild方法功能：直接构建-------------------------------
    /// </summary>
    private static void PCTargerBuild()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar2();
        BuildAssetBundles(Config.AB_Build_External_Path_PC);
        CopyVersionFile(Config.AB_Build_External_Path_PC);
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar3();
        //删除Assets/streamingAssets下的目录，减少打包PC端时间
        DeleteDirectory(Path.Combine(System.Environment.CurrentDirectory, Config.AB_Build_Path + "/assets").Replace("\\", "/"));
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar4();
        //重新构建项目
        BuildPlayerOptionSet("PC");
    }

    //-------------------------------AndroidTargerBuild方法功能：直接构建-------------------------------
    /// <summary>
    ///-------------------------------AndroidTargerBuild方法功能：直接构建-------------------------------
    /// </summary>
    private static void AndroidTargerBuild()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar2();
        BuildAssetBundles(Config.AB_Build_External_Path_Android);
        EditorUtilityDisplayProgressBar.OpenProgressBar3();
        // copy version.manifest to target
        CopyVersionFile(Config.AB_Build_External_Path_Android);
        CopyABFile(Config.AB_Build_External_Path_Android, Config.AB_Build_Path);
        EditorUtilityDisplayProgressBar.OpenProgressBar4();
        AssetDatabase.Refresh();
        //重新构建项目
        BuildPlayerOptionSet("Android");
    }

    //-------------------------------IOSTargerBuild方法功能：直接构建-------------------------------
    /// <summary>
    ///-------------------------------IOSTargerBuild方法功能：直接构建-------------------------------
    /// </summary>
    private static void IOSTargerBuild()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        AssetDatabase.Refresh();
        EditorUtilityDisplayProgressBar.OpenProgressBar2();
        BuildAssetBundles(Config.AB_Build_External_Path_IOS);
        EditorUtilityDisplayProgressBar.OpenProgressBar3();
        CopyVersionFile(Config.AB_Build_External_Path_IOS);
        CopyABFile(Config.AB_Build_External_Path_IOS, Config.AB_Build_Path);
        EditorUtilityDisplayProgressBar.OpenProgressBar4();
        AssetDatabase.Refresh();
        //重新构建项目
        BuildPlayerOptionSet("IOS");
    }

    //-------------------------------PCTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// <summary>
    ///-------------------------------PCTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// </summary>
    private static void PCTargerAssetBundles()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        BuildAssetBundles(Config.AB_Build_External_Path_PC);
        CopyVersionFile(Config.AB_Build_External_Path_PC);
        EditorUtilityDisplayProgressBar.OpenProgressBar6();
        return;
    }

    //-------------------------------AndroidTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// <summary>
    ///-------------------------------AndroidTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// </summary>
    private static void AndroidTargerAssetBundles()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        BuildAssetBundles(Config.AB_Build_External_Path_Android);
        // copy version.manifest to target
        CopyVersionFile(Config.AB_Build_External_Path_Android);
        CopyABFile(Config.AB_Build_External_Path_Android, Config.AB_Build_Path);
        EditorUtilityDisplayProgressBar.OpenProgressBar6();
        return;
    }

    //-------------------------------IOSTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// <summary>
    ///-------------------------------IOSTargerAssetBundles方法功能：直接生成AB包-------------------------------
    /// </summary>
    private static void IOSTargerAssetBundles()
    {
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");
        // 重新生成XLua代码
        Generator.GenAll();
        BuildAssetBundles(Config.AB_Build_External_Path_IOS);
        CopyVersionFile(Config.AB_Build_External_Path_IOS);
        CopyABFile(Config.AB_Build_External_Path_IOS, Config.AB_Build_Path);
        EditorUtilityDisplayProgressBar.OpenProgressBar6();
        return;
    }


    //-------------------------------发布参数设置-------------------------------
    /// <summary>
    /// -------------------------------发布参数设置-------------------------------
    /// </summary>
    /// <param name="Target">平台</param>
    public static void BuildPlayerOptionSet(string Targets)
    {
        //上一次外部构建出来的目录
        string currentPath = System.IO.Directory.GetCurrentDirectory();

        BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
        buildPlayerOptions.scenes = levels.ToArray();
        if (Targets == "PC")
        {
            //上一次外部构建出来的目录
            string buildPath = Path.Combine(currentPath, "Build/Windows/").Replace("\\", "/");
            buildPlayerOptions.locationPathName = buildPath + Application.productName + ".exe";
            buildPlayerOptions.target = BuildTarget.StandaloneWindows64;
        }
        else if (Targets == "Android")
        {
            string buildPath = Path.Combine(currentPath, "Build/Android/").Replace("\\", "/");
            buildPlayerOptions.locationPathName = buildPath + Application.productName + ".apk";
            buildPlayerOptions.target = BuildTarget.Android;
        }
        else
        {
            string buildPath = Path.Combine(currentPath, "Build/IOS/").Replace("\\", "/");
            buildPlayerOptions.locationPathName = buildPath + Application.productName + "Xcode";
            buildPlayerOptions.target = BuildTarget.iOS;
        }
        buildPlayerOptions.options = BuildOptions.None;
        Build(buildPlayerOptions);

        EditorUtilityDisplayProgressBar.OpenProgressBar5();
        return;
    }

    //-------------------------------发布/监听构建回调函数-------------------------------
    /// <summary>
    /// -------------------------------发布/监听构建回调函数-------------------------------
    /// </summary>
    /// <param name="buildPlayerOptions">发布选项</param>
    public static void Build(BuildPlayerOptions buildPlayerOptions)
    {
        try
        {
            BuildReport report = BuildPipeline.BuildPlayer(buildPlayerOptions);
            BuildSummary summary = report.summary;

            //构建完成后的事件监听
            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log("Build succeeded: " + summary.totalSize + " bytes" + " output:" + summary.outputPath);
                // #if UNITY_STANDALONE_WIN
                if (buildPlayerOptions.target == BuildTarget.StandaloneWindows64)
                {
                    string dataPath = "Build/Windows/" + Application.productName + "_Data/StreamingAssets/assetbundles";
                    // CopyABFile(Config.AB_Build_External_Path_PC, Config.PC_StreamingAssets_Path);
                    CopyABFile(Config.AB_Build_External_Path_PC, dataPath);
                }
                // #endif     
                EditorUtilityDisplayProgressBar.OpenProgressBar6();
            }

            if (summary.result == BuildResult.Failed)
            {
                Debug.LogError("Build failed! total errors:" + summary.totalErrors);
                EditorUtilityDisplayProgressBar.OpenProgressBar7();
            }
        }
        catch (System.Exception)
        {

            throw;
        }
    }

    //-------------------------------删除上次的文件-------------------------------
    /// <summary>
    /// -------------------------------删除上次的文件-------------------------------
    /// </summary>
    /// <param name="path">删除路径</param>
    public static void DeleteDirectory(string path)
    {
        DirectoryInfo info = new DirectoryInfo(path);
        if (info.Exists)
        {
            info.Delete(true);
        }
    }

    //-------------------------------拷贝版本文件-------------------------------
    /// <summary>
    /// -------------------------------拷贝版本文件-------------------------------
    /// </summary>
    public static void CopyVersionFile(string TargetPath)
    {
        string verfile = Path.Combine(System.Environment.CurrentDirectory, "Assets/version.manifest").Replace("\\", "/");
        string tgtfile = Path.Combine(System.Environment.CurrentDirectory, TargetPath + "/version.manifest").Replace("\\", "/");

        File.Copy(verfile, tgtfile, true);
        Debug.Log("copy verfile from:" + verfile + " to:" + tgtfile);
    }

    //-------------------------------复制文件夹所有文件-------------------------------
    /// <summary>
    /// -------------------------------复制文件夹所有文件-------------------------------
    /// </summary>
    public static void CopyABFile(string CopyPath1, string CopyPath2)
    {
        string path1 = Path.Combine(System.Environment.CurrentDirectory, CopyPath1).Replace("\\", "/");
        string path2 = Path.Combine(System.Environment.CurrentDirectory, CopyPath2).Replace("\\", "/");
        DeleteDirectory(path2);//先删除一遍
        CopyFolder(path1, path2);
    }

    //-------------------------------复制文件夹所有文件-------------------------------
    /// <summary>
    /// -------------------------------复制文件夹所有文件-------------------------------
    /// </summary>
    /// <param name="sourcePath">源目录</param>
    /// <param name="destPath">目的目录</param>
    public static void CopyFolder(string sourcePath, string destPath)
    {
        if (Directory.Exists(sourcePath))
        {
            if (!Directory.Exists(destPath))
            {
                Directory.CreateDirectory(destPath);
            }
            //获得源文件下所有文件
            List<string> files = new List<string>(Directory.GetFiles(sourcePath));
            files.ForEach(c =>
            {
                string destFile = Path.Combine(new string[] { destPath, Path.GetFileName(c) }).Replace("\\", "/");
                //不只复制meta
                if (Path.GetExtension(destFile) != "meta")
                {
                    File.Copy(c, destFile, true);//覆盖模式
                }
            });
            //获得源文件下所有目录文件
            List<string> folders = new List<string>(Directory.GetDirectories(sourcePath));
            folders.ForEach(c =>
            {
                string destDir = Path.Combine(new string[] { destPath, Path.GetFileName(c) }).Replace("\\", "/");
                //采用递归的方法实现
                CopyFolder(c, destDir);
            });

        }
    }

    //-------------------------------构建AB包的方法-------------------------------
    /// <summary>
    /// -------------------------------构建AB包的方法-------------------------------
    /// </summary>
    /// <param name="BuildABPath">AB包要存的路径</param>
    public static void BuildAssetBundles(string BuildABPath)
    {
        AssetBundleBuilder builder = new AssetBundleBuilder(BuildABPath, Config.AssetBundleBuildRulePath);
        builder.Begin();
        builder.ParseRule();
        builder.Export();
        builder.End();
        Debug.Log("Build AssetBundles OK!");
    }

    //-------------------------------（过时）切换平台-------------------------------
    /// <summary>
    /// -------------------------------切换平台-------------------------------
    /// </summary>
    /// <param name="BuildTargetName"></param>
    static void SwitchBuildTarget(string BuildTargetName)
    {
        // 清理XLua生成的代码,要在切换平台前清除否则切换后会报错.
        Generator.ClearAll();

        if (BuildTargetName == "Windows")
        {
#if (UNITY_STANDALONE_WIN == false)
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.StandaloneWindows64); //切换平台
#endif
        }
        else if (BuildTargetName == "Android")
        {
#if (UNITY_ANDROID == false)
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.Android); //切换平台
#endif
        }
        else if (BuildTargetName == "iOS")
        {
#if (UNITY_IOS == false)
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.iOS); //切换平台
#endif
        }

    }

    //-------------------------------（过时）xlua和ab包打包-------------------------------
    /// <summary>
    /// -------------------------------xlua和ab包打包-------------------------------
    /// </summary>
    static void PreBuild()
    {
        // 要打包的场景
        levels.Clear();
        levels.Add("Assets/Scenes/Launch.unity");

        // 重新生成XLua代码
        Generator.GenAll();

        // 重新打ab包
        FrameworkMenuItems.BuildAssetBundles();

        // copy version.manifest to target
        CopyVersionFile(Config.AB_Build_Path);
    }

    #endregion

}