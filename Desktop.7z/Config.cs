﻿

namespace TJ
{
    public class Config
    {
        //打包规则描述文件路径
        public const string AssetBundleBuildRulePath = "Assets/TJFramework/AssetBundleBuilder/BuildRuleTemplate.json";
        //打包AB包路径(当前不考虑热更新的情况)
        public const string AB_Build_Path = "Assets/StreamingAssets/assetbundles";
        //打包AB包路径(PC热更)
        public const string PC_StreamingAssets_Path = "Build/Windows/dungeon3_Data/StreamingAssets/assetbundles";
        //打包AB包路径(PC热更)
        public const string AB_Build_Hotfix_Path_PC = "StreamingAssetsData/Windows/Hotfix/assetbundles";
        //打包AB包路径(Android热更)
        public const string AB_Build_Hotfix_Path_Android = "StreamingAssetsData/Android/Hotfix/assetbundles";
        //打包AB包路径(IOS热更)
        public const string AB_Build_Hotfix_Path_IOS = "StreamingAssetsData/IOS/Hotfix/assetbundles";

    };
}
